package ilias.forms.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import oracle.ewt.lwAWT.LWContainer;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;

public class ErrorBox extends LWContainer {

	private static final long serialVersionUID = -6115600878027253508L;

	public static final int INFO = 0;
	public static final int WARNING = 1;
	public static final int ERROR = 2;
	private static final Color infoColor = new Color(162, 255, 162);
	private static final Color warningColor = new Color(255, 255, 162);
	private static final Color errorColor = new Color(255, 162, 162);
	private static final ErrorBoxBorderPainter infoBorderPainter = new ErrorBoxBorderPainter(Color.green);
	private static final ErrorBoxBorderPainter warningBorderPainter = new ErrorBoxBorderPainter(Color.yellow);
	private static final ErrorBoxBorderPainter errorBorderPainter = new ErrorBoxBorderPainter(Color.red);

	static class ErrorData {
		String errorId;
		String errorTitle;
		String errorText;
	}

	private int type;
	private ErrorData errorData;
	private ErrorText textPane;
	private ErrorBoxHeader headerPane;
	private long timestamp;
	
	public ErrorBox(String text, int type) {
		this.type = type;
		this.timestamp = System.currentTimeMillis();
		setLayout(new BorderLayout());
		errorData = parseText(text, type);
		textPane = new ErrorText(errorData.errorText) {
			private static final long serialVersionUID = 5532084867955247873L;
			@Override
			protected void onClick() {
				ErrorBox.this.onClick();
			}
		};
		add(BorderLayout.CENTER, textPane);
		headerPane = new ErrorBoxHeader(errorData.errorTitle, type) {
			private static final long serialVersionUID = 4881872915540003679L;
			@Override
			protected void onClick() {
				ErrorBox.this.onClick();
			}
			@Override
			protected void onButtonClick() {
				ErrorBox.this.onButtonClick();
			}
		};
		switch(type) {
		case INFO:
			headerPane.setBackground(infoColor);
			break;
		case WARNING:
			headerPane.setBackground(warningColor);
			break;
		case ERROR:
			headerPane.setBackground(errorColor);
			break;
		}
		add(BorderLayout.NORTH, headerPane);
	}

	public int getType() {
		return type;
	}

	public String getErrorText() {
		return errorData.errorText;
	}

	public String getErrorTitle() {
		return errorData.errorTitle;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public String getErrorId() {
		return errorData.errorId;
	}

	public void setErrorId(String errorId) {
		errorData.errorId = errorId;
	}

	public void increment() {
		timestamp = System.currentTimeMillis();
		headerPane.increment();
	}

	protected void onClick() {
		//ActionEvent action = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, getErrorId());
		//ErrorBox.this.fireActionEvent(action);
	}

	protected void onButtonClick() {
		//ActionEvent action = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, getErrorId());
		//ErrorBox.this.fireActionEvent(action);
	}

	/**
	 * The text is a sequence of elements separated by ':'
	 * 
	 * <errorId>:<errorTitle>:<errorText>
	 * 
	 * errorId: the unique number of the message (increases by each new message)
	 * 
	 * @param text
	 */
	protected static ErrorData parseText(String text, int type) {
		char[] chars = text.toCharArray();
		int[] delims = new int[2];
		boolean foundSlash = false;
		int k = 0;
		for(int i=0; i<chars.length; i++) {
			if (chars[i] == ':' && !foundSlash) {
				delims[k++] = i;
			}
			foundSlash = chars[i] == '\\';
		}
		ErrorData data = new ErrorData();
		if(k>0) {
			data.errorId = text.substring(0, delims[0]);
			if (k>1) {
				data.errorTitle = text.substring(delims[0]+1, delims[1]);
				data.errorTitle = data.errorTitle.replace("\\:", ":");
				data.errorText = text.substring(delims[1]+1);
				data.errorText = data.errorText.replace("\\:", ":");
			} else {
				switch(type) {
				case INFO:
					data.errorTitle = "INFO";
					break;
				case WARNING:
					data.errorTitle = "WARNING";
					break;
				case ERROR:
					data.errorTitle = "ERROR";
					break;
				}
				data.errorText = text.substring(delims[0]+1);
				data.errorText = data.errorText.replace("\\:", ":");
			}
		}
		return data;
	}

	@Override
	protected void processMouseEvent(MouseEvent event) {
		if (event.getID() == MouseEvent.MOUSE_CLICKED) {
			ErrorBox.this.onClick();
		}
		super.processMouseEvent(event);
	}
	
	@Override
	public BorderPainter getBorderPainter() {
		if (type == INFO) {
			return infoBorderPainter;
		} else if (type == WARNING) {
			return warningBorderPainter;
		} else {
			return errorBorderPainter;
		}
	}

	public int calcHeight() {
		int height = getHeight() - getInnerSize().height;
		height += headerPane.getTextHeight();
		height += textPane.getTextHeight();
		return height;
	}

	public static class ErrorBoxBorderPainter extends AbstractBorderPainter {

		private static final ImmInsets _INSETS0 = new ImmInsets(2, 2, 2, 2);

		private Color borderColor;
		
		public ErrorBoxBorderPainter(Color color) {
			borderColor = color;
		}
		
		protected ImmInsets getOwnInsets(PaintContext ctx) {
			return _INSETS0;
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			g.setColor(borderColor);
			g.drawRect(x, y, w - 1, h - 1);
			g.setColor(Color.white);
			g.drawRect(x+1, y+1, w - 3, h - 3);
			g.setColor(oldColor);
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | 0x80;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return true;
		}
	}
}
