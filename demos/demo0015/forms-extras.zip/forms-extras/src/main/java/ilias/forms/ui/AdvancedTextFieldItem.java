package ilias.forms.ui;

import ilias.clipboard.MyClipboard;
import ilias.forms.error.ErrorComponent;
import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import oracle.ewt.button.PushButton;
import oracle.ewt.lwAWT.lwMenu.LWPopupMenu;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.util.ClipboardProxy;
import oracle.ewt.util.InputEventUtils;
import oracle.forms.engine.KeyBinder;
import oracle.forms.handler.IHandler;
import oracle.forms.properties.BorderBevel;
import oracle.forms.properties.FormAction;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTextField;

public class AdvancedTextFieldItem extends VTextField implements
		ErrorComponent, ActionListener, MouseListener, KeyListener {

	private static final long serialVersionUID = -6510016495554341418L;

	private static final ID ERROR_STRING = ID.registerProperty("errorString");

	private static final String CUT = "cut";
	private static final String COPY = "copy";
	private static final String PASTE = "paste";
	private static final String PASTE_SPECIAL = "pasteSpecial";

	private static Image SEARCH_WHITE = TextComponentButton.getImage("search_white.gif");
	private static Image SEARCH_YELLOW = TextComponentButton.getImage("search_yellow.gif");

	private TextComponentBorder border;

	private PushButton button;
	private Image normal;
	private Image query;
	private boolean hasLov = false;
	private boolean editable = true;

	private String tooltip;
	private String prompt;

	public AdvancedTextFieldItem() {
		this(SEARCH_WHITE, SEARCH_YELLOW);
	}
	
	public AdvancedTextFieldItem(Image normal, Image query) {
		super();
		this.normal = normal;
		this.query = query;
		// listval or calendar button 
		button = new TextComponentButton(normal);
		getTextBorder().setButton(button);
		button.setVisible(false);		
		add(button);
		// Add listener for decimal point
		addKeyListener(this);
	}

	protected TextComponentBorder getTextBorder() {
		if (border == null) {
			border = new TextComponentBorder(this);
		}
		return border;
	}

	protected PushButton getButton() {
		return button;
	}

	public void init(IHandler ihandler) {
		if (ihandler != null) {
			super.init(ihandler);
		}
		// Add listener on listval or calendar button
		button.addMouseListener(this);
	}

	@Override
	public boolean setProperty(ID id, Object value) {
		if (id == ID.VALUE) {
			return setValueAndTooltip((String) value);
		//} else if (id == ID.POPUPHELP_ID) {
		} else if (id == ID.BORDER_BEVEL) {
			getTextBorder().setBorderBevel((BorderBevel) value);
		} else if (id == ERROR_STRING) {
			return setErrorStringProperty((String) value);
		/*} else if (id == SEARCH_ICON) {
    		buttonImage = TextComponentButton.getImage((String) value);
    		System.out.println("value=" + ((String) value));
    		button.setImage(buttonImage);
    		button.setVisible(true);
    		return true;*/
		} else if (id == ID.HAS_LOV) {
			if (value instanceof Boolean) {
				if ((Boolean) value) {
					hasLov = true;
				} else {
					hasLov = false;
				}			
				showButton(editable);
			}
    	} else if (id == ID.EDITABLE) {
			if (value instanceof Boolean) {
				if ((Boolean) value) {
					editable = true;
				} else {
					editable = false;
				}
				showButton(editable);
			}
		} else if (id == ID.BACKGROUND) {
			if (value instanceof Color) {
				Color c = (Color) value;
				if (c.getRGB() == IliasLookAndFeel.QUERY_COLOR.getRGB()) {
		    		button.setImage(query);					
				} else {
		    		button.setImage(normal);
				}
			}
		}
		return super.setProperty(id, value);
	}
	
	protected void showButton(boolean editable) {
		if (editable && hasLov) {
			button.setVisible(true);
			button.setToolTipValue(tooltip);
		}
		else {
			button.setVisible(false);
		}
	}
	
	private String dequote(String str) {
    	return str.replaceAll("^\"|\"$", "").replaceAll("\"\"", "\"");
    }
    
	private boolean setValueAndTooltip(String val) {
		if (val != null) {
            // set separate tooltip text and value
            // e.g. in pl/sql set 
            //    :blck.item := '<tooltip>tooltip text;value';
            if (val.toLowerCase().startsWith("<tooltip>")) {
            	// remove <tooltip> prefix, and split tooltip text and value
            	String v = val.substring("<tooltip>".length());
            	
            	//regexp: separated by ; followed by either even number of 
				//        double quotes or no double quotes
				String[] vals = v.split(";(?=([^\"]|\"[^\"]*\")*$)");
				tooltip = dequote(vals[0]);
				String itemvalue = dequote(vals[1]);
				
				// set tooltip to null when empty string, to avoid empty bubble popping up
				if (tooltip == "") tooltip = (String) null;
				
				_setToolTipValue(tooltip);
				if (button != null) {
					button.setToolTipValue(tooltip);
				}				
				return super.setProperty(ID.VALUE, itemvalue);
            }
        }
        return super.setProperty(ID.VALUE, val);
    }
	
	private void _setToolTipValue(String text) {
		setToolTipValue(text);
	}

	private boolean setErrorStringProperty(String error) {
		setErrorString(error);
		return true;
	}

	public void setErrorString(String error) {
		getTextBorder().setErrorString(error);
	}

	public String getErrorString() {
		return getTextBorder().getErrorString();
	}

    @Override
	public BorderPainter getBorderPainter() {
		return getTextBorder().getBorderPainter();
	}

	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}

    @Override
    public void setEditable(boolean flag) {
    	super.setEditable(flag);
    	button.setEnabled(isEnabled() && isEditable());
    }

    @Override
    public void setEnabled(boolean flag) {
    	super.setEnabled(flag);
    	button.setEnabled(isEnabled() && isEditable());
    }
	
    @Override
    public void destroy() {
    	removeKeyListener(this);
    	if (button != null) {
	  		button.removeMouseListener(this);
	  		button = null;
    	}
		if (border != null) {
			border.dispose();
			border = null;
		}
    	super.destroy();
    }
    
    @Override
	protected void processFocusEvent(FocusEvent e) {
		super.processFocusEvent(e);
	}

	@Override
	public void processMouseEvent(MouseEvent e) {
		if (InputEventUtils.isRightMouseButton(e)) {
			switch (e.getID()) {
			case MouseEvent.MOUSE_PRESSED:
				if (!hasGlobalFocus()) {
					requestFocus();
				}
				e.consume();
				return;
			case MouseEvent.MOUSE_RELEASED:
				if (hasGlobalFocus()) {
					createPopup(e.getX(), e.getY());
				}
				e.consume();
				return;
			}
		}
		super.processMouseEvent(e);
	}

    @Override
	public void processKeyEvent(KeyEvent e) {
		if (!e.isConsumed() && e.getID() == KeyEvent.KEY_TYPED
				&& e.getKeyChar() == 2) {
			pasteSpecial();
			e.consume();
			return;
		}
		super.processKeyEvent(e);
	}

	/** Create a popup for this field */
	private void createPopup(int x, int y) {
		LWPopupMenu mPopupMenu = new LWPopupMenu();
		mPopupMenu.setFont(getFont());
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Cut", CUT,
				"cut_16.gif", isEditable()));
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Copy", COPY,
				"copy_16.gif", true));
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Paste", PASTE,
				"paste_16.gif", isEditable()));
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Paste Special",
				PASTE_SPECIAL, "paste_16.gif", isEditable()));
		mPopupMenu.popup(this, x, y);
	}

    @Override
	public void copy() {
		if (isTextSecure()) {
			Toolkit.getDefaultToolkit().beep();
			return;
		}
		String s = getSelectedText();
		if (s.length() == 0) {
			return;
		}
		super.copy();
		addFromClipboard();
	}

	private void pasteSpecial() {
		if (!isEditable()) {
			Toolkit.getDefaultToolkit().beep();
			return;
		}
		if (MyClipboard.mMyClipboard.size() > 0) {
			MyClipboard.mMyClipboard.popup(this, 2, 2);
		}
	}

    @Override
	public void actionPerformed(ActionEvent e) {
		String s = e.getActionCommand();
		if (s == CUT) {
			cut();
		} else if (s == COPY) {
			copy();
		} else if (s == PASTE) {
			paste();
		} else if (s == PASTE_SPECIAL) {
			pasteSpecial();
		}
	}

	/** Add what is on the clipboard into our clipboard */
	@SuppressWarnings("deprecation")
	private void addFromClipboard() {
		String text = null;
		Clipboard clipboard = ClipboardProxy.getSystemClipboard();
		Transferable transferable = clipboard.getContents(this);
		if (transferable != null) {
			try {
				if (transferable.isDataFlavorSupported(DataFlavor.stringFlavor))
					text = (String) transferable
							.getTransferData(DataFlavor.stringFlavor);
				else if (transferable
						.isDataFlavorSupported(DataFlavor.plainTextFlavor)) {
					byte abyte0[] = (byte[]) transferable
							.getTransferData(DataFlavor.plainTextFlavor);
					try {
						text = new String(abyte0, 0, abyte0.length, "8859_1");
					} catch (UnsupportedEncodingException unsupportedencodingexception) {
					}
				}
			} catch (UnsupportedFlavorException unsupportedflavorexception) {
			} catch (IOException ioexception) {
			}
		}
		if (text != null) {
			String key = prompt;
			if (key == null) {
				key = getAccessibleContext().getAccessibleName();
			}
			if (key == null) {
				key = "????";
			}
			MyClipboard.mMyClipboard.add(new MyClipboard.MyEntry(key, text));
		}
	}

	// //////////////////////////////////////////////////////////////////////////
	// Handle mouse events on the button (listval button)
	
    public void mouseClicked(MouseEvent e) {
    	if (button.isEnabled()) {
    		// The requestFocus() in the mousePressed method might have
    		// been denied by forms
        	if (hasGlobalFocus()) {
        		KeyEvent keyEvent = KeyBinder.getKeySequence(FormAction.FA_LIST_OF_VALUES);
        		/*
        		ComponentItem handler = (ComponentItem)getHandler();
        		handler.keyPressedImpl(keyEvent);
				*/
	    		dispatchEvent(new KeyEvent(this, KeyEvent.KEY_PRESSED,
	    				System.currentTimeMillis(), keyEvent.getModifiers(), keyEvent.getKeyCode(),
	    				KeyEvent.CHAR_UNDEFINED));
	    		dispatchEvent(new KeyEvent(this, KeyEvent.KEY_RELEASED,
	    				System.currentTimeMillis(), keyEvent.getModifiers(), keyEvent.getKeyCode(),
	    				KeyEvent.CHAR_UNDEFINED));

				e.consume();
        	}
    	}
    }

    public void mousePressed(MouseEvent e) {
    	if (button.isEnabled() && !hasGlobalFocus()) {
    		requestFocus();
    	}
		e.consume();
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void keyPressed(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}
}