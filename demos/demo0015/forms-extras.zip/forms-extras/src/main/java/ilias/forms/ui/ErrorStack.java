package ilias.forms.ui;

import ilias.forms.ui.ErrorBox.ErrorData;

import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventListener;
import java.util.Vector;

import oracle.ewt.button.PushButton;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.NullPainter;
import oracle.ewt.timer.Timer;

public class ErrorStack extends LWComponent implements Runnable {

	private static final long serialVersionUID = -616260118909467181L;

	private int boxWidth = 300;
	private long timerDelay = 10000L;
	private long timerPeriod = 900L;
	private Vector<ErrorBox> stack = new Vector<ErrorBox>();
	private Timer timer = null;
	private Vector<ClickListener> _clickListeners;
	private Vector<ButtonClickListener> _buttonListeners;
	private PushButton closeButton;
	private boolean cleanupFlag = false;
	
	public static interface ClickListener extends EventListener {
	    public void onClick(ActionEvent e);
	}

	public static interface ButtonClickListener extends EventListener {
	    public void onButtonClick(ActionEvent e);
	}

	public ErrorStack() {
		setBounds(0, 0, 0, 0);
		closeButton = new PushButton("Close");
		closeButton.setFocusable(false);
		closeButton.setVisible(false);
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cleanup();
			}
		});
		add(closeButton);
	}

	public void setBoxWidth(int width) {
		boxWidth = width;
	}

	public void setTimerDelay(int delay) {
		timerDelay = 1000L * delay;
	}

	public void addClickListener(ClickListener listener) {
		if (_clickListeners == null) {
			_clickListeners = new Vector<ClickListener>(1);
		}
		_clickListeners.addElement(listener);
	}

	public void removeClickListener(ClickListener listener) {
		if (_clickListeners != null) {
			_clickListeners.removeElement(listener);
		}
	}

	public void addButtonListener(ButtonClickListener listener) {
		if (_buttonListeners == null) {
			_buttonListeners = new Vector<ButtonClickListener>(1);
		}
		_buttonListeners.addElement(listener);
	}

	public void removeButtonListener(ButtonClickListener listener) {
		if (_buttonListeners != null) {
			_buttonListeners.removeElement(listener);
		}
	}

	/**
	 * Add an error message
	 * 
	 * @param text
	 */
	public void addError(String text) {
		addStack(text, ErrorBox.ERROR);
	}

	/**
	 * Add a warning message
	 * 
	 * @param text
	 */
	public void addWarning(String text) {
		addStack(text, ErrorBox.WARNING);
	}

	/**
	 * Add an info message
	 * 
	 * @param text
	 */
	public void addInfo(String text) {
		addStack(text, ErrorBox.INFO);
	}
	
	private void addStack(String text, int type) {
		if (stack.size() > 0) {
			ErrorBox last = stack.lastElement();
			ErrorData errorData = ErrorBox.parseText(text, type);
			if (last.getType() == type
					&& last.getErrorTitle().equals(errorData.errorTitle)
					&& last.getErrorText().equals(errorData.errorText)) {
				last.increment();
				last.setErrorId(errorData.errorId);
				// Redraw
				getParent().validate();
				return;
			}
		}
		// Create an Error Box
		ErrorBox textBox = new ErrorBox(text, type) {
			private static final long serialVersionUID = -8542636000455711853L;
			@Override
			protected void onClick() {
				if (_clickListeners != null) {
					ClickListener listener = _clickListeners.lastElement();
					ActionEvent action = new ActionEvent(ErrorStack.this, ActionEvent.ACTION_PERFORMED, getErrorId());
					listener.onClick(action);
				}
			}
			@Override
			protected void onButtonClick() {
				if (_buttonListeners != null) {
					ButtonClickListener listener = _buttonListeners.lastElement();
					ActionEvent action = new ActionEvent(ErrorStack.this, ActionEvent.ACTION_PERFORMED, getErrorId());
					listener.onButtonClick(action);
				}
			}
		};
		textBox.setBounds(0, 0, boxWidth, 100);
		textBox.doLayout();
		int height = textBox.calcHeight();
		textBox.setBounds(0, 0, boxWidth, height);
		textBox.doLayout();
		
		// Add to stack and this container
		stack.add(textBox);
		add(textBox);

		closeButton.setVisible(true);

		// Redraw
		getParent().validate();

		// Start timer
		startTimer();
	}

	public void layoutContainer(Container parent) {
		int w = 0;
		int h = 0;
		int pw = parent.getWidth();
		int ph = parent.getHeight();
		int n = stack.size();
		if (n > 0) {
			w += boxWidth;
			int y = 27;	// Leave room for button
			int[] xPos = new int[n];
			int[] yPos = new int[n];
			int i = 0;
			for(ErrorBox textBox : stack) {
				if (y + 2 + textBox.getHeight() > ph) {
					// Overflow, start new column
					w += boxWidth + 2;
					y = 0;
				}
				y += 2;
				xPos[i] = w;
				y += textBox.getHeight();
				yPos[i] = y;
				h = Math.max(h, y);
				i++;
			}
			i = 0;
			for(ErrorBox textBox : stack) {
				textBox.setLocation(w - xPos[i], h - yPos[i]);
				i++;
			}
			closeButton.setBounds(w - boxWidth, h - 27, boxWidth, 25);
		}
		setBounds(pw - w, ph - h, w, h);
	}

	private void startTimer() {
		if (timer == null) {
			timer = new Timer(this, timerPeriod);
		} else {
			timer.schedule(timerPeriod);
		}
	}

	public void run() {
		//System.out.println("timer tick");
		boolean changed = false;
		synchronized(stack) {
			long now = System.currentTimeMillis();
			ErrorBox[] arr = stack.toArray(new ErrorBox[stack.size()]);
			for(ErrorBox box : arr) {
				if (cleanupFlag || now - box.getTimestamp() >= timerDelay) {
					stack.remove(box);
					remove(box);
					changed = true;
				}
			}
			if (stack.size() <= 0) {
				closeButton.setVisible(false);
				if (timer != null) {
					timer.cancel();
					timer = null;
				}
			} else {
				startTimer();
			}
		}
		if (changed) {
			Container parent = getParent();
			if (parent != null) {
				parent.validate();
			}
		}
	}

	public void cleanup() {
		try {
			cleanupFlag = true;
			run();
		} finally {
			cleanupFlag = false;
		}
	}

	@Override
    public final void repaint(long when, int x, int y, int w, int h) {
		// Transparent
    }
	
	@Override
	public BorderPainter getBorderPainter() {
		return NullPainter.getPainter();
	}
	
	@Override
	public void paintInterior(Graphics g) {
		// Transparent
	}
}
