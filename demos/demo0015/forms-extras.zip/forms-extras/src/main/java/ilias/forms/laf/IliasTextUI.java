package ilias.forms.laf;

import java.awt.Cursor;

import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.lwAWT.lwText.LWTextComponent;
import oracle.ewt.plaf.TextUI;

public abstract class IliasTextUI extends BasicComponentUI implements TextUI {
	protected IliasTextUI(LWComponent comp) {
		super(comp);
	}

	@Override
	public void installUI(LWComponent comp) {
		comp.setCursor(Cursor.getPredefinedCursor(2));
	}

	public Cursor getCursor(LWComponent comp) {
		if (comp instanceof LWTextComponent
				&& ((LWTextComponent) comp).isFocusable()) {
			return Cursor.getPredefinedCursor(2);
		}
		return Cursor.getDefaultCursor();
	}
}