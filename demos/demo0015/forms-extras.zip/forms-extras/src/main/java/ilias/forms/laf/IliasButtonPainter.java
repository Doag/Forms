package ilias.forms.laf;

import java.awt.Color;
import java.awt.Graphics;

import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.util.ImmInsets;

public class IliasButtonPainter extends AbstractBorderPainter {
	private static final ImmInsets _INSETS = new ImmInsets(4, 4, 4, 4);
	private static final ImmInsets _FILL_INSETS = new ImmInsets(1, 1, 1, 1);
	private static final ImmInsets _FILL_INSETS_FOCUSED = new ImmInsets(2, 2, 2, 2);

	public IliasButtonPainter() {
	}

	public IliasButtonPainter(Painter wrapped) {
		super(wrapped);
	}

	protected ImmInsets getOwnInsets(PaintContext ctx) {
		// Padding 
		return _INSETS;
	}

	protected ImmInsets getOwnFillInsets(PaintContext ctx) {
		int state = ctx.getPaintState();
		if ((state & PaintContext.STATE_FOCUSED) != 0) {
			return _FILL_INSETS_FOCUSED;
		} else {
			return _FILL_INSETS;
		}
	}

	protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		// Save color
		Color oldColor = g.getColor();

		w--;
		h--;

		int state = ctx.getPaintState();
		if ((state & PaintContext.STATE_FOCUSED) != 0) {
			g.setColor(IliasLookAndFeel.FOCUS_COLOR);
			g.drawRect(x, y, w, h);
			x++;
			y++;
			w-=2;
			h-=2;
		}
		g.setColor(IliasLookAndFeel.BORDER_COLOR);
		g.drawRect(x, y, w, h);

		// Restore color
		g.setColor(oldColor);
	}

	public int getRepaintFlags(PaintContext ctx) {
		return super.getRepaintFlags(ctx) | PaintContext.STATE_FOCUSED | 0x400;
	}

	protected boolean isBorderTransparent(PaintContext ctx) {
		return true;
	}
}
