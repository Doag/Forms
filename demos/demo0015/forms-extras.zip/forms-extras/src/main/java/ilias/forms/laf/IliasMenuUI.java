package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericMenuUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasMenuUI extends GenericMenuUI {
	public IliasMenuUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}