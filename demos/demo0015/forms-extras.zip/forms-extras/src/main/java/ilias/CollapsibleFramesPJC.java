package ilias;

import ilias.forms.vgs.IliasDisplayFrame;
import ilias.oracle.forms.engine.FormsMain;
import oracle.forms.properties.ID;
import oracle.forms.ui.CustomEvent;
import oracle.forms.ui.VBean;

public class CollapsibleFramesPJC extends VBean {

	private static final long serialVersionUID = 6538367938922910480L;

	private static final ID FORM_NAME = ID.registerProperty("FORM_NAME");
	private static final ID FRAME_NAME = ID.registerProperty("FRAME_NAME");
	private static final ID FRAME_STATE = ID.registerProperty("FRAME_STATE");

	private String mFormName;
	
	public CollapsibleFramesPJC() {
		super();
	}
	
	public String getFormName() {
		return mFormName;
	}

	public boolean setProperty(ID pid, Object value) {
		if (pid == FORM_NAME) {
			mFormName = (String)value;
			FormsMain main = (FormsMain) getHandler().getApplet();
			main.registerCollapsibleFramesBean(this);
			return true;
		} else if (pid == FRAME_STATE) {
			String[] args = ((String)value).split(":");
			FormsMain main = (FormsMain) getHandler().getApplet();
			IliasDisplayFrame frame = main.getCollapsibleFrame(mFormName, args[0]);
			if (frame != null) {
				frame.setCollapsed("C".equals(args[1]));
			}
			return true;
		}
		return super.setProperty(pid, value);
	}
	
	@Override
	public void destroy() {
		if (mFormName != null) {
			FormsMain main = (FormsMain) getHandler().getApplet();
			main.unregisterCollapsibleFramesBean(this);
			mFormName = null;
		}
		super.destroy();
	}

	public void updateFrameState(IliasDisplayFrame frame) {
		CustomEvent event = new CustomEvent(getHandler(), FRAME_STATE);
		event.setProperty(FORM_NAME, frame.getFormName());
		event.setProperty(FRAME_NAME, frame.getFrameName());
		event.setProperty(FRAME_STATE, frame.isCollapsed() ? "C" : "O");
		dispatchCustomEvent(event);
	}
}