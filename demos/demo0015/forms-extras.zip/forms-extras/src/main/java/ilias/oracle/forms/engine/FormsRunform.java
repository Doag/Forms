package ilias.oracle.forms.engine;

import ilias.forms.handler.IliasFormStatusBar;
import oracle.forms.engine.Main;
import oracle.forms.engine.Registry;
import oracle.forms.engine.Runform;
import oracle.forms.handler.FormStatusBar;
import oracle.forms.ui.mdi.MDIContainer;

public class FormsRunform extends Runform {

	private IliasFormStatusBar mStatusBar = null;

	protected FormsRunform(Main main, Runform runform) {
		super(main, runform);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	/**
	 * (We do not want a status bar) We want our own version of the status bar
	 * 
	 * Note: there is only ONE status bar instance per runform instance
	 */
	@Override
	public void setCurrentStatusBar(FormStatusBar statusBar) {
		// super.setCurrentStatusBar(statusBar);
		if (mStatusBar != statusBar) {
			mStatusBar = (IliasFormStatusBar) statusBar;
			if (!isSDIMode()) {
				MDIContainer mdi = getApplet().getMDIContainer();
				if (statusBar != null) {
					mdi.setDefaultStatusBar(mStatusBar.getStatusBar());
				} else {
					mdi.setDefaultStatusBar(null);
				}
			}
		}
	}

	/**
	 * Override the default handlers here
	 */
	protected void sendInitialMessage() throws Exception {

		System.out.println("Overruling registry handler classes");

		Registry registry = getRegistry();

		registry.updateEntry("oracle.classById", "4",
				"ilias.forms.handler.IliasFormWindow");
		registry.updateEntry("oracle.classById", "6",
				"ilias.forms.handler.IliasDisplayList");
		registry.updateEntry("oracle.classById", "11",
				"ilias.forms.handler.IliasHelpDialog");
		registry.updateEntry("oracle.classById", "12",
				"ilias.forms.handler.IliasFormStatusBar");
		registry.updateEntry("oracle.classById", "17",
				"ilias.forms.handler.IliasPromptListItem");
		registry.updateEntry("oracle.classById", "257",
				"ilias.forms.handler.IliasTextFieldItem");
		registry.updateEntry("oracle.classById", "258",
				"ilias.forms.handler.IliasTextAreaItem");
		registry.updateEntry("oracle.classById", "259",
				"ilias.forms.handler.IliasFormCanvas");
		registry.updateEntry("oracle.classById", "261",
				"ilias.forms.handler.IliasButtonItem");
		registry.updateEntry("oracle.classById", "262",
				"ilias.forms.handler.IliasCheckboxItem");
		registry.updateEntry("oracle.classById", "263",
				"ilias.forms.handler.IliasPopListItem");
		registry.updateEntry("oracle.classById", "264",
				"ilias.forms.handler.IliasTListItem");
		registry.updateEntry("oracle.classById", "267",
				"ilias.forms.handler.IliasRadioButtonItem");
		registry.updateEntry("oracle.classById", "268",
				"ilias.forms.handler.IliasImageItem");
		registry.updateEntry("oracle.classById", "270",
				"ilias.forms.handler.IliasBlockScroller");
		registry.updateEntry("oracle.classById", "271",
				"ilias.forms.handler.IliasJavaContainer");
		registry.updateEntry("oracle.classById", "272",
				"ilias.forms.handler.IliasTabControl");
		registry.updateEntry("oracle.classById", "273",
				"ilias.forms.handler.IliasComboBoxItem");
		registry.updateEntry("oracle.classById", "274",
				"ilias.forms.handler.IliasTreeItem");

		registry.updateEntry("app.ui", "lovButtons", "true");

		super.sendInitialMessage();
	}
}
