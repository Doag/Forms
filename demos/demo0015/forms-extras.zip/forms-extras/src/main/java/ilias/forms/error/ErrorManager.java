package ilias.forms.error;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import oracle.ewt.popup.AbstractToolTip;
import oracle.ewt.popup.PopupOwner;
import oracle.ewt.popup.PopupUtils;
import oracle.ewt.popup.ToolTip;
import oracle.ewt.popup.ToolTipSite;
import oracle.ewt.thread.Task;
import oracle.ewt.thread.TaskEvent;
import oracle.ewt.thread.TaskScheduler;

public class ErrorManager {
	private PopupOwner _owner;
	private Component _over;
	private ToolTip _currentTip;
	private ToolTipSite _site;
	private final MouseLsnr _mouselsnr = new MouseLsnr();
	private Task _task;
	private Point _lastPoint;
	private int _delay = 500;
	private static final int _INITIAL_DELAY = 500;
	private static final int _BROWSE_DELAY = 20;
	private static final int _CURSOR_SIZE = 18;
	private static final int[] _sDefaultAlignments = { 2, 17, 22, 1, 16, 21, 10, 5 };
	private static ErrorManager _sErrorManager;

	public static ErrorManager getErrorManager() {
		if (_sErrorManager == null) {
			_sErrorManager = new ErrorManager();
		}
		return _sErrorManager;
	}

	public void registerComponent(Component component) {
		component.addMouseListener(_mouselsnr);
	}

	public void unregisterComponent(Component component) {
		component.removeMouseListener(_mouselsnr);
	}

	public synchronized void show(Component component) {
		show(component, 0, 0);
	}

	public synchronized void show(Component component, int x, int y) {
		enter(component);
		_lastPoint = new Point(x, y);
		schedule();
	}

	public synchronized void enter(Component component) {
		if (_over != null) {
			leave(_over);
		}
		_task = new Tsk();
		String error = null;
		if ((component instanceof ErrorComponent)) {
			error = ((ErrorComponent) component).getErrorString();
		}
		if (error == null) {
			_site = null;
		} else {
			_site = new ToolTipSite(error, null);
		}
		_over = component;
		component.addMouseMotionListener(_mouselsnr);
	}

	public synchronized void hide() {
		PopupOwner localPopupOwner = _owner;
		if (_task != null) {
			TaskScheduler.getDefaultTaskScheduler().cancel(_task);
		}
		_owner = null;
		if (localPopupOwner != null) {
			localPopupOwner.removePopup((Component) _currentTip);
		}
	}

	protected synchronized void schedule() {
		if (_owner == null) {
			TaskScheduler.getDefaultTaskScheduler()
					.schedule(_task, _getDelay());
		}
	}

	protected synchronized void cancel() {
		PopupOwner localPopupOwner = this._owner;
		if (_task != null) {
			TaskScheduler.getDefaultTaskScheduler().cancel(_task);
		}
		_owner = null;
		if (localPopupOwner != null) {
			localPopupOwner.removePopup((Component) _currentTip);
		}
		_site = null;
	}

	synchronized void _showToolTip(Task task) {
		if (task != _task) {
			return;
		}
		if (_over == null) {
			return;
		}
		_delay = _BROWSE_DELAY;
		int x = _lastPoint.x;
		int y = _lastPoint.y;

		if (_site != null && _over.isShowing()) {
			ToolTip toolTip = LabelErrorTip.getToolTip();
			toolTip.setToolTipValue(_site.getValue());
			_currentTip = toolTip;

			Rectangle rect = _over.getBounds();
			rect.x = rect.y = 0;
			rect.add(new Rectangle(x, y, _CURSOR_SIZE, _CURSOR_SIZE));

			AbstractToolTip popup = (AbstractToolTip) toolTip;
			popup.setBackground(Color.RED);
			Dimension dim = popup.getPreferredSize();
			PopupOwner owner = PopupUtils.displayPopupRelativeTo(_over, popup,
					rect, dim, dim, 2);
			if (owner == null) {
				toolTip = MLLabelErrorTip.getToolTip();
				toolTip.setToolTipValue(_site.getValue());
				_currentTip = toolTip;
				popup = (AbstractToolTip) toolTip;
				popup.setBackground(Color.RED);
				owner = PopupUtils.displayPopupRelativeTo(_over, popup, rect,
						null, _sDefaultAlignments);
			}
			_owner = owner;
		}
	}

	private int _getDelay() {
		return _delay;
	}

	public void leave(Component component) {
		if (_over == component) {
			synchronized (this) {
				if (_over == component) {
					cancel();
					_over.removeMouseMotionListener(_mouselsnr);
					_over = null;
					_delay = _INITIAL_DELAY;
				}
			}
		}
	}

	void moved(int x, int y) {
		synchronized (this) {
			if (_site != null) {
				if (!_site.contains(x, y)) {
					cancel();
				}
				_task = new Tsk();
			}
		}
		_lastPoint = new Point(x, y);
		schedule();
	}

	private class MouseLsnr extends MouseAdapter implements MouseMotionListener {
		public void mousePressed(MouseEvent e) {
			cancel();
		}

		public void mouseEntered(MouseEvent e) {
			enter((Component) e.getSource());
		}

		public void mouseExited(MouseEvent e) {
			leave(e.getComponent());
		}

		public void mouseDragged(MouseEvent e) {
		}

		public void mouseMoved(MouseEvent e) {
			moved(e.getX(), e.getY());
		}
	}

	private class Tsk implements Task {
		public void runTask(TaskEvent paramTaskEvent) {
			_showToolTip(this);
		}
	}
}
