package ilias.forms.laf;

import oracle.ewt.lwAWT.LWComponent;

public class IliasTextAreaUI extends IliasTextUI {

	public IliasTextAreaUI(LWComponent component) {
		super(component);
	}
}