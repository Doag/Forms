package ilias.forms.laf;

import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AlignmentPainter;
import oracle.ewt.painter.DirectionalBorderPainter;
import oracle.ewt.painter.Painter;
import oracle.ewt.painter.PainterJoiner;
import oracle.ewt.plaf.ToggleButtonUI;

public abstract class IliasToggleButtonUI extends BasicComponentUI implements
		ToggleButtonUI {

	protected static final int IMAGESTRIP_MASK = 11;

	public IliasToggleButtonUI(LWComponent comp) {
		super(comp);
	}

	public Painter getPainter(LWComponent comp) {
		UIDefaults defaults = getUIDefaults(comp);
		return defaults.getPainter(getComponentPainterKeyName());
	}

	protected static Painter createComponentPainter(UIDefaults defaults, Painter painter) {
		// Painter for the text
		Painter text = defaults.getPainter(IliasLookAndFeel.DEFAULT_TEXT_PAINTER);
		// Add border
		text = new DirectionalBorderPainter(text, 0, 2, 0, 0, false);
		// Painter for the image / image set
		Painter image = defaults.getPainter(LookAndFeel.IMAGE_SET_PAINTER);
		// Add border
		image = new DirectionalBorderPainter(image, 0, 2, 0, 0, false);
		Painter textAndImage = new PainterJoiner(image, text, 13); 
		return new AlignmentPainter(new PainterJoiner(painter, textAndImage, 13));
	}

	protected abstract String getPainterKeyName();

	protected abstract String getComponentPainterKeyName();
}