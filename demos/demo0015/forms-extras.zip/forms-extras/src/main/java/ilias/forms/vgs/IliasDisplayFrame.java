package ilias.forms.vgs;

import ilias.CollapsibleFramesPJC;
import ilias.forms.handler.IliasFormCanvas;
import ilias.forms.handler.IliasPromptItem;
import ilias.oracle.forms.engine.FormsMain;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import oracle.ewt.button.PushButton;
import oracle.graphics.vgs.ui.Device;
import oracle.graphics.vgs.ui.Frame;
import oracle.graphics.vgs.ui.PackedTree;
import oracle.graphics.vgs.ui.Text;

public class IliasDisplayFrame extends Frame {
	
	static final Image UP = loadImage("/icons/up_16.gif");
	static final Image DOWN = loadImage("/icons/down_16.gif");
    static final int BUTTON_WIDTH = 24;
    static final int BUTTON_HEIGHT = 18;
	
    static class ComponentInFrame implements PropertyChangeListener {
        private Component c;
        private int y;
        private boolean serverVisible;
        public ComponentInFrame(Component c, int y) {
            this.c = c;
            this.y = y;
            this.serverVisible = c.isVisible();
            c.addPropertyChangeListener("serverVisible", this);
        }
        
        public Component getC() {
            return c;
        }

        public int getY() {
            return y;
        }

        public boolean isServerVisible() {
            return serverVisible;
        }

        public void propertyChange(PropertyChangeEvent e) {
            serverVisible = c.isVisible();
        }
	}

	private IliasDisplayGroup mGroup;
	private IliasFormCanvas mFormCanvas;
	private PushButton mButton = null;
	private boolean mCollapsed = false;
	private boolean mCollapsible = false;
    private String mFormName = null;
    private String mFrameName = null;
	private List<ComponentInFrame> mComponentsInFrame;
    private List<IliasPromptItem> mPromptsInFrame;
    private int buttonWidth = BUTTON_WIDTH;
    private int buttonHeight = BUTTON_HEIGHT;

	public IliasDisplayFrame(boolean highContrast, IliasDisplayGroup group, IliasFormCanvas canvas) {
		super(highContrast);
	    mGroup = group;
	    mFormCanvas = canvas;
	}

    public synchronized void onDestroy() {
        if (mFormName != null && mFrameName != null) {
            FormsMain main = (FormsMain) mFormCanvas.getApplet();
            main.unregisterCollapsibleFrame(this);
        }
        mFormCanvas = null;
    }

	public boolean isCollapsed() {
		return mCollapsed;
	}

	public boolean isCollapsible() {
		return mCollapsible;
	}

	@Override
	public String getName() {
        if (mFrameName == null) {
			return super.getName();
		} else {
            return mFrameName;
		}
	}

    public String getFormName() {
        return mFormName;
    }

    public String getFrameName() {
        return mFrameName;
    }

	public List<ComponentInFrame> getComponentsInFrame() {
		return mComponentsInFrame;
	}
    
    public List<IliasPromptItem> getPromptsInFrame() {
        return mPromptsInFrame;
    }

    public void setCollapsed(boolean collapsed) {
        if (mCollapsible) {
            if (mCollapsed != collapsed) {
                mCollapsed = collapsed;
                setButtonImage();
                mGroup.invalidateLayout();
            }
        }
    }

	@Override
	public int pUnpack(PackedTree tree, DataInputStream stream) throws IOException {
		int result = super.pUnpack(tree, stream);
		
		try {
			Field labelField = Frame.class.getDeclaredField("mLabel");
			labelField.setAccessible(true);
			
			Text label = (Text)labelField.get(this);

			Field textLinesField = Text.class.getDeclaredField("mTextLines");
			textLinesField.setAccessible(true);

			Object[] textLines = (Object[])textLinesField.get(label);
			if (textLines.length > 0) {
				Class<?> compoundText = Class.forName("oracle.graphics.vgs.ui.CompoundText");
				Field stringsField = compoundText.getDeclaredField("strings");
				stringsField.setAccessible(true);

				Class<?> simpleText = Class.forName("oracle.graphics.vgs.ui.SimpleText");
				Field textStringField = simpleText.getDeclaredField("textString");
				textStringField.setAccessible(true);
				
				for(Object textLine : textLines) {
					Object[] strings = (Object[])stringsField.get(textLine);
					for(Object string : strings) {
						String str = (String)textStringField.get(string);
						if (str.charAt(0) == '[') {
							int off = str.indexOf(']');
							if (off > 0) {
                                textStringField.set(string, str.substring(off+1));
								String[] elements = str.substring(1, off).split(",");
								mCollapsible = true;
								mCollapsed = "C".equals(elements[0]);
                                String[] names = elements[1].split("\\.");
                                mFormName = names[0];
                                mFrameName = names[1];
                                FormsMain main = (FormsMain) mFormCanvas.getApplet();
                                main.registerCollapsibleFrame(this);
								label.setDirty(true);
							}
						}
						break;
					}
				}
			}
			
		} catch (Exception e) {
		}

        // Collect the items on the canvas that this frame contains
        int scale = 100;
        int x = getX() * scale / 100;
        int y = getY() * scale / 100;
        int w = (getX() + getWidth()) * scale / 100 - x;
        int h = (getY() + getHeight()) * scale / 100 - y;
        Rectangle rect = new Rectangle(x, y, w, h);

        mComponentsInFrame = new ArrayList<ComponentInFrame>();
        for(Component c : mFormCanvas.getPanel().getComponents()) {
            Point topLeft = c.getLocation();
            if (rect.contains(topLeft)) {
                ComponentInFrame cif = new ComponentInFrame(c, c.getY() * 100 / scale);
                mComponentsInFrame.add(cif);
			}
        }

        if (mFormCanvas.getPromptListItem() != null) {
            mPromptsInFrame = mFormCanvas.getPromptListItem().getPromptsInRect(rect);
        }
        
        // Create a collapse/show button
        if (mCollapsible) {
		    mButton = new PushButton();
		    mButton.setImage(mCollapsed ? DOWN : UP);
			mButton.setFocusable(false);
			mButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					mCollapsed = !mCollapsed;
                    setButtonImage();
					mGroup.invalidateLayout();
                    FormsMain main = (FormsMain) mFormCanvas.getApplet();
                    CollapsibleFramesPJC bean = main.getCollapsibleFramesBean(mFormName);
                    if (bean != null) {
                        bean.updateFrameState(IliasDisplayFrame.this);
                    }
				}
			});
			mFormCanvas.getPanel().add(mButton);
		}

		return result;
	}

	@Override
	public void recalc(Graphics g, Device device) {
		super.recalc(g, device);
		if (mButton != null) {
            mButton.setSize(buttonWidth, buttonHeight);
            mButton.setLocation(getX() + getWidth() - mButton.getWidth() + 1, getY());
		}
	}

	@Override
	public void listProperties(PrintStream paramPrintStream, String paramString) {
		super.listProperties(paramPrintStream, paramString);
	}

	private static Image loadImage(String name) {
		InputStream in = IliasDisplayFrame.class.getResourceAsStream(name);
		try {
			int n = in.available();
			byte[] bytes = new byte[n];
			int o = 0;
			while((o+=in.read(bytes,o,n-o))<n);
			in.close();
			return Toolkit.getDefaultToolkit().createImage(bytes);
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
    
    public void rescale(int scale) {
        buttonWidth = BUTTON_WIDTH * scale / 100;
        buttonHeight = BUTTON_HEIGHT * scale / 100;
        setButtonImage();
    }

    private void setButtonImage() {
        if (mButton != null) {
            int scale = 100;
            Image image = mCollapsed ? DOWN : UP;
            if (scale != 100) {
                int iw = 16;// image.getWidth(null);
                image = image.getScaledInstance(iw * scale / 100, -1, Image.SCALE_AREA_AVERAGING);
            }
            mButton.setImage(image);
        }
    }
}