package ilias.forms.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseEvent;

import javax.swing.SwingUtilities;

import oracle.ewt.util.InputEventUtils;
import oracle.forms.handler.IHandler;
import oracle.forms.handler.UICommon;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTextField;

public class VFrameTitle extends VTextField {

	private static final long serialVersionUID = -7472126964492055626L;

	private Color mFrameBackgroundColor = null;

	@Override
	public void init(IHandler handler) {
		super.init(handler);
		String frameBackgroundColor = handler.getApplet().getParameter("FrameBackgroundColor");
		if (frameBackgroundColor != null && frameBackgroundColor.trim().equals("") ) {
			frameBackgroundColor = null;
		}
		if (frameBackgroundColor != null) {
			if (handler instanceof UICommon) {
				try {
					short color = Short.parseShort(frameBackgroundColor);
					UICommon uicommon = (UICommon) handler;
					mFrameBackgroundColor = uicommon.getDispatcher().getColorEntry(color);
					setBackground(mFrameBackgroundColor);
				} catch(NumberFormatException e) {
					// Ignore
				}
			}
		}
	}

	@Override
	public boolean setProperty(ID paramID, Object paramObject) {
		switch (paramID.toID()) {
		case ID.INDEX_BACKGROUND:
			if (mFrameBackgroundColor == null) {
				return super.setProperty(paramID, paramObject);
			} else {
				// Ignore background setting
				return true;
			}
		default:
			return super.setProperty(paramID, paramObject);
		}
	}

	@Override
	protected void processMouseEvent(MouseEvent e) {
		if (InputEventUtils.isRightMouseButton(e) && e.getID() == MouseEvent.MOUSE_PRESSED) {
			retarget(e);
			e.consume();
		} else {
			super.processMouseEvent(e);
		}
	}

	private void retarget(MouseEvent event) {
		Component target = getParent();
		if (target != null) {
			Point point = event.getPoint();
			SwingUtilities.convertPointToScreen(point, this);
			SwingUtilities.convertPointFromScreen(point, target);
	
			MouseEvent nextEvent = new MouseEvent(target, event.getID(),
					event.getWhen(), event.getModifiers() | event.getModifiersEx(), point.x, point.y,
					event.getClickCount(),
					event.isPopupTrigger(), event.getButton());
	
			target.dispatchEvent(nextEvent);
		}
	}
}
