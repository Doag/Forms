package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericArrowBoxUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasArrowBoxUI extends GenericArrowBoxUI {
	public IliasArrowBoxUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}
