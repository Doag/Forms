package ilias.forms.ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.LayoutManager2;
import java.awt.Rectangle;

public class ErrorStackLayout implements LayoutManager2 {

	  private boolean _dontInvalidate;
	  private LayoutManager _wrappedLayout;
	  private ErrorStack _errorStack;

	public ErrorStackLayout(LayoutManager wrapped, ErrorStack errorStack) {
		_wrappedLayout = wrapped;
		_errorStack = errorStack;
	}

	public boolean shouldInvalidate() {
		return !_dontInvalidate;
	}

	public void addLayoutComponent(String name, Component comp) {
	    if (comp != _errorStack && _wrappedLayout != null) {
	        _wrappedLayout.addLayoutComponent(name, comp);
	    }
	}

	public void removeLayoutComponent(Component comp) {
	    if (_wrappedLayout != null) {
	        _wrappedLayout.removeLayoutComponent(comp);
	    }
	}

	public Dimension preferredLayoutSize(Container parent) {
		if (_wrappedLayout != null) {
			ErrorStack old = removeErrorStack(parent);
			Dimension size = _wrappedLayout.preferredLayoutSize(parent);
			if (old != null) {
				showErrorStack(parent, old);
			}
			return size;
		}
		return parent.getSize();
	}

	public Dimension minimumLayoutSize(Container parent) {
		if (_wrappedLayout != null) {
			ErrorStack old = removeErrorStack(parent);
			Dimension size = _wrappedLayout.minimumLayoutSize(parent);
			if (old != null) {
				showErrorStack(parent, old);
			}
			return size;
		}
		return new Dimension(0, 0);
	}

	public Dimension maximumLayoutSize(Container target) {
		if (_wrappedLayout instanceof LayoutManager2) {
			ErrorStack old = removeErrorStack(target);
			Dimension size = ((LayoutManager2) _wrappedLayout)
					.maximumLayoutSize(target);
			if (old != null) {
				showErrorStack(target, old);
			}
			return size;
		}
		return new Dimension(32767, 32767);
	}

	public void layoutContainer(Container parent) {
		if (_wrappedLayout != null) {
			ErrorStack old = removeErrorStack(parent);
			_wrappedLayout.layoutContainer(parent);
			if (old != null) {
				old.layoutContainer(parent);
				showErrorStack(parent, old);
			}
		}
	}

	public void addLayoutComponent(Component comp, Object constraints) {
		if (comp != _errorStack && _wrappedLayout != null) {
			if (_wrappedLayout instanceof LayoutManager2) {
				((LayoutManager2) _wrappedLayout).addLayoutComponent(comp,
						constraints);
			} else {
				addLayoutComponent((String) constraints, comp);
			}
		}
	}

	public float getLayoutAlignmentX(Container target) {
		if (_wrappedLayout instanceof LayoutManager2) {
			return ((LayoutManager2) _wrappedLayout)
					.getLayoutAlignmentX(target);
		}
		return 0.5F;
	}

	public float getLayoutAlignmentY(Container target) {
		if (_wrappedLayout instanceof LayoutManager2) {
			return ((LayoutManager2) _wrappedLayout)
					.getLayoutAlignmentY(target);
		}
		return 0.5F;
	}

	public void invalidateLayout(Container target) {
		if (_wrappedLayout instanceof LayoutManager2) {
			((LayoutManager2) _wrappedLayout).invalidateLayout(target);
		}
	}

	private ErrorStack removeErrorStack(Container parent) {
		if (_errorStack != null) {
			synchronized (parent.getTreeLock()) {
				synchronized (this) {
					if (_errorStack.getParent() == parent) {
						_dontInvalidate = true;
						parent.remove(_errorStack);
						_dontInvalidate = false;
						if (_errorStack.isVisible()) {
							return _errorStack;
						}
					}
				}
			}
		}
		return null;
	}

	public void showErrorStack(Container parent, ErrorStack comp) {
		if (comp == null) {
			return;
		}
		synchronized (parent.getTreeLock()) {
			synchronized (this) {
				_dontInvalidate = true;
				if (parent.getComponent(0) != comp) {
					parent.add(comp, 0);
				}
				Dimension parentSize = parent.getSize();
				Rectangle compSize = comp.getBounds();
				comp.setVisible(false);
				int x = parentSize.width - compSize.width;
				int y = parentSize.height - compSize.height;
				comp.setBounds(x, y, compSize.width, compSize.height);
				comp.setVisible(true);
				_dontInvalidate = false;
			}
		}
	}
}
