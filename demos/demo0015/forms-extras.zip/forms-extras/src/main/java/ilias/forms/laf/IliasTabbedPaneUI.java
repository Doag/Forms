package ilias.forms.laf;

import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.plaf.TabbedPaneUI;
import oracle.ewt.tabPanel.TabPanel;

public class IliasTabbedPaneUI extends BasicComponentUI implements TabbedPaneUI {

	private static BorderPainter topBorderPainter;
	private static BorderPainter bottomBorderPainter;
	private static BorderPainter leftBorderPainter;
	private static BorderPainter rightBorderPainter;
	
	public IliasTabbedPaneUI(LWComponent component) {
		super(component);
	}

	public BorderPainter getSheetBorderPainter(LWComponent panel) {
		TabPanel tabPanel = (TabPanel) panel;
		if (tabPanel.getOrientation() == TabPanel.TOP)
			return _getTopBorderPainter();
		if (tabPanel.getOrientation() == TabPanel.BOTTOM)
			return _getBottomBorderPainter();
		if (tabPanel.getOrientation() == TabPanel.LEFT)
			return _getLeftBorderPainter();
		return _getRightBorderPainter();
		// return NullPainter.getPainter();
	}

	private BorderPainter _getTopBorderPainter() {
		if (topBorderPainter == null) {
			topBorderPainter = new TabbedPaneBorderPainter(
					TabbedPaneBorderPainter.TOP);
		}
		return topBorderPainter;
	}

	private BorderPainter _getBottomBorderPainter() {
		if (bottomBorderPainter == null) {
			bottomBorderPainter = new TabbedPaneBorderPainter(
					TabbedPaneBorderPainter.BOTTOM);
		}
		return bottomBorderPainter;
	}

	private BorderPainter _getLeftBorderPainter() {
		if (leftBorderPainter == null) {
			leftBorderPainter = new TabbedPaneBorderPainter(
					TabbedPaneBorderPainter.LEFT);
		}
		return leftBorderPainter;
	}

	private BorderPainter _getRightBorderPainter() {
		if (rightBorderPainter == null) {
			rightBorderPainter = new TabbedPaneBorderPainter(
					TabbedPaneBorderPainter.RIGHT);
		}
		return rightBorderPainter;
	}
}
