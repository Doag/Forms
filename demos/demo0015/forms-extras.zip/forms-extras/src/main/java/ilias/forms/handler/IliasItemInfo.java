package ilias.forms.handler;

import java.awt.Point;

public class IliasItemInfo {
	private int mItemIndex;
	private int mItemX;
	private int mItemY;
	private int mItemWidth;
	private int mItemHeight;

	public final int getItemX() {
		return this.mItemX;
	}

	public final int getItemY() {
		return this.mItemY;
	}

	public final int getItemWidth() {
		return this.mItemWidth;
	}

	public final int getItemHeight() {
		return this.mItemHeight;
	}

	public final int getItemIndex() {
		return this.mItemIndex;
	}

	public void setItemPosition(Point paramPoint) {
		this.mItemX = paramPoint.x;
		this.mItemY = paramPoint.y;
	}

	public void setItemSize(Point paramPoint) {
		this.mItemWidth = paramPoint.x;
		this.mItemHeight = paramPoint.y;
	}

	public void setItemIndex(int paramInt) {
		this.mItemIndex = paramInt;
	}
}