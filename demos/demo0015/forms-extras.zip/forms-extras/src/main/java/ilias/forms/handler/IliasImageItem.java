package ilias.forms.handler;

import oracle.forms.handler.ImageItem;

public class IliasImageItem extends ImageItem {
}
