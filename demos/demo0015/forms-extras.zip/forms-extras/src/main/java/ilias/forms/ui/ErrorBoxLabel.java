package ilias.forms.ui;

import java.awt.Font;
import java.awt.event.MouseEvent;

import oracle.ewt.lwAWT.LWLabel;

public class ErrorBoxLabel extends LWLabel {

	private static final long serialVersionUID = -6854850803157400158L;

	public ErrorBoxLabel(String text) {
		super(text);
		if (getFont() == null) {
			setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		Font bold = getFont().deriveFont(Font.BOLD);
		setFont(bold);
	}

	@Override
	protected void processMouseEvent(MouseEvent event) {
		if (event.getID() == MouseEvent.MOUSE_CLICKED) {
			onClick();
		}
		super.processMouseEvent(event);
	}

	protected void onClick() {
	}
}
