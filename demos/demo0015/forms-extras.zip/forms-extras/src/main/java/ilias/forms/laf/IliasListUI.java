package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericListUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasListUI extends GenericListUI {

	public IliasListUI(LWComponent component) {
		super(component);
	}
}