package ilias.forms.ui;

import ilias.forms.error.ErrorManager;
import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import oracle.ewt.button.PushButton;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.scrolling.scrollBox.ScrollBox;
import oracle.ewt.util.ImmInsets;
import oracle.forms.properties.BorderBevel;

public class TextComponentBorder implements ComponentListener, FocusListener {

	private TextBorderPainter borderPainter;
	private Component component;
	private String error = null;
	private PushButton button;

	public TextComponentBorder(Component component) {
		this.component = component;
		// Listen to 'move' and 'resize' events
		component.addComponentListener(this);
		// Listen to 'focus' events
		component.addFocusListener(this);
		borderPainter = new TextBorderPainter(component);
	}

	public void setButton(PushButton button) {
		this.button = button;
		borderPainter.setButton(button);
		Rectangle rect = component.getBounds();
		setButtonBounds(rect);
	}

	public void setBorderBevel(BorderBevel bevel) {
		borderPainter.setBorderBevel(bevel);
	}

	public void dispose() {
		if (component != null) {
			component.removeComponentListener(this);
			component.removeFocusListener(this);
			component = null;
		}
		borderPainter.dispose();
		borderPainter = null;
	}

	public void setErrorString(String error) {
		if (this.error != null) {
			ErrorManager.getErrorManager().unregisterComponent(component);
			removeErrorBorder();
		}
		this.error = error;
		if (this.error != null) {
			addErrorBorder();
			ErrorManager.getErrorManager().registerComponent(component);
		}
	}

	public String getErrorString() {
		return error;
	}

	private void addErrorBorder() {
		borderPainter.setError(true);
		component.repaint();
		/*
		errorBorder = new ErrorBorder();
		setBorderBounds(errorBorder, component.getBounds());
		component.getParent().add(errorBorder);
		*/
	}

	private void removeErrorBorder() {
		borderPainter.setError(false);
		component.repaint();
		/*
		if (errorBorder != null) {
			component.getParent().remove(errorBorder);
			errorBorder = null;
		}
		*/
	}

	private void setButtonBounds(Rectangle bounds) {
		if (button != null) {
			int y = (bounds.height - button.getHeight()) / 2 + 1;
			int x = bounds.width - button.getWidth() - 2;
			button.setBounds(x, y, button.getWidth(), button.getHeight());
		}
	}

	// Focus listener

	public void focusGained(FocusEvent e) {
		component.repaint();
	}

	public void focusLost(FocusEvent e) {
		component.repaint();
	}

	// Component listener

	public void componentResized(ComponentEvent e) {
		Rectangle rect = e.getComponent().getBounds();
		/*
		setBorderBounds(focusBorder, rect);
		setBorderBounds(errorBorder, rect);
		*/
		setButtonBounds(rect);
	}

	public void componentMoved(ComponentEvent e) {
		Rectangle rect = e.getComponent().getBounds();
		/*
		setBorderBounds(focusBorder, rect);
		setBorderBounds(errorBorder, rect);
		*/
		setButtonBounds(rect);
	}

	public void componentShown(ComponentEvent e) {
		/*
		setBorderVisibility(focusBorder);
		setBorderVisibility(errorBorder);
		*/
	}

	public void componentHidden(ComponentEvent e) {
		/*
		setBorderVisibility(focusBorder);
		setBorderVisibility(errorBorder);
		*/
	}

	public BorderPainter getBorderPainter() {
		return borderPainter;
	}

	public static class TextBorderPainter extends AbstractBorderPainter {

		private static final Color ERROR_COLOR = new Color(255, 0, 0);

		// top, left, bottom, right
		private static final ImmInsets _INSETS_TEXT_FIELD = new ImmInsets(3, 2, 0, 2);
		private static final ImmInsets _INSETS_TEXT_AREA = new ImmInsets(1, 1, 1, 1);
		
		private static final ImmInsets _FILL_INSETS0 = new ImmInsets(0, 0, 0, 0);	// No border
		private static final ImmInsets _FILL_INSETS1 = new ImmInsets(1, 1, 1, 1);	// Border, no focus
		private static final ImmInsets _FILL_INSETS2 = new ImmInsets(2, 2, 2, 2);	// Border and focus

		private Component component;
		private boolean hasError = false;
		
		private BorderBevel borderBevel;
		private PushButton button;

		public TextBorderPainter(Component component) {
			this.component = component;
		}

		public void setButton(PushButton button) {
			this.button = button;
		}

		public void setBorderBevel(BorderBevel bevel) {
			this.borderBevel = bevel;
		}

		public void dispose() {
			this.component = null;
			this.button = null;
			this.borderBevel = null;
		}

		protected void setError(boolean flag) {
			hasError = flag;
		}

		private boolean hasFocus() {
			if (component instanceof ScrollBox) {
				return ((ScrollBox)component).getContent().hasFocus();
			} else {
				return component.hasFocus();
			}
		}

		@Override
		protected ImmInsets getOwnInsets(PaintContext ctx) {
			ImmInsets immSets;
			if (component instanceof ScrollBox) {
				immSets = _INSETS_TEXT_AREA;
			} else {
				immSets = _INSETS_TEXT_FIELD;
			}
			if (button != null && button.isVisible()) {
				return new ImmInsets(immSets.top, immSets.left, immSets.bottom, immSets.right + button.getWidth());
			} else {
				return immSets;
			}
		}
		
		@Override
		protected ImmInsets getOwnFillInsets(PaintContext ctx) {
			if (borderBevel != BorderBevel.NONE) {
				if (hasError || hasFocus()) {
					return _FILL_INSETS2;
				} else {
					return _FILL_INSETS1;
				}
			} else {
				return _FILL_INSETS0;
			}
		}

		@Override
		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			if (borderBevel != BorderBevel.NONE) {
				if (hasError) {
					g.setColor(ERROR_COLOR);
					g.drawRect(x, y, w - 1, h - 1);
					g.setColor(IliasLookAndFeel.BORDER_COLOR);
					g.drawRect(x+1, y+1, w - 3, h - 3);
				} else if (hasFocus()) {
					g.setColor(IliasLookAndFeel.FOCUS_COLOR);
					g.drawRect(x, y, w - 1, h - 1);
					g.setColor(IliasLookAndFeel.BORDER_COLOR);
					g.drawRect(x+1, y+1, w - 3, h - 3);
				} else {
					g.setColor(IliasLookAndFeel.BORDER_COLOR);
					g.drawRect(x, y, w - 1, h - 1);
				}
			}
			g.setColor(oldColor);
		}

		@Override
		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | PaintContext.STATE_FOCUSED | PaintContext.STATE_ARMED | 0x400;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return true;
		}
	}

	public static class FocusBorder extends LWComponent {

		private static final long serialVersionUID = 4498984874691493766L;

		public void paint(Graphics g) {
			Color oldColor = g.getColor();
			g.setColor(IliasLookAndFeel.FOCUS_COLOR);
			g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
			g.setColor(oldColor);
		}
	}

	public static class ErrorBorder extends LWComponent {

		private static final long serialVersionUID = 7871281472894938526L;

		private static final Color ERROR_COLOR = new Color(255, 0, 0);

		public void paint(Graphics g) {
			Color oldColor = g.getColor();
			g.setColor(ERROR_COLOR);
			g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
			g.setColor(oldColor);
		}
	}
}
