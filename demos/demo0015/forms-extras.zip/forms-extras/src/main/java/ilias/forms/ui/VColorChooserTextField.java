package ilias.forms.ui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.TextEvent;

import javax.swing.JColorChooser;

import oracle.ewt.button.PushButton;
import oracle.ewt.painter.BorderPainter;
import oracle.forms.handler.IHandler;
import oracle.forms.properties.BorderBevel;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTextField;

public class VColorChooserTextField extends VTextField implements ActionListener, MouseListener {

	private static final long serialVersionUID = -7836894346349867742L;

	private Color mColor = null;
    private PushButton mButton;
    private boolean mEditable = true;

	private static Image SEARCH_WHITE = TextComponentButton.getImage("search_white.gif");
	private static Image SEARCH_YELLOW = TextComponentButton.getImage("search_yellow.gif");

	protected TextComponentBorder border;
	
	public VColorChooserTextField() {
        super();
        setLayout(null);
        setEditable(false);
        mButton = new TextComponentButton(SEARCH_WHITE);
        mButton.addActionListener(this);
		getTextBorder().setButton(mButton);	
		add(mButton);
    }
	
	private TextComponentBorder getTextBorder() {
		if (border == null) {
			border = new TextComponentBorder(this);
		}
		return border;
	}

	public void init(IHandler ihandler) {
		super.init(ihandler);
		mButton.addMouseListener(this);
	}

	public boolean setProperty(ID id, Object obj) {
		switch (id.toID()) {
        case ID.INDEX_VALUE:
            mColor = null;
            super.setProperty(id, obj);
            String s = getText();
            if ( s != null && !s.equalsIgnoreCase("") ) {
                mColor = Color.decode("0x"+s);
            }
            return true;
        case ID.INDEX_EDITABLE:
        	mEditable = ((Boolean)obj).booleanValue();
            return true;
        case ID.INDEX_ENABLED:
            boolean enabled = ((Boolean)obj).booleanValue();
            mButton.setEnabled(enabled);
            break;
        case ID.INDEX_BACKGROUND :
			if (obj instanceof Color) {
				Color c = (Color) obj;
				if (c.getRed() == 251 && c.getGreen() == 230 && c.getBlue() == 174) {
		    		mButton.setImage(SEARCH_YELLOW);					
				} else {
					mButton.setImage(SEARCH_WHITE);					
				}
			}
			break;
        case ID.INDEX_BORDER_BEVEL:
			getTextBorder().setBorderBevel((BorderBevel) obj);
			break;
        }
        return super.setProperty(id, obj);
    }

	public Object getProperty(ID id) {
		switch (id.toID()) {
        case ID.INDEX_EDITABLE:
        	return mEditable;
		}
		return super.getProperty(id);
	}

	protected void paintCanvasInterior(Graphics g) {
		Rectangle r = getInnerBounds();

		Color oldColor = g.getColor();

		g.setColor(Color.white);
		g.fillRect(r.x, r.y, r.width - r.height, r.height);
		if (mColor != null) {
			g.setColor(mColor);
			if (hasGlobalFocus()) {
				g.fillRect(r.x, r.y, 22, r.height - 4);
				g.setColor(Color.black);
				g.drawRect(r.x, r.y, 21, r.height - 5);
			} else {
				g.fillRect(r.x + 2, r.y + 2, 22, r.height - 6);
				g.setColor(Color.black);
				g.drawRect(r.x + 2, r.y + 2, 21, r.height - 7);
			}
		}

		String s = getText();
		if (s != null) {
			g.setColor(Color.black);
			FontMetrics fontmetrics = g.getFontMetrics();
			int o = (r.height - fontmetrics.getHeight()) / 2;
			g.drawString(s, 26, o + fontmetrics.getAscent());
		}

		g.setColor(oldColor);
	}

	public void actionPerformed(ActionEvent e) {
        if (mButton.isEnabled()) {
        	openDialog();
        }
	}
	
	private void openDialog() {
	    Color c = JColorChooser.showDialog(this, "Choose a color", mColor);
		if (c != null) {
	        mColor = c;
	        setText(Integer.toHexString(mColor.getRGB()).substring(2).toUpperCase());
	        processTextEvent(new TextEvent(this, TextEvent.TEXT_VALUE_CHANGED));
	    }
    }

	public BorderPainter getBorderPainter() {
		return getTextBorder().getBorderPainter();
	}

    public void destroy() {
  		mButton.removeMouseListener(this);
    	super.destroy();
    }
    
	// //////////////////////////////////////////////////////////////////////////

    public void mouseClicked(MouseEvent e) {
    	if (mButton.isEnabled()) {
        	if (!hasGlobalFocus()) {
        		requestFocus();
        	}
        	openDialog();
			e.consume();
    	}
    }

    public void mousePressed(MouseEvent e) {
    	if (mButton.isEnabled() && !hasGlobalFocus()) {
    		requestFocus();
    	}
		e.consume();
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}
}