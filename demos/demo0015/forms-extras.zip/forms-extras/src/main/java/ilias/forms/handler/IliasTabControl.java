package ilias.forms.handler;

import oracle.forms.handler.TabControl;

public class IliasTabControl extends TabControl {
}
