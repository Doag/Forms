package ilias.forms.ui;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.InputStream;

import javax.swing.ImageIcon;

import oracle.ewt.button.PushButton;
import oracle.ewt.graphics.ImageSet;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.ImageSetPainter;
import oracle.ewt.painter.PaintContext;

public class TextComponentButton extends PushButton {

	private static final long serialVersionUID = 2737117212135157056L;

	public TextComponentButton(Image image) {
		setCursor(Cursor.getDefaultCursor());
		setRightmost(false);
		setLeftmost(false);
		setFocusable(false);
		setImage(image);
		ImageIcon icon = new ImageIcon(image);
		setSize(icon.getIconWidth(), icon.getIconHeight());
		setPainter(new ImageSetPainter() {
			public void paint(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
				ImageSet imageset = getImageSet(ctx);
				if (imageset != null) {
					int paintState = getPaintState(ctx);
					// If a modal form is openen, the paint state becomes DISABLED + INACTIVE
					paintState &= ~PaintContext.STATE_DISABLED;
					imageset.paintImage(paintState & 0x9F, g, x, y, ctx.getImageObserver());
				}
			}
		});
		setLabel(null);
	}

	public BorderPainter getBorderPainter() {
		return null;
	}

	public static Image getImage(String name) {
		InputStream in = TextComponentButton.class.getResourceAsStream(name);
		try {
			int n = in.available();
			byte[] bytes = new byte[n];
			int o = 0;
			while ((o += in.read(bytes, o, n - o)) < n)
				;
			in.close();
			return Toolkit.getDefaultToolkit().createImage(bytes);
		} catch (Exception e) {
			return null;
		}
	}
}
