package ilias.forms.error;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;

import oracle.ewt.lwAWT.LWComponent;

public class ErrorBorder extends LWComponent implements ComponentListener, ContainerListener {
	private static final long serialVersionUID = 7871281472894938526L;

	private Component component;
	
	public ErrorBorder(Component component) {
		this.component = component;
		setBounds(component.getX() - 2, component.getY() - 2,
				component.getWidth() + 4, component.getHeight() + 4);
		component.addComponentListener(this);
		component.getParent().addContainerListener(this);
		setVisible(component.isVisible());
	}

	public void paint(Graphics g) {
		g.setColor(Color.RED);
		g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
		g.drawRect(1, 1, getWidth() - 3, getHeight() - 3);
	}

	public void dispose() {
		component.getParent().removeContainerListener(this);
		component.removeComponentListener(this);
		component = null;
	}

	public void componentResized(ComponentEvent e) {
		Dimension size = e.getComponent().getSize();
		setSize(size.width + 4, size.height + 4);
	}

	public void componentMoved(ComponentEvent e) {
		Rectangle bounds = e.getComponent().getBounds();
		bounds.width += 4;
		bounds.height += 4;
		setBounds(bounds);
	}

	public void componentShown(ComponentEvent e) {
		setVisible(true);
	}

	public void componentHidden(ComponentEvent e) {
		setVisible(false);
	}

	public void componentAdded(ContainerEvent e) {
		if(e.getChild()==component) {
			
		}
	}

	public void componentRemoved(ContainerEvent e) {
		if(e.getChild()==component) {
			
		}
	}
}
