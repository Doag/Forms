package ilias.forms.laf;

import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.lwAWT.LWScrollbar;
import oracle.ewt.painter.FGBGColorChange;
import oracle.ewt.painter.FilledRectPainter;
import oracle.ewt.painter.Painter;
import oracle.ewt.plaf.ScrollBarUI;

public class IliasScrollBarUI extends BasicComponentUI implements ScrollBarUI {

	private static Painter _sThumbPainter;
	private static Painter _sTrackPainter;
	private static final Painter _BLOCK_TRACK_PAINTER = new FGBGColorChange(
			FilledRectPainter.getPainter(), true);

	public IliasScrollBarUI(LWComponent comp) {
		super(comp);
	}

	public Painter getIncrementPainter(LWComponent comp) {
		int i = (_isHorizontal(comp)) ? 3 : 1;
		return IliasScrollArrowPainter.getPainter(i);
	}

	public Painter getDecrementPainter(LWComponent comp) {
		int i = (_isHorizontal(comp)) ? 2 : 0;
		return IliasScrollArrowPainter.getPainter(i);
	}

	public Painter getThumbPainter(LWComponent comp) {
		if (_sThumbPainter == null) {
			_sThumbPainter = new FGBGColorChange(
					FilledRectPainter.getPainter(), true);
		}
		return _sThumbPainter;
	}

	public Painter getTrackPainter(LWComponent comp) {
		if (_sTrackPainter == null) {
			_sTrackPainter = new IliasScrollbarColorChange(
					FilledRectPainter.getPainter());
		}
		return _sTrackPainter;
	}

	public Painter getThumbDragPainter(LWComponent comp) {
		return getThumbPainter(comp);
	}

	public Painter getBlockTrackPainter(LWComponent comp) {
		return _BLOCK_TRACK_PAINTER;
	}

	private boolean _isHorizontal(LWComponent bar) {
		return (((LWScrollbar) bar).getOrientation() == 0);
	}
}