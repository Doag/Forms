package ilias.forms.laf;

import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.lwAWT.lwMenu.LWPopupMenu;
import oracle.ewt.lwAWT.lwMenu.laf.PopupMenuController;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.plaf.PopupMenuUI;
import oracle.ewt.util.ImmInsets;

public class IliasPopupMenuUI extends BasicComponentUI implements PopupMenuUI {
	private PopupMenuController _controller;
	private static IliasRectanglePainter _sBorder;

	public IliasPopupMenuUI(LWComponent comp) {
		super(comp);
	}

	public BorderPainter getDefaultBorderPainter(LWComponent paramLWComponent) {
		if (_sBorder == null) {
			_sBorder = new IliasRectanglePainter(IliasLookAndFeel.DARK);
			_sBorder.setOwnInsets(new ImmInsets(1, 1, 1, 1));
		}
		return _sBorder;
	}

	public void installUI(LWComponent comp) {
		LWPopupMenu popup = (LWPopupMenu) comp;
		_controller = new PopupMenuController(popup);
		comp.addKeyListener(_controller);
	}

	public void uninstallUI(LWComponent comp) {
		comp.removeKeyListener(_controller);
		_controller = null;
	}
}