package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericMenuItemUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasMenuItemUI extends GenericMenuItemUI {
	public IliasMenuItemUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}