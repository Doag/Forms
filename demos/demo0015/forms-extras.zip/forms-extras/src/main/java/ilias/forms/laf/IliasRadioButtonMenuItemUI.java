package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericRadioButtonMenuItemUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasRadioButtonMenuItemUI extends GenericRadioButtonMenuItemUI {
	public IliasRadioButtonMenuItemUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}