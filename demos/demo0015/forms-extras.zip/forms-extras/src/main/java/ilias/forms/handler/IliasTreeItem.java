package ilias.forms.handler;

import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import oracle.ewt.dTree.DTree;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.scrolling.scrollBox.ScrollBox;
import oracle.ewt.util.ImmInsets;
import oracle.forms.engine.Message;
import oracle.forms.engine.Runform;
import oracle.forms.handler.TreeItem;
import oracle.forms.properties.ID;

public class IliasTreeItem extends TreeItem {

	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);
		DTree tree = (DTree)getEventComponent();
		Component comp = getComponent();
		if (comp instanceof ScrollBox) {
			ScrollBox scrollBox = (ScrollBox)comp;
			scrollBox.setBorderPainter(new TreeScrollBoxBorderPainter(scrollBox, tree));
		}
	}
	  
	@Override
	public synchronized boolean onUpdate(int id, Object value) {
		switch (id) {
		case ID.INDEX_BORDER_BEVEL:
			// No set of bevel for TreeItem
			return true;
		case ID.INDEX_BORDER:
			// No set of border for TreeItem
			return true;
		}
		return super.onUpdate(id, value);
	}

	@Override
	public void onDestroy() {
		Component comp = getComponent();
		if (comp instanceof ScrollBox) {
			ScrollBox scrollBox = (ScrollBox)comp;
			((TreeScrollBoxBorderPainter)scrollBox.getBorderPainter()).dispose();
		}
		super.onDestroy();
	}

	/**
	 * The border painter on the scroll box
	 * 
	 */
	public static class TreeScrollBoxBorderPainter extends AbstractBorderPainter implements FocusListener {

		// top, left, bottom, right
		private static final ImmInsets _INSETS1 = new ImmInsets(1, 1, 1, 1);
		private static final ImmInsets _INSETS2 = new ImmInsets(2, 2, 2, 2);

		private Component box;
		private Component tree;
		
		public TreeScrollBoxBorderPainter(Component box, Component tree) {
			this.box = box;
			this.tree = tree;
			this.tree.addFocusListener(this);
		}

		public void dispose() {
			this.tree.removeFocusListener(this);
			this.tree = null;
			this.box = null;
		}

		private boolean hasFocus() {
			return tree != null ? tree.hasFocus() : false;
		}
		
		@Override
		protected ImmInsets getOwnInsets(PaintContext ctx) {
			// Padding
			if (hasFocus()) {
				return _INSETS2;
			} else {
				return _INSETS1;
			}
		}

		@Override
		protected ImmInsets getOwnFillInsets(PaintContext ctx) {
			if (hasFocus()) {
				return _INSETS2;
			} else {
				return _INSETS1;
			}
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			boolean hasFocus = tree.hasFocus();
			if (hasFocus) {
				g.setColor(IliasLookAndFeel.FOCUS_COLOR);
				g.drawRect(x, y, w - 1, h - 1);
				g.setColor(IliasLookAndFeel.BORDER_COLOR);
				g.drawRect(x + 1, y + 1, w - 3, h - 3);
			} else {
				g.setColor(IliasLookAndFeel.BORDER_COLOR);
				g.drawRect(x, y, w - 1, h - 1);
			}
			g.setColor(oldColor);
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | 0x400;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return true;
		}

		public void focusGained(FocusEvent e) {
			box.invalidate();
			box.repaint();
		}

		public void focusLost(FocusEvent e) {
			box.invalidate();
			box.repaint();
		}
	}
}
