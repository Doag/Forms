package ilias.forms.ui;

import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import oracle.ewt.button.PushButton;
import oracle.forms.handler.IHandler;
import oracle.forms.properties.ID;

public class VListValField2 extends AdvancedTextFieldItem implements MouseListener {

	private static final long serialVersionUID = 114596175090673909L;

    private final static ID SEARCH_ICON = ID.registerProperty("search_icon");
	private static Image buttonImage = TextComponentButton.getImage("search.gif");

	private PushButton button;

    public VListValField2() {
		button = new TextComponentButton(buttonImage);
		button.addActionListener(this);
		getTextBorder().setButton(button);
		button.setVisible(false);		
		add(button);
    }

    public void init(IHandler ihandler) {
    	if (ihandler != null) {
    		super.init(ihandler);
    	}
		button.addMouseListener(this);
    }

    @Override
    public boolean setProperty(ID id, Object value) {
    	if (id == SEARCH_ICON) {
    		buttonImage = TextComponentButton.getImage((String) value);
    		button.setImage(buttonImage);
    		button.setVisible(true);
    		return true;
    	}
    	return super.setProperty(id, value);
    }

    public void destroy() {
  		button.removeMouseListener(this);
    	super.destroy();
    }

    public void setEditable(boolean flag) {
    	super.setEditable(flag);
    	button.setEnabled(isEnabled() && isEditable());
    }

    public void setEnabled(boolean flag) {
    	super.setEnabled(flag);
    	button.setEnabled(isEnabled() && isEditable());
    }

    // //////////////////////////////////////////////////////////////////////////

    public void mouseClicked(MouseEvent e) {
    	if (button.isEnabled()) {
    		dispatchEvent(new KeyEvent(this, KeyEvent.KEY_PRESSED,
    				System.currentTimeMillis(), 0, KeyEvent.VK_F9,
    				KeyEvent.CHAR_UNDEFINED));
    		dispatchEvent(new KeyEvent(this, KeyEvent.KEY_RELEASED,
    				System.currentTimeMillis(), 0, KeyEvent.VK_F9,
    				KeyEvent.CHAR_UNDEFINED));
    	}
    }

    public void mousePressed(MouseEvent e) {
    	if (button.isEnabled() && !hasGlobalFocus()) {
    		requestFocus();
    	}
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}
}