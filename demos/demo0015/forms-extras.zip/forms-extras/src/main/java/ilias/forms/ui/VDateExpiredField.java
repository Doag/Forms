package ilias.forms.ui;

import java.awt.Color;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import oracle.forms.handler.IHandler;
import oracle.forms.properties.ID;
import oracle.forms.ui.BeanManager;
import oracle.forms.ui.CustomEvent;
import oracle.forms.ui.CustomListener;

public class VDateExpiredField extends VDateField {

	private static final long serialVersionUID = 9186196019516954522L;

	private IHandler mHandler;
	private BeanManager mManager;

	public static final ID GETRANGESEVENT = ID.registerProperty("GetRangeEvent");
	public final static ID SYSDATE = ID.registerProperty("SYSDATE");
	public final static ID SETCOLOR = ID.registerProperty("SETCOLOR");
	public final static ID SETRANGE = ID.registerProperty("SETRANGE");

	public long localTimeDifference = 0;
	public Color colorSetByForms = null;
	public Font fontSetByForms = null;
	public Date sysdate;
	public Date value;	
	public Date localTime; 
	public Date sysdateSetAt;
	private boolean dateRequested = false;
	private String[] parts;	
	
	private List<VDateExpiredFieldRange> ranges = new ArrayList<VDateExpiredFieldRange>();
	
	public VDateExpiredField () {
		super();
	}
	
	public void init(IHandler handler) {
		super.init(handler);
		mHandler = handler;
	}

	public boolean setProperty(ID id, Object obj) {
		if (id == SETRANGE){
			parts = ((String)obj).split(";"); 
			
			int priority = Integer.parseInt(parts[0]);
			
			Date sDate = null;
			try {
				if (parts[1].equals("")){
					sDate = null;
				} else {
					sDate = new SimpleDateFormat("dd-MM-yyyy").parse(parts[1]);
				}
			} catch (ParseException e1) {
				e1.printStackTrace();
			} 
			
			Date eDate = null;
			try {
				if (parts[2].equals("")){
					eDate = null;
				} else{
					eDate = new SimpleDateFormat("dd-MM-yyyy").parse(parts[2]);	
				}
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			
			Color color = null;
			try {
				if (parts[3].equals("")){
					color = null;
				} else {
					if (parts[3].equalsIgnoreCase("ORANGE")){
						color = new Color(255,140,0);
					} else {
						color = (Color)Class.forName("java.awt.Color").getField(parts[3]).get(null);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}	
			
			ranges.add(new VDateExpiredFieldRange(priority, sDate, eDate, color));
			
			checkExpDate();
			return true;
		} else if (id == ID.FOREGROUND) {
			colorSetByForms = (Color) obj;
			checkExpDate();
			return true;
		} else if (id == ID.FONT) {
			fontSetByForms = (Font) obj;
			//checkExpDate();
			return true;
		} else if (id == ID.VALUE) {			
			if (ranges.isEmpty()){
				customGetRangesEvent();
			}
			if (obj != null && ! ((String) obj).trim().equals("")){
				try {
					value = new SimpleDateFormat("dd-MM-yyyy").parse((String) obj);
				} catch (ParseException e) {
					e.printStackTrace();
				}
			} else{
				value = null;
			}
			checkExpDate();
		}
		return super.setProperty(id, obj);
	}

	private void checkExpDate() {
		Collections.sort(ranges, new VDateExpiredFieldRange());		
		 
		setForeground(colorSetByForms);
		setFont(fontSetByForms);
		
		VDateExpiredFieldRange range;
		if (!ranges.isEmpty() && value != null){
			for (int i = 0; i < ranges.size(); i++){
				range = ranges.get(i);
				if (range.geteDate() == null){
					if (value.after(range.getsDate())){
						colorField(range);
						break;
					}
				} else if (range.getsDate() == null) {
					if (value.before(range.geteDate())){
						colorField(range);
						break;
					}
				} else if (value.before(range.geteDate())
							&& value.after(range.getsDate())){
						colorField(range);
						break;
				}
			}
		} 
		if (value == null) {
			setForeground(colorSetByForms);
			setFont(fontSetByForms);
		}		
		
//		if (sysdate != null && value != null){
//			localTime = new Date();
//			int diffInDays = (int)( (localTime.getTime() - sysdateSetAt.getTime())/ (1000 * 60 * 60 * 24));
//			
//			//System.out.println("Difference: "+diffInDays);
//			Calendar cal = Calendar.getInstance();
//	        cal.setTime(sysdate);
//	        cal.add(Calendar.DATE, diffInDays); //minus number would decrement the days
//	        sysdate = cal.getTime();
//			
//	        if (sysdate.after(value)) {
//				setForeground(colorWhenExpired);	
//				Font f = fontSetByForms;
//				setFont(f.deriveFont(Font.BOLD));
//			}else{
//				setForeground(colorSetByForms);
//				setFont(fontSetByForms);
//			}
//		} else {
//			setForeground(colorSetByForms);
//			setFont(fontSetByForms);
//		}
	}

	private void colorField(VDateExpiredFieldRange range) {
		setForeground(range.getColor());	
		Font f = fontSetByForms;
		setFont(f.deriveFont(Font.BOLD));
	}
	
	private BeanManager getBeanManager() {
		if (mHandler != null && mManager == null) {
			mManager = new BeanManager();
			mManager.setHandler(mHandler);
			mManager.addCustomListener((CustomListener) mHandler);
		}
		return mManager;
	}
	public void dispatchCustomEvent(CustomEvent ce) {
		getBeanManager().dispatchCustomEvent(ce);
	}
	
	public void customGetRangesEvent() {
		if (mHandler != null && dateRequested == false) {
			try {
				CustomEvent ce = new CustomEvent(mHandler, GETRANGESEVENT);
				dispatchCustomEvent(ce);
				dateRequested = true; 
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}