package ilias.forms.handler;

import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;
import oracle.forms.engine.Message;
import oracle.forms.engine.Runform;
import oracle.forms.handler.TListItem;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTList;

public class IliasTListItem extends TListItem {

	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);
		Component list = getComponent();
		if (list instanceof VTList) {
			((VTList)list).setBorderPainter(new ListBorderPainter(list));
		}
	}

	@Override
	public synchronized boolean onUpdate(int id, Object value) {
		switch (id) {
		case ID.INDEX_BORDER_BEVEL:
			// No set of bevel for TListItem
			return true;
		case ID.INDEX_BORDER:
			// No set of border for TListItem
			return true;
		default:
			return super.onUpdate(id, value);
		}
	}

	@Override
	public synchronized void onDestroy() {
		Component list = getComponent();
		if (list instanceof VTList) {
			((ListBorderPainter)((VTList)list).getBorderPainter()).dispose();
		}
		super.onDestroy();
	}

	public static class ListBorderPainter extends AbstractBorderPainter implements FocusListener {

		private static final ImmInsets _INSETS1 = new ImmInsets(1, 1, 1, 1);
		private static final ImmInsets _INSETS2 = new ImmInsets(2, 2, 2, 2);

		private Component list;
		
		public ListBorderPainter(Component list) {
			this.list = list;
			this.list.addFocusListener(this);
		}

		public void dispose() {
			this.list.removeFocusListener(this);
			this.list = null;
		}

		protected ImmInsets getOwnInsets(PaintContext ctx) {
			boolean hasFocus = list.hasFocus();
			if (hasFocus) {
				return _INSETS2;
			} else {
				return _INSETS1;
			}
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			boolean hasFocus = list.hasFocus();
			if (hasFocus) {
				g.setColor(IliasLookAndFeel.FOCUS_COLOR);
				g.drawRect(x, y, w - 1, h - 1);
				g.setColor(IliasLookAndFeel.BORDER_COLOR);
				g.drawRect(x + 1, y + 1, w - 3, h - 3);
			} else {
				/*
				g.setColor(list.getParent().getBackground());
				g.drawRect(x, y, w - 1, h - 1);
				g.setColor(IliasLookAndFeel.BORDER_COLOR);
				g.drawRect(x + 1, y + 1, w - 3, h - 3);
				*/
				g.setColor(IliasLookAndFeel.BORDER_COLOR);
				g.drawRect(x, y, w - 1, h - 1);
			}
			g.setColor(oldColor);
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | 0x80;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return false;
		}

		public void focusGained(FocusEvent e) {
			list.invalidate();
			list.repaint();
		}

		public void focusLost(FocusEvent e) {
			list.invalidate();
			list.repaint();
		}
	}
}
