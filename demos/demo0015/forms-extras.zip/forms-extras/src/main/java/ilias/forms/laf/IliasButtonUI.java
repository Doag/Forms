package ilias.forms.laf;

import java.awt.Color;

import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.button.PushButton;
import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.laf.basic.DisablingPainter;
import oracle.ewt.laf.generic.GenericLookAndFeel;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AlignmentPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.painter.PainterJoiner;
import oracle.ewt.plaf.ButtonUI;

public class IliasButtonUI extends BasicComponentUI implements ButtonUI {

	private static Painter[] sPainters = new Painter[2];
	private static BorderPainter sBorderPainter;

	public IliasButtonUI(LWComponent comp) {
		super(comp);
	}

	public Painter getPainter(LWComponent comp) {
		int i = _hasImageSet((PushButton) comp) ? 1 : 0;
		Painter painter = sPainters[i];
		if (painter == null) {
			UIDefaults defaults = getUIDefaults(comp);
			Painter text = defaults
					.getPainter(GenericLookAndFeel.TRUNCATING_TEXT_PAINTER);
			text = new DisablingPainter(text, true);
			if (i == 1) {
				Painter image = defaults
						.getPainter(LookAndFeel.IMAGE_SET_PAINTER);
				painter = new AlignmentPainter(new PainterJoiner(text, image,
						10));
			} else {
				painter = text;
			}
			sPainters[i] = painter;
		}
		return painter;
	}

	private boolean _hasImageSet(PushButton btn) {
		return btn.getPaintContext().getPaintData(PaintContext.IMAGESET_KEY) != null;
	}

	@Override
	public Color getDefaultBackground(LWComponent comp) {
		PushButton btn = (PushButton) comp;
		if (btn.isEnabled()) {
			if (btn.isDefault()) {
				return IliasLookAndFeel.LIGHT;
			} else {
				return IliasLookAndFeel.BLUE;
			}
		} else {
			return Color.white;
		}
	}

	@Override
	public Color getDefaultForeground(LWComponent comp) {
		PushButton btn = (PushButton) comp;
		if (btn.isEnabled()) {
			if (btn.isDefault()) {
				return Color.white;
			} else {
				return Color.black;
			}
		} else {
			return Color.gray;
		}
	}

	@Override
	public BorderPainter getDefaultBorderPainter(LWComponent comp) {
		if (sBorderPainter == null) {
			sBorderPainter = new IliasButtonPainter();
		}
		return sBorderPainter;
	}
}
