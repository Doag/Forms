package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericMenuBarUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasMenuBarUI extends GenericMenuBarUI {
	public IliasMenuBarUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}