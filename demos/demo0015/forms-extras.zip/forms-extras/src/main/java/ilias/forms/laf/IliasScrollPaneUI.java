package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericScrollPaneUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.NullPainter;

public class IliasScrollPaneUI extends GenericScrollPaneUI {
	
	public IliasScrollPaneUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
	
	public BorderPainter getDefaultBorderPainter(LWComponent paramLWComponent) {
		return NullPainter.getPainter();
	}
}
