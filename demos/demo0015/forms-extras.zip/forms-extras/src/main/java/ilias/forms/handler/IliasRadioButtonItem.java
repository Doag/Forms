package ilias.forms.handler;

import oracle.forms.handler.RadioButtonItem;

public class IliasRadioButtonItem extends RadioButtonItem {
}
