package ilias.forms.handler;

import oracle.forms.handler.JavaContainer;

public class IliasJavaContainer extends JavaContainer {
}
