package ilias.forms.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import oracle.ewt.button.ButtonBar;
import oracle.ewt.button.PushButton;
import oracle.ewt.lwAWT.LWContainer;
import oracle.ewt.lwAWT.lwWindow.LWWindow;
import oracle.ewt.lwAWT.lwWindow.WindowType;
import oracle.ewt.painter.FixedBorderPainter;
import oracle.ewt.util.FocusUtils;
import oracle.forms.engine.Runform;
import oracle.forms.handler.AppsModalStyle;
import oracle.forms.handler.DialogThread;
import oracle.forms.ui.FWindow;
import oracle.forms.ui.mdi.MDIContainer;

public class DateDialog extends LWContainer implements ActionListener
{
	private static final long serialVersionUID = 382163373660248565L;
	
	private LWWindow myDialog;
    private DatePanel myCalendar;
    private PushButton ok, cancel;

    private boolean myFixedDate;

	public DateDialog(DateCalendar date, boolean withTime) {
        setLayout(new BorderLayout(4,4));
        setBorderPainter(new FixedBorderPainter(4,4,4,4));

        ButtonBar bar = new ButtonBar();

        ok = new PushButton("OK");
        ok.setDefault(true);
        ok.setMinimumSize(new Dimension(120, 20));
        ok.addActionListener(this);
        bar.add(ok);
        
        cancel = new PushButton("Cancel");
        cancel.setMinimumSize(new Dimension(120, 20));
        cancel.addActionListener(this);
        bar.add(cancel);

        myFixedDate = date.isFixed();
        myCalendar = new DatePanel(this, date, withTime);

		add(myCalendar, BorderLayout.CENTER);
		add(bar, BorderLayout.SOUTH);
    }

	public void showDialog(Runform runform) {
        myDialog = createDialog(runform, runform.getFrame(), this);
        myDialog.setTitle("Pick a date ");
        myDialog.pack();
        //Point pos = runform.getFrame().getLocation();
        //myDialog.setLocation(myPosition.x + pos.x, myPosition.y + pos.y);
        DialogThread.centerWindow(runform, myDialog);
        myDialog.setResizable(false);
        myDialog.setClosable(false);
        myDialog.setMaximizable(false);
        myDialog.setMinimizable(false);
        DialogThread.showDialog(myDialog);
        myCalendar.setInitialFocus();
    }

    public static LWWindow createDialog(Runform runform, LWWindow lwwindow, LWContainer content) {
        FWindow fwindow = new FWindow(WindowType.FRAME, lwwindow, true);
        MDIContainer mdicontainer = runform.getApplet().getMDIContainer();
        fwindow.setModalStyle(AppsModalStyle.getAppsModalStyle(mdicontainer.getMDIScrollBox()));
        fwindow.setContent(content);
        runform.getApplet().getDesktop().addWindow(fwindow, false);
        fwindow.pack();
        FocusUtils.setDefaultFocusTraversalKeys(fwindow);
        return fwindow;
    }

	public void cancelDialog() {
        myCalendar.cancel();
        onCancel();
        myDialog.setVisible(false);
        myDialog.dispose();
    }

	public void endDialog() {
        onOK();
        myDialog.setVisible(false);
        myDialog.dispose();
    }

	public void actionPerformed(ActionEvent actionevent) {
        if(actionevent.getSource() == ok)
            endDialog();
        else
        if(actionevent.getSource() == cancel)
            cancelDialog();
    }

    public void onOK() {};
    public void onCancel() {};

    /** Return the selected date. */
	public DateCalendar getDate() {
        DateCalendar result = myCalendar.getDate();
        result.setFixed(myFixedDate);
        return result;
    }
}

