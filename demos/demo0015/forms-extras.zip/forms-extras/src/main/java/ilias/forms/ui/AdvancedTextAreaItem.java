package ilias.forms.ui;

import ilias.clipboard.MyClipboard;
import ilias.forms.error.ErrorComponent;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import oracle.ewt.lwAWT.lwMenu.LWPopupMenu;
import oracle.ewt.lwAWT.lwText.LWTextArea;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.util.ClipboardProxy;
import oracle.ewt.util.InputEventUtils;
import oracle.forms.handler.IHandler;
import oracle.forms.properties.BorderBevel;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTextArea;

public class AdvancedTextAreaItem extends VTextArea implements ErrorComponent,
		ActionListener, MouseListener, KeyListener {

	private static final long serialVersionUID = -3747464976263348945L;

	private static final ID ERROR_STRING = ID.registerProperty("errorString");

	private static final String CUT = "cut";
	private static final String COPY = "copy";
	private static final String PASTE = "paste";
	private static final String PASTE_SPECIAL = "pasteSpecial";

	protected TextComponentBorder border;

	private String prompt;

	public AdvancedTextAreaItem() {
		super();
	}

	private TextComponentBorder getTextBorder() {
		if (border == null) {
			border = new TextComponentBorder(this);
		}
		return border;
	}

	public void init(IHandler ihandler) {
		if (ihandler != null) {
			super.init(ihandler);
		}
		LWTextArea area = (LWTextArea) getContent();
		area.addMouseListener(this);
		area.addKeyListener(this);
	}

	public boolean setProperty(ID id, Object value) {
		if (id == ID.BORDER_BEVEL) {
			getTextBorder().setBorderBevel((BorderBevel) value);
		} else if (id.toID() == ERROR_STRING.toID()) {
			return setErrorStringProperty((String) value);
		}
		return super.setProperty(id, value);
	}

	public void destroy() {
		if (border != null) {
			border.dispose();
			border = null;
		}
		LWTextArea area = (LWTextArea) getContent();
		area.removeKeyListener(this);
		area.removeMouseListener(this);
		super.destroy();
	}

	private boolean setErrorStringProperty(String error) {
		setErrorString(error);
		return true;
	}

	public void setErrorString(String error) {
		getTextBorder().setErrorString(error);
	}

	public String getErrorString() {
		return getTextBorder().getErrorString();
	}

	public BorderPainter getBorderPainter() {
		return getTextBorder().getBorderPainter();
	}

	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}

	/** Create a popup for this field */
	private void createPopup(int x, int y) {
		LWTextArea area = (LWTextArea) getContent();
		LWPopupMenu mPopupMenu = new LWPopupMenu();
		mPopupMenu.setFont(getFont());

		mPopupMenu.add(MyClipboard.createPopupItem(this, "Cut", CUT,
				"cut_16.gif", area.isEditable()));
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Copy", COPY,
				"copy_16.gif", true));
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Paste", PASTE,
				"paste_16.gif", area.isEditable()));
		mPopupMenu.add(MyClipboard.createPopupItem(this, "Paste Special",
				PASTE_SPECIAL, "paste_16.gif", area.isEditable()));
		mPopupMenu.popup(area, x, y);
	}

	public void copy() {
		LWTextArea area = (LWTextArea) getContent();
		String s = area.getSelectedText();
		if (s.length() == 0) {
			return;
		}
		area.copy();
		addFromClipboard();
	}

	private void pasteSpecial() {
		LWTextArea area = (LWTextArea) getContent();
		if (!area.isEditable()) {
			Toolkit.getDefaultToolkit().beep();
			return;
		}
		if (MyClipboard.mMyClipboard.size() > 0) {
			MyClipboard.mMyClipboard.popup(this, 2, 2);
		}
	}

	public void actionPerformed(ActionEvent e) {
		LWTextArea area = (LWTextArea) getContent();
		String s = e.getActionCommand();
		if (s == CUT)
			area.cut();
		else if (s == COPY)
			copy(); // not area.copy !!!
		else if (s == PASTE)
			area.paste();
		else if (s == PASTE_SPECIAL)
			pasteSpecial();
	}

	/** Add what is on the clipboard into our clipboard */
	@SuppressWarnings("deprecation")
	private void addFromClipboard() {
		String text = null;
		Clipboard clipboard = ClipboardProxy.getSystemClipboard();
		Transferable transferable = clipboard.getContents(this);
		if (transferable != null) {
			try {
				if (transferable.isDataFlavorSupported(DataFlavor.stringFlavor))
					text = (String) transferable
							.getTransferData(DataFlavor.stringFlavor);
				else if (transferable
						.isDataFlavorSupported(DataFlavor.plainTextFlavor)) {
					byte abyte0[] = (byte[]) transferable
							.getTransferData(DataFlavor.plainTextFlavor);
					try {
						text = new String(abyte0, 0, abyte0.length, "8859_1");
					} catch (UnsupportedEncodingException unsupportedencodingexception) {
					}
				}
			} catch (UnsupportedFlavorException unsupportedflavorexception) {
			} catch (IOException ioexception) {
			}
		}
		if (text != null) {
			String key = prompt;
			if (key == null) {
				key = getAccessibleContext().getAccessibleName();
			}
			if (key == null) {
				key = "????";
			}
			MyClipboard.mMyClipboard.add(new MyClipboard.MyEntry(key, text));
		}
	}

	// //////////////////////////////////////////////////////////////////////////

	public void mouseClicked(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
		if (InputEventUtils.isRightMouseButton(e)) {
			LWTextArea area = (LWTextArea) getContent();
			if (!area.hasGlobalFocus()) {
				area.requestFocus();
			}
			e.consume();
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (InputEventUtils.isRightMouseButton(e)) {
			LWTextArea area = (LWTextArea) getContent();
			if (area.hasGlobalFocus()) {
				createPopup(e.getX(), e.getY());
			}
			e.consume();
		}
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void keyPressed(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
		if (!e.isConsumed() && e.getKeyChar() == 2) {
			pasteSpecial();
			e.consume();
			return;
		}
		if (!e.isConsumed() && e.getKeyChar() == 3) {
			copy();
			e.consume();
			return;
		}
	}
}
