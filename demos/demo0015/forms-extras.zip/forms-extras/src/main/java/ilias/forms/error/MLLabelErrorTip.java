package ilias.forms.error;

import java.awt.Color;

import oracle.ewt.multiLineLabel.MultiLineLabel;
import oracle.ewt.popup.AbstractToolTip;
import oracle.ewt.popup.ToolTip;
import oracle.ewt.textWrapper.WordWrapper;

public class MLLabelErrorTip extends AbstractToolTip {

	private static final long serialVersionUID = -5782229702850622221L;

	private static ToolTip _sToolTip;
	private MultiLineLabel _mlLabel = new MultiLineLabel();

	public MLLabelErrorTip() {
		this._mlLabel.setTextWrapper(WordWrapper.getTextWrapper());
		setContent(this._mlLabel);
	}

	public static ToolTip getToolTip() {
		if (_sToolTip == null) {
			MLLabelErrorTip comp = new MLLabelErrorTip();
			comp.setBackground(Color.RED);
			comp._mlLabel.setForeground(Color.WHITE);
			_sToolTip = comp;
		}
		return _sToolTip;
	}

	public void setToolTipValue(Object paramObject) {
		this._mlLabel.setText(paramObject.toString());
	}

	public Object getUIClassID() {
		return "ErrorTipUI";
	}
}
