package ilias.forms.handler;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Locale;
import java.util.Vector;

import oracle.ewt.LookAndFeel;
import oracle.ewt.UIManager;
import oracle.ewt.graphics.GraphicUtils;
import oracle.ewt.painter.FixedImagePainter;
import oracle.ewt.painter.Painter;
import oracle.ewt.painter.PainterTiler;
import oracle.ewt.util.LocaleUtils;
import oracle.ewt.util.StringUtils;
import oracle.forms.engine.PatternProducer;
import oracle.forms.engine.Runform;
import oracle.forms.handler.FormCanvas;
import oracle.forms.properties.Alignment;
import oracle.forms.properties.ID;
import oracle.graphics.vgs.ui.Device;
import oracle.graphics.vgs.ui.Text;

public class IliasPromptItem {

	private byte mEnumVal;
	private int mEdgeOffset;
	private int mAlignOffset;
	private byte mReadingDirection;
	private Vector<String> mTextVal;
	private int mColorNum;
	private Color mBgColor;
	private int mFontNum;
	private Color mColor;
	private String mImageName;
	private Painter mPainter;
	private IliasItemInfo mItemInfo;
	private PatternProducer mProducer;
	private Font mFont;
	private FontMetrics mFontMetrics;
	private int mWidth = 0;
	private int mHeight = 0;
	private Rectangle mBoundingBox;
	private boolean mDirty;
	private boolean mFirst;
	private boolean mVisible = true;
	private int mOriginalX;
	private int mOriginalY;
    private boolean mFrameVisible = true;

	public static final int PROMPT_ITEMINDEX = -1;

	public static final byte PROMPT_DSP_SHIFT = 7;
	public static final byte PROMPT_DSP_MASK = 1;
	public static final byte PROMPT_EDG_SHIFT = 5;
	public static final byte PROMPT_EDG_MASK = 3;
	public static final byte PROMPT_EDG_TOP = 0;
	public static final byte PROMPT_EDG_BOT = 1;
	public static final byte PROMPT_EDG_START = 2;
	public static final byte PROMPT_EDG_END = 3;
	public static final byte PROMPT_TAL_SHIFT = 2;
	public static final byte PROMPT_TAL_MASK = 7;
	public static final byte PROMPT_TAL_START = 0;
	public static final byte PROMPT_TAL_END = 1;
	public static final byte PROMPT_TAL_LEFT = 2;
	public static final byte PROMPT_TAL_CENTER = 3;
	public static final byte PROMPT_TAL_RIGHT = 4;
	public static final byte PROMPT_EAL_SHIFT = 0;
	public static final byte PROMPT_EAL_MASK = 3;
	public static final byte PROMPT_EAL_START = 0;
	public static final byte PROMPT_EAL_CENTER = 1;
	public static final byte PROMPT_EAL_END = 2;

	public static final byte PROMPT_READINGDIRECTION_DEFAULT = 0;
	public static final byte PROMPT_READINGDIRECTION_TOLEFT = 1;
	public static final byte PROMPT_READINGDIRECTION_TORIGHT = 2;

	public IliasPromptItem() {
		setDirty(true);
		this.mFirst = true;
		this.mFontNum = 1;
		this.mColorNum = 1;
		this.mReadingDirection = 0;
		this.mItemInfo = new IliasItemInfo();
		this.mBoundingBox = new Rectangle();
	}

	public boolean setPromptProperty(int id, Object value) {
		boolean i = true;
		switch (id) {
		case 421:
			setEnum(((Byte) value).byteValue());
			break;
		case 165:
			mReadingDirection = ((Byte) value).byteValue();
			break;
		case 422:
			setEOF(((Integer) value).intValue());
			break;
		case 423:
			setAOF(((Integer) value).intValue());
			break;
		case 131:
			setTextVal((String[]) (String[]) value);
			break;
		case 425:
			setColorNum(((Integer) value).intValue());
			break;
		case 426:
			setFontNum(((Integer) value).intValue());
			break;
		case ID.INDEX_PROMPT_ITEMPOS:
			mItemInfo.setItemPosition((Point) value);
			mOriginalX = mItemInfo.getItemX();
			mOriginalY = mItemInfo.getItemY();
			break;
		case ID.INDEX_PROMPT_ITEMSIZE:
			mItemInfo.setItemSize((Point) value);
			break;
		case PROMPT_ITEMINDEX:
			mItemInfo.setItemIndex(((Integer) value).intValue());
			break;
		case ID.INDEX_PROMPT_BGPATTERN:
			setImage((String) value);
			break;
		default:
			i = false;
			break;
		}
		return i;
	}

	public void setEnum(byte value) {
		mEnumVal = value;
	}

	public void setEOF(int value) {
		mEdgeOffset = value;
	}

	public void setAOF(int value) {
		mAlignOffset = value;
	}

	public void setTextVal(String[] value) {
		mTextVal = new Vector<String>();
		for (int i = 0; i < value.length; i++)
			mTextVal.addElement(value[i]);
	}

	public void setColorNum(int value) {
		if (value != mColorNum)
			mPainter = null;
		mColorNum = value;
	}

	public void setBgColor(Color value) {
		if (value != mBgColor)
			mPainter = null;
		mBgColor = value;
	}

	public void setFontNum(int value) {
		mFontNum = value;
	}

	public void setDirty(boolean value) {
		mDirty = value;
	}

	public void setImage(String value) {
		if ((value == null && value != mImageName)
				|| (value != null && !value.equals(mImageName))) {
			mPainter = null;
		}
		mImageName = value;
	}

	public byte getEnum() {
		return mEnumVal;
	}

	public int getEOF() {
		return mEdgeOffset;
	}

	public int getAOF() {
		return mAlignOffset;
	}

	public int getColorNum() {
		return mColorNum;
	}

	public Color getBgColor() {
		return mBgColor;
	}

	public int getFontNum() {
		return mFontNum;
	}

	public Painter getPainter(Runform runform) {
		if ((mPainter == null) && (mImageName != null)) {
			if (mProducer == null) {
				mProducer = PatternProducer.getProducer(runform.getApplet());
			}
			Image img = mProducer.getPattern(mImageName,
					runform.getColorEntry(getColorNum()), getBgColor());
			mPainter = (img == null ? null : new PainterTiler(
					new FixedImagePainter(img)));
		}
		return mPainter;
	}

	public IliasItemInfo getItemInfo() {
		return mItemInfo;
	}

	public boolean isDirty() {
		return mDirty;
	}

	public boolean isDisplayed() {
		boolean result = false;
		int i = (byte) (mEnumVal >> 7 & 0x1);
		if (i == 1) {
			result = true;
		}
		return result;
	}

	public void computeWidth(byte value) {
		int j;
		if (mReadingDirection == PROMPT_READINGDIRECTION_TORIGHT
				|| (mReadingDirection == PROMPT_READINGDIRECTION_DEFAULT && value == 1))
			j = 1;
		else
			j = 2;
		
		mWidth = 0;
		Locale locale = Locale.getDefault();
		for (int i = 0; i < mTextVal.size(); i++) {
			String text = mTextVal.elementAt(i);
			String str = StringUtils.getDisplayString(text, locale, j);
			int w = mFontMetrics.stringWidth(str);
			if (w <= mWidth) {
				continue;
			}
			mWidth = w;
		}
	}

	public void computeHeight() {
		mHeight = 0;
		for (int i = 0; i < mTextVal.size(); i++) {
			mHeight += mFontMetrics.getHeight();
		}
	}

	public void computeBoundingBox(FormCanvas canvas) {
		int scale = 100;

		int edg = (byte) (mEnumVal >> PROMPT_EDG_SHIFT & PROMPT_EDG_MASK);
		int eal = (byte) (mEnumVal >> PROMPT_EAL_SHIFT & PROMPT_EAL_MASK);

		int x = mItemInfo.getItemX() * scale / 100;
		int y = mItemInfo.getItemY() * scale / 100;
		int w = mItemInfo.getItemWidth() * scale / 100;
		int h = mItemInfo.getItemHeight() * scale / 100;
		
		mFont = canvas.getFontEntry(getFontNum());
		mFontMetrics = canvas.getComponent().getFontMetrics(mFont);

		computeWidth(canvas.getDeviceDirection());
		computeHeight();

		/*
		 * if (canvas.getDeviceDirection() == UICommon.UI_DIRECTION_TOLEFT) {
		 * Dimension localDimension = canvas.getPanel().getSize(); if
		 * ((canvas.getPanel().getCanvasType() == 0) && (!canvas.isTabCanvas()))
		 * { ExtendedFrame localExtendedFrame = (ExtendedFrame) (ExtendedFrame)
		 * canvas .getParentWindow(); if (localExtendedFrame != null) {
		 * DrawnPanel localDrawnPanel = localExtendedFrame
		 * .getVerticalToolbar(); if ((localDrawnPanel != null) &&
		 * (localDrawnPanel.isVisible())) localDimension.width -=
		 * localDrawnPanel.getSize().width; } } k = localDimension.width - (k +
		 * n); if ((i == 0) || (i == 1)) ; switch (j) { case 1: break; case 2: j
		 * = 0; break; case 0: default: j = 2; break; if (i == 2) i = 3; else i
		 * = 2; } }
		 */
		
		int aOffset = getAOF() * scale / 100;
		int eOffset = getEOF() * scale / 100;
		if (eal == PROMPT_EAL_END) {
			aOffset *= -1;
		}

		Point p = new Point(0, 0);

		switch (edg) {
		case PROMPT_EDG_TOP:
			p.x = x;
			p.y = y - eOffset - mHeight;
			switch (eal) {
			case PROMPT_EAL_CENTER:
				p.x += (w - mWidth) / 2;
				break;
			case PROMPT_EAL_END:
				p.x += w - mWidth;
				break;
			}
			p.x += aOffset;
			break;
		case PROMPT_EDG_BOT:
			p.x = x;
			p.y = y + eOffset + h;
			switch (eal) {
			case PROMPT_EAL_CENTER:
				p.x += (w - mWidth) / 2;
				break;
			case PROMPT_EAL_END:
				p.x += w - mWidth;
				break;
			}
			p.x += aOffset;
			break;
		case PROMPT_EDG_END:
			p.x = x + w + eOffset;
			p.y = y;
			switch (eal) {
			case PROMPT_EAL_CENTER:
				p.y += (h - mHeight) / 2;
				break;
			case PROMPT_EAL_END:
				p.y += h - mHeight;
				break;
			}
			p.y += aOffset;
			break;
		case PROMPT_EDG_START:
		default:
			p.x = x - mWidth - eOffset;
			p.y = y;
			switch (eal) {
			case PROMPT_EAL_CENTER:
				p.y += (h - mHeight) / 2;
				break;
			case PROMPT_EAL_END:
				p.y += h - mHeight;
				break;
			}
			p.y += aOffset;
			break;
		}
		
		mBoundingBox.x = p.x;
		mBoundingBox.y = p.y;
		mBoundingBox.width = mWidth;
		mBoundingBox.height = mHeight;
		
		setDirty(false);
	}

	public void damagePrompt(FormCanvas canvas) {
		if ((mBoundingBox.width != 0) && (mBoundingBox.height != 0))
			canvas.getPanel().repaint(0L, mBoundingBox.x, mBoundingBox.y,
					mBoundingBox.width, mBoundingBox.height);
		computeBoundingBox(canvas);
		if ((mBoundingBox.width != 0) && (mBoundingBox.height != 0))
			canvas.getPanel().repaint(0L, mBoundingBox.x, mBoundingBox.y,
					mBoundingBox.width, mBoundingBox.height);
	}

	public boolean redrawNeeded(Rectangle rect) {
		boolean bool;
		if (mFirst == true) {
			mFirst = false;
			bool = true;
		} else {
			bool = rect.intersects(mBoundingBox);
		}
		return bool;
	}

	public void drawPrompt(Graphics g, Device device, FormCanvas canvas) {
		int tal = (byte) (mEnumVal >> PROMPT_TAL_SHIFT & PROMPT_TAL_MASK);
		int align;
		if ((mReadingDirection == 1)
				|| ((mReadingDirection == 0) && (canvas.getDeviceDirection() == 2))) {
			if (tal == 0) {
				tal = PROMPT_TAL_RIGHT;
			}
			else if (tal == PROMPT_TAL_END) {
				tal = PROMPT_TAL_LEFT;
			}
			align = Alignment.ID_RIGHT;
		} else {
			align = Alignment.ID_LEFT;
		}

		if (isDirty()) {
			computeBoundingBox(canvas);
		}

		Point pos = new Point();
		pos.x = mBoundingBox.x;
		pos.y = mBoundingBox.y;

		Font oldFont = g.getFont();
		Color oldColor = g.getColor();

		if (getColorNum() == 255) {
			if (canvas.getDispatcher().getApplet().hasDarkLook())
				mColor = device.getColorEntry(0);
			else
				mColor = UIManager.getLookAndFeel()
						.getDefaults(canvas.getPanel().getPaintContext())
						.getColor(LookAndFeel.TEXT_TEXT);
		} else {
			mColor = device.getColorEntry(getColorNum());
		}

		g.setColor(mColor);
		g.setFont(mFont);

		Locale locale = LocaleUtils.getDefaultableLocale(device.getComponent());
		byte style = device.getStyle(getFontNum());

		for (int m = 0; m < mTextVal.size(); m++) {
			String text = mTextVal.elementAt(m);
			String str = StringUtils.getDisplayString(text, locale, align);
			int strWidth = mFontMetrics.stringWidth(str);

			pos.y += mFontMetrics.getHeight();

			switch (tal) {
			case PROMPT_TAL_END:
			case PROMPT_TAL_RIGHT:
				pos.x = (mBoundingBox.x + mWidth - strWidth);
				break;
			case PROMPT_TAL_CENTER:
				pos.x = (mBoundingBox.x + (mWidth - strWidth) / 2);
				break;
			}

			pos.y -= mFontMetrics.getDescent();
            if (mVisible && mFrameVisible) {
                GraphicUtils.drawString(g, str, pos.x, pos.y);
                Text.drawUnderlineOverstrike(g, str, pos.x, pos.y, style);
            }
			pos.y += mFontMetrics.getDescent();
		}

		g.setFont(oldFont);
		g.setColor(oldColor);
	}

	public void doDestroy() {
		mItemInfo = null;
		mBoundingBox = null;
		mTextVal = null;
	}
	
	public int getX() {
		return mItemInfo.getItemX();
	}
	
	public int getY() {
		return mItemInfo.getItemY();
	}

    public int getOriginalX() {
        return mOriginalX;
    }

	public int getOriginalY() {
		return mOriginalY;
	}

	public Point getLocation() {
		return new Point(getX(), getY());
	}

	public void setLocation(int x, int y) {
		mItemInfo.setItemPosition(new Point(x, y));
		setDirty(true);
	}

	public boolean isVisible() {
		return mVisible;
	}

	public void setVisible(boolean visible) {
		mVisible = visible;
		setDirty(true);
	}

    public boolean isFrameVisible() {
        return mFrameVisible;
    }

    public void setFrameVisible(boolean visible) {
        mFrameVisible = visible;
        setDirty(true);
    }
}