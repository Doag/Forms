--
-- Demo : Autocomplete Combo Box
-- Friedhold Matz, 16.09.2007
--
create table europecities( 
 name varchar2 (30)
 constraint pk_name primary key  
)
/
	

		insert into europecities values ('Berlin');
		insert into europecities values ('Paris');
		insert into europecities values ('Kopenhagen');
		insert into europecities values ('Hamburg');
		insert into europecities values ('Stockholm');
		insert into europecities values ('Amsterdam');
		insert into europecities values ('Dublin');
		insert into europecities values ('Rom');
		insert into europecities values ('Madrid');
		insert into europecities values ('Mailand');
		insert into europecities values ('Barcelona');
		insert into europecities values ('Valencia');
		insert into europecities values ('Padua');
		insert into europecities values ('Wien');
		insert into europecities values ('Budapest');
		insert into europecities values ('Luxemburg');
		insert into europecities values ('Br�ssel');
		insert into europecities values ('Oslo');
		insert into europecities values ('Bratislava');
		insert into europecities values ('Granada');
		insert into europecities values ('Sankt Petersburg');
		insert into europecities values ('Prag');
		insert into europecities values ('Warschau');
		insert into europecities values ('Lissabon');
		insert into europecities values ('Florenz');
		insert into europecities values ('Venedig');
		insert into europecities values ('Sevillia');
		insert into europecities values ('Marseille');
		insert into europecities values ('Neapel');
		insert into europecities values ('Cork');
		insert into europecities values ('Limerick');
		insert into europecities values ('Edinburgh');
		insert into europecities values ('London');
		insert into europecities values ('Moskau');
		insert into europecities values ('Kiew');
		insert into europecities values ('Malaga');
		insert into europecities values ('Toledo');
		insert into europecities values ('Bilbao');
		insert into europecities values ('Nizza');
		insert into europecities values ('Toulouse');
		insert into europecities values ('Bordeaux');
		insert into europecities values ('Strassburg');
		insert into europecities values ('Dresden');
		insert into europecities values ('K�ln');
		insert into europecities values ('Mannheim');
		insert into europecities values ('N�rnberg');
		insert into europecities values ('Z�rich');
		insert into europecities values ('Bern');
		insert into europecities values ('Genf');
		insert into europecities values ('Utrecht');
		insert into europecities values ('Leipzig');
		insert into europecities values ('Stuttgart');
		insert into europecities values ('Linz');
		insert into europecities values ('Salzburg');
		insert into europecities values ('Breslau');
		insert into europecities values ('Spremberg');
		insert into europecities values ('Cottbus');
		insert into europecities values ('Faro');
		insert into europecities values ('Albufeira');
		insert into europecities values ('Gibraltar');
		insert into europecities values ('Porto');
		insert into europecities values ('Ennis');
		insert into europecities values ('Galway');
		insert into europecities values ('Belfast');
		insert into europecities values ('Lille');
		insert into europecities values ('T�bingen');
		insert into europecities values ('Heidelberg');
		insert into europecities values ('W�rzburg');
		insert into europecities values ('M�nchen');
		insert into europecities values ('Freiburg');
		insert into europecities values ('Lyon');
		insert into europecities values ('Liverpool');
		insert into europecities values ('Birmingham');
		insert into europecities values ('Glasgow');
		insert into europecities values ('Helsinki');
		insert into europecities values ('San Sebastian');
		insert into europecities values ('Palermo');
		insert into europecities values ('Krakau');
		insert into europecities values ('Tallin');
		insert into europecities values ('Riga');
		insert into europecities values ('Vilnius');
		insert into europecities values ('Belgrad');

COMMIT;

