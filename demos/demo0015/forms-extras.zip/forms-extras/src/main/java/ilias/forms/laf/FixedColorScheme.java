package ilias.forms.laf;

import java.awt.Color;
import java.awt.image.ImageFilter;
import java.util.Locale;
import oracle.ewt.ColorScheme;
import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.graphics.NullImageFilter;

class FixedColorScheme extends ColorScheme {

	public String getName() {
		return "IliasFixedColor";
	}

	public String getDisplayName(Locale paramLocale) {
		return getName();
	}

	public String getDescription(Locale paramLocale) {
		return "Fixed Color Scheme for Ilias Look and Feel";
	}

	public final Color getDefiningColor() {
		return Color.lightGray;
	}

	public final ImageFilter createColorizingFilter() {
		return NullImageFilter.getImageFilter();
	}

	public final void initializeColors(UIDefaults defaults) {
		Color localColor1 = Color.white;
		Color localColor2 = new Color(14671839);
		Color localColor3 = Color.lightGray;
		Color localColor4 = Color.gray;
		Color localColor5 = Color.black;
		Color localColor6 = new Color(16777185);
		Color localColor7 = new Color(128);
		Color localColor8 = new Color(-129);
		Color localColor9 = new Color(32896);
		Object[] colorArray = { //
				LookAndFeel.DESKTOP, localColor9, //
				LookAndFeel.ACTIVE_CAPTION, localColor7, //
				LookAndFeel.ACTIVE_CAPTION_TEXT, localColor1, //
				LookAndFeel.ACTIVE_CAPTION_BORDER, localColor3, //
				LookAndFeel.INACTIVE_CAPTION, localColor4, //
				LookAndFeel.INACTIVE_CAPTION_TEXT, localColor3, //
				LookAndFeel.INACTIVE_CAPTION_BORDER, localColor3, //
				LookAndFeel.DIALOG, localColor3, //
				LookAndFeel.WINDOW, localColor1, //
				LookAndFeel.WINDOW_BORDER, localColor5, //
				LookAndFeel.WINDOW_TEXT, localColor5, //
				LookAndFeel.MENU, localColor3, //
				LookAndFeel.MENU_TEXT, localColor5, //
				LookAndFeel.TEXT_TEXT, localColor5, //
				LookAndFeel.TEXT_HIGHLIGHT, localColor7, //
				LookAndFeel.TEXT_HIGHLIGHT_TEXT, localColor1, //
				LookAndFeel.TEXT_INACTIVE_TEXT, localColor4, //
				LookAndFeel.CONTROL, localColor3, //
				LookAndFeel.CONTROL_TEXT, localColor5, //
				LookAndFeel.CONTROL_HIGHLIGHT, localColor2, //
				LookAndFeel.CONTROL_LT_HIGHLIGHT, localColor1, //
				LookAndFeel.CONTROL_SHADOW, localColor4, //
				LookAndFeel.CONTROL_DK_SHADOW, localColor5, //
				LookAndFeel.SCROLLBAR, localColor6, //
				LookAndFeel.INFO, localColor6, //
				LookAndFeel.INFO_TEXT, localColor5, //
				LookAndFeel.TEXT, localColor1, //
				LookAndFeel.SECONDARY_TEXT_HIGHLIGHT, localColor7, //
				LookAndFeel.LIGHT_INTENSITY, localColor2, //
				LookAndFeel.NORMAL_INTENSITY, localColor3, //
				LookAndFeel.DARK_INTENSITY, localColor4, //
				LookAndFeel.VERY_DARK_INTENSITY, localColor5, //
				LookAndFeel.LIGHT_LOOK, localColor3, //
				LookAndFeel.DARK_LOOK, localColor3, //
				LookAndFeel.VERY_DARK_LOOK, localColor3, //
				LookAndFeel.CONTROL_INACTIVE_TEXT, localColor4, //
				LookAndFeel.CONTROL_INACTIVE, localColor3, //
				LookAndFeel.TOOL_TIP, localColor6, //
				LookAndFeel.SELECTED_FOCUS, localColor8 };
		defaults.putDefaults(colorArray);
	}
}
