package ilias.forms.vgs;

import ilias.forms.handler.IliasFormCanvas;
import ilias.forms.handler.IliasPromptItem;
import ilias.forms.vgs.IliasDisplayFrame.ComponentInFrame;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.DataInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import oracle.forms.engine.Main;
import oracle.forms.handler.FormCanvas;
import oracle.forms.ui.DrawnPanel;
import oracle.forms.ui.ExtendedFrame;
import oracle.graphics.vgs.ui.Arc;
import oracle.graphics.vgs.ui.Device;
import oracle.graphics.vgs.ui.Generic;
import oracle.graphics.vgs.ui.Graphic;
import oracle.graphics.vgs.ui.Group;
import oracle.graphics.vgs.ui.Line;
import oracle.graphics.vgs.ui.PackedTree;
import oracle.graphics.vgs.ui.Rect;
import oracle.graphics.vgs.ui.RoundRect;
import oracle.graphics.vgs.ui.Symbol;
import oracle.graphics.vgs.ui.Text;
import oracle.graphics.vgs.ui.VGImage;
import oracle.graphics.vgs.ui.VPolygon;

public class IliasDisplayGroup extends Generic {

	private Generic[] mKids;
	private Rectangle[] mKidRectangles;
	private boolean[] mKidVisible;
	private static byte mDeviceDirection;
	private static int mDeviceWidth;
	private boolean mHighContrast = false;
	private String mFrameBackgroundColor;
	private String mFrameBorderColor;
	private IliasFormCanvas mFormCanvas;
	private boolean mLayoutInvalid = true;

	public IliasDisplayGroup(Main main, IliasFormCanvas formCanvas) {
		setClassType((byte) 2);
		mFormCanvas = formCanvas;
		mHighContrast = main.isHighContrast();
		mFrameBackgroundColor = main.getParameter("FrameBackgroundColor");
		if (mFrameBackgroundColor != null
				&& mFrameBackgroundColor.trim().equals("")) {
			mFrameBackgroundColor = null;
		}
		mFrameBorderColor = main.getParameter("FrameBorderColor");
		if (mFrameBorderColor != null && mFrameBorderColor.trim().equals("")) {
			mFrameBorderColor = null;
		}
	}

	public synchronized void onDestroy() {
		mFormCanvas = null;
        for(Generic kid : mKids) {
            if (kid instanceof IliasDisplayGroup) {
                ((IliasDisplayGroup)kid).onDestroy();
            } else if (kid instanceof IliasDisplayFrame) {
                ((IliasDisplayFrame)kid).onDestroy();
            }
        }
	}

	public void invalidateLayout() {
		mLayoutInvalid = true;
	}

	public int unpackTree(PackedTree tree) throws IOException {
		DataInputStream stream = tree.getStream(1);
		super.pUnpack(tree, stream);

		int pData = stream.readInt();
		int nKids = stream.readInt();

		int[] pKids = new int[nKids];

		stream.readByte(); // Clip

		mKids = new Generic[nKids];
		mKidRectangles = new Rectangle[nKids];
		mKidVisible = new boolean[nKids];

		int k = 0;
		if (nKids > 0) {
			stream = tree.getStream(pData);
			for (int i = nKids - 1; i >= 0; i--) {
				pKids[i] = stream.readInt();
			}
			for (int i = nKids - 1; i >= 0; i--) {
				stream = tree.getStream(pKids[i]);
                int type = stream.readByte();

				Generic generic = null;
				switch (type) {
				case 2:
					generic = new Group();
					break;
				case 9:
					generic = new Text();
					break;
				case 5:
					generic = new Line();
					break;
				case 8:
					generic = new Rect();
					break;
				case 7:
					generic = new VPolygon();
					break;
				case 3:
					generic = new Arc();
					break;
				case 6:
					generic = new RoundRect();
					break;
				case 4:
					generic = new VGImage();
					break;
				case 10:
					generic = new Symbol();
					break;
				case 11:
					generic = new IliasDisplayFrame(mHighContrast, this, mFormCanvas);
					break;
				default:
					break;
				}

				generic.pUnpack(tree, stream);
				mKids[k] = generic;
				mKidRectangles[k] = new Rectangle(generic.getX(), generic.getY(), generic.getWidth(), generic.getHeight());
				mKidVisible[k] = true;
				k++;

				if (generic instanceof IliasDisplayFrame) {
					IliasDisplayFrame frame = (IliasDisplayFrame) generic;
					try {
						if (mFrameBackgroundColor != null) {
							try {
                                short color = Short.parseShort(mFrameBackgroundColor);
                                Method m = Graphic.class.getDeclaredMethod("setBackFillColor", short.class);
                                m.setAccessible(true);
                                m.invoke(frame, color);
							} catch (NumberFormatException e) {
								// Ignore
							}
						}
						if (mFrameBorderColor != null) {
							try {
                                short color = Short.parseShort(mFrameBorderColor);
                                Method m = Graphic.class.getDeclaredMethod("setForeEdgeColor", short.class);
                                m.setAccessible(true);
                                m.invoke(frame, color);
							} catch (NumberFormatException e) {
								// Ignore
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			
			if (k != nKids) {
				Generic[] genericArr = new Generic[k];
				System.arraycopy(mKids, 0, genericArr, 0, k);
				mKids = genericArr;

				Rectangle[] rectangleArr = new Rectangle[k];
				System.arraycopy(mKidRectangles, 0, rectangleArr, 0, k);
				mKidRectangles = rectangleArr;

				boolean[] visibleArr = new boolean[k];
				System.arraycopy(mKidVisible, 0, visibleArr, 0, k);
				mKidVisible = visibleArr;
			}
		}

		setDirty(true);

		return 1;
	}

	public static byte getDeviceDirection() {
		return mDeviceDirection;
	}

	public static int getDeviceWidth() {
		return mDeviceWidth;
	}

	public void drawGraphic(Graphics g, Device device) {
		if (mLayoutInvalid) {
			doLayout();
			mLayoutInvalid = false;
			mFormCanvas.getPanel().repaint();
		} else {
			int n = mKids.length;

			mDeviceDirection = device.getDeviceDirection();
			mDeviceWidth = device.getDeviceSize().x;

			if (device instanceof FormCanvas
					&& ((FormCanvas) device).isToLeft()) {
				FormCanvas cvs = (FormCanvas) device;
				if (cvs.getPanel().getCanvasType() == 0 && !cvs.isTabCanvas()) {
					ExtendedFrame frame = (ExtendedFrame) cvs.getParentWindow();
					if (frame != null) {
						DrawnPanel panel = frame.getVerticalToolbar();
						if (panel != null && panel.isVisible()) {
							mDeviceWidth -= panel.getSize().width;
						}
					}
				}
			}

			for (int i = n - 1; i >= 0; i--) {
				if (mKidVisible[i]) {
					Generic generic = mKids[i];
					generic.drawGraphic(g, device);
				}
			}
		}
	}

	public void doLayout() {
		int n = mKids.length;

        int scale = 100;

		Map<Integer, List<Integer>> map = new TreeMap<Integer, List<Integer>>();
        
        // Make a map of frames, keyed by each y position
		for (int i = 0; i < n; i++) {
			Generic generic = mKids[i];
			if (generic instanceof IliasDisplayFrame) {
				Rectangle rect = mKidRectangles[i];
                int y = rect.y * scale / 100;
                List<Integer> list = map.get(y);
				if (list == null) {
					list = new ArrayList<Integer>();
					map.put(y, list);
				}
				list.add(i);
			}
		}

		int offset = 0;
		for (List<Integer> list : map.values()) {
			int rowHeight = 0;
			int newRowHeight = 0;
			for (Integer item : list) {
				int i = item.intValue();
				Generic generic = mKids[i];
				if (generic instanceof IliasDisplayFrame) {
					IliasDisplayFrame frame = (IliasDisplayFrame) generic;

					// Set height of frame as a function of collapsed
					Rectangle rect = mKidRectangles[i];
                    int x = rect.x * scale / 100;
                    int y = rect.y * scale / 100;
                    int w = (rect.x + rect.width) * scale / 100 - x;
                    int h = (rect.y + rect.height) * scale / 100 - y;
                    rect = new Rectangle(x, y, w, h);

                    // Set frame Y position and height
                    frame.setY(rect.y - offset * scale / 100);
                    frame.setHeight(frame.isCollapsed() ? 36 * scale / 100 : rect.height);

					// New size of frame
                    Rectangle r = new Rectangle(frame.getX(), frame.getY(), frame.getWidth(), frame.getHeight());

					// Move components that are in the frame
					List<ComponentInFrame> componentsInFrame = frame.getComponentsInFrame();
					if (componentsInFrame != null) {
						for (ComponentInFrame c : componentsInFrame) {
                            Component comp = c.getC();
                            comp.setLocation(comp.getX(), (c.getY() - offset) * scale / 100);
                            Point topLeft = comp.getLocation();
                            comp.setVisible(r.contains(topLeft) && c.isServerVisible());
						}
					}

					// Move prompts that are in the frame
                    List<IliasPromptItem> promptsInFrame = frame.getPromptsInFrame();
                    if (promptsInFrame != null) {
                        Rectangle fr = new Rectangle(mKidRectangles[i]);
                        fr.y = fr.y - offset;
                        fr.height = frame.isCollapsed() ? 36 : fr.height;
                        for (IliasPromptItem prompt : promptsInFrame) {
                            int px = prompt.getX();
                            int py = prompt.getOriginalY() - offset;
                            prompt.setLocation(px, py);
							Point topLeft = prompt.getLocation();
                            prompt.setFrameVisible(fr.contains(topLeft));
						}
					}

					// Move other graphics that are in the frame
					for (int k = 0; k < n; k++) {
						if (i != k) {
							Generic other = mKids[k];
							if (!(other instanceof IliasDisplayFrame)) {
								Rectangle otherRect = mKidRectangles[k];
                                int ox = otherRect.x * scale / 100;
                                int oy = otherRect.y * scale / 100;
                                Point topLeft = new Point(ox, oy);
                                if (rect.contains(topLeft)) {
                                    topLeft.y -= offset * scale / 100;
									other.setY(topLeft.y);
									mKidVisible[k] = r.contains(topLeft);
									other.setDirty(true);
								}
							}
						}
					}

                    rowHeight = Math.max(rowHeight, mKidRectangles[i].height);
                    newRowHeight = Math.max(newRowHeight, frame.isCollapsed() ? 36 : mKidRectangles[i].height);

					frame.setDirty(true);
				}
			}
			offset += rowHeight - newRowHeight;
		}
	}

    /**
     * Rescale all elements in the group
     * 
     * @param scale
     */
	public void rescale(int scale) {
		int n = mKids.length;
		for (int i = 0; i < n; i++) {
			Rectangle rect = mKidRectangles[i];
			int x1 = rect.x * scale / 100;
			int y1 = rect.y * scale / 100;
			int x2 = (rect.x + rect.width) * scale / 100;
			int y2 = (rect.y + rect.height) * scale / 100;
			Generic generic = mKids[i];
			generic.setX(x1);
			generic.setY(y1);
			generic.setWidth(x2 - x1);
			generic.setHeight(y2 - y1);
			generic.setDirty(true);
            if (generic instanceof IliasDisplayFrame) {
                ((IliasDisplayFrame)generic).rescale(scale);
            }
		}
        invalidateLayout();
	}
}