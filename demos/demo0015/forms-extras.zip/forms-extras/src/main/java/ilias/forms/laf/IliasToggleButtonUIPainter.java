package ilias.forms.laf;

import java.awt.Dimension;
import java.awt.Graphics;

import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AbstractPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;

public class IliasToggleButtonUIPainter extends AbstractPainter {

	private Painter _painter1;
	private Painter _painter2;

	public IliasToggleButtonUIPainter(Painter painter1, Painter painter2) {
		_painter1 = painter1;
		_painter2 = painter2;
	}

	public Dimension getMinimumSize(PaintContext ctx) {
		return _painter1.getMinimumSize(ctx);
	}

	public void paint(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		// The checkbox or radio button is a child component of the VRadioButton or VCheckbox
		LWComponent button = (LWComponent)ctx.getImageObserver();
		LWComponent parent = (LWComponent)button.getParent();
		// Set the VRadioButtonField or VCheckBoxField for the state 256,
		// which is set in enter query mode
		if ((parent.getPaintContext().getPaintState() & 256) != 0) {
			_painter2.paint(ctx, g, x, y, w, h);
		} else {
			_painter1.paint(ctx, g, x, y, w, h);
		}
	}
}
