package ilias.forms.handler;

import java.awt.BorderLayout;
import java.awt.Component;
import java.beans.PropertyChangeEvent;

import oracle.ewt.layout.MaximumBorderLayout;
import oracle.ewt.lwAWT.lwWindow.LWWindow;
import oracle.ewt.lwAWT.lwWindow.laf.TitleBar;
import oracle.forms.handler.FormCanvas;
import oracle.forms.handler.FormWindow;

public class IliasFormWindow extends FormWindow {

	@Override
	public void propertyChange(PropertyChangeEvent event) {
		// Remove title bar when a window is maximized
		super.propertyChange(event);
		if (event.getPropertyName() == LWWindow.PROPERTY_MAXIMIZED) {
			LWWindow window = getWindow();
			MaximumBorderLayout layout = (MaximumBorderLayout) window.getLayout();
			Component titleBar = layout.getLayoutComponent(BorderLayout.NORTH);
			if (window.isMaximized()) {
				if (titleBar != null) {
					window.remove(titleBar);
				}
			} else {
				if (titleBar == null) {
					titleBar = new TitleBar(window);
					window.add(BorderLayout.NORTH, titleBar);
				}
			}
		}
	}

	/**
	 * Do not set the status bar on a window
	 */
	@Override
	protected void setStatusBar(FormCanvas canvas) {
		// super.setStatusBar(canvas);
	}

	@Override
	public void createMenu() {
		// Do not create a menu on a window
	}
}
