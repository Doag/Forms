package ilias.forms.ui;

import ilias.forms.laf.IliasLookAndFeel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import oracle.ewt.EwtComponent;
import oracle.ewt.button.PushButton;
import oracle.ewt.lwAWT.LWChoice;
import oracle.ewt.lwAWT.LWContainer;
import oracle.ewt.lwAWT.LWLabel;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.NullPainter;

public class DatePanel extends LWContainer implements KeyListener {
	private static final long serialVersionUID = 6627930260179785651L;

	private DateDialog dialog;
    
    /** Graphic area for display the year */
    private DialogDateDay ddd;
    
    /** Save the date */
    private DateCalendar save;
    
    /** buttons to handles the change of date EV 20031027 **/
    private DatePanelButton jbPrevMonth, jbNextMonth;
    private DatePanelButton jbPrevYear, jbNextYear;	

    private LWLabel jtDate;
    private LWChoice jtHour;	
    private LWChoice jtMinute;
    
    private static Image prevYear = getImage("/icons/prevyear.gif");
    private static Image nextYear = getImage("/icons/nextyear.gif");
    private static Image prevMonth = getImage("/icons/prevmonth.gif");
    private static Image nextMonth = getImage("/icons/nextmonth.gif");
    private static SimpleDateFormat fmt = new SimpleDateFormat("MMM yyyy");
    private static int CELL_W = 34;
    private static int CELL_H = 16;
      
	public DatePanel(DateDialog dialog, DateCalendar date, boolean withTime) {
        setLayout(new BorderLayout(4,4));

        this.dialog = dialog;
        this.save = date;
        
        if ( date == null ) {
            date = new DateCalendar();
        }
        
        ddd = new DialogDateDay(date);
        ddd.addKeyListener(this);

        LWContainer lb = new LWContainer();
        lb.setLayout(new GridLayout(1,2));
        LWContainer rb = new LWContainer();
        rb.setLayout(new GridLayout(1,2));
        LWContainer top = new LWContainer();
        top.setLayout(new BorderLayout());

        jbPrevYear = new DatePanelButton();
        jbPrevYear.setImage(prevYear);
		jbPrevYear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				rollDate(Calendar.YEAR, -1);
			}
		});
        jbPrevMonth = new DatePanelButton();
        jbPrevMonth.setImage(prevMonth);
		jbPrevMonth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				rollDate(Calendar.MONTH, -1);
			}
		});
        jbNextMonth = new DatePanelButton();
        jbNextMonth.setImage(nextMonth);
		jbNextMonth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				rollDate(Calendar.MONTH, +1);
			}
		});
		jbNextYear = new DatePanelButton();
		jbNextYear.setImage(nextYear);
		jbNextYear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				rollDate(Calendar.YEAR, +1);
			}
		});
/*          
        jbPrevYear.setToolTipText(GanttProject.getToolTip(language.getText("prevYear")));
        jbPrevMonth.setToolTipText(GanttProject.getToolTip(language.getText("prevMonth")));
        jbNextMonth.setToolTipText(GanttProject.getToolTip(language.getText("nextMonth")));
        jbNextYear.setToolTipText(GanttProject.getToolTip(language.getText("nextYear")));
*/
        jtDate = new LWLabel();
        jtDate.setText(fmt.format(ddd.date.getTime()));
        jtDate.setAlignment(LWLabel.CENTER);
        jtDate.setBackground(IliasLookAndFeel.DARK);
        jtDate.setForeground(Color.white);
        
        lb.add(jbPrevYear);
        lb.add(jbPrevMonth);
        rb.add(jbNextMonth);
        rb.add(jbNextYear);
        
        top.add(BorderLayout.WEST, lb);
        top.add(BorderLayout.EAST, rb);
        top.add(BorderLayout.CENTER, jtDate);

        add("North", top);
        add("Center", ddd);
        
        if (withTime) {
            LWContainer bottom = new LWContainer();
            //bottom.setLayout(new GridLayout(1,5));
            bottom.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));

            LWLabel jtHourLabel = new LWLabel("Hour:");
            jtHourLabel.setAlignment(LWLabel.RIGHT);
            bottom.add(jtHourLabel);
            
            jtHour = new LWChoice();
            for(int i=0; i<24; i++) {
            	jtHour.addItem(String.format("%02d", i));
            }
            jtHour.setSize(30, 20);
            jtHour.select(date.get(GregorianCalendar.HOUR_OF_DAY));
            bottom.add(jtHour);

            LWLabel jtMinuteLabel = new LWLabel("Minute:");
            jtMinuteLabel.setAlignment(LWLabel.RIGHT);
            bottom.add(jtMinuteLabel);

            jtMinute = new LWChoice();
            for(int i=0; i<60; i++) {
            	jtMinute.addItem(String.format("%02d", i));
            }
            jtMinute.setSize(30, 20);
            jtMinute.select(date.get(GregorianCalendar.MINUTE));
            bottom.add(jtMinute);

            add("South", bottom);
        }
    }

	public void setInitialFocus() {
		ddd.setEnabled(true);
		ddd.requestFocus();
	}

	private static Image getImage(String s) {
		InputStream in = VDateField.class.getResourceAsStream(s);
		try {
			int n = in.available();
			byte[] bytes = new byte[n];
			int o = 0;
			while ((o += in.read(bytes, o, n - o)) < n)
				;
			in.close();
			return Toolkit.getDefaultToolkit().createImage(bytes);
		} catch (Exception e) {
			return null;
		}
	}

	public void cancel() {
		ddd.date = save;
	}
  
    /** Return The selected date. */
	public DateCalendar getDate() {
		DateCalendar result = ddd.date;
		if (jtHour != null) {
			int hh = Integer.parseInt(jtHour.getSelectedItem());
			result.set(GregorianCalendar.HOUR_OF_DAY, hh);
		}
		if (jtMinute != null) {
			int mm = Integer.parseInt(jtMinute.getSelectedItem());
			result.set(GregorianCalendar.MINUTE, mm);
		}
		return result;
	}

    /** Fill the content of the central label **/
	private void changeDate(DateCalendar newDate) {
        boolean differentMonth = 
          (ddd.date.get(Calendar.MONTH) != newDate.get(Calendar.MONTH)) ||
          (ddd.date.get(Calendar.YEAR) != newDate.get(Calendar.YEAR));
        ddd.date.setTime(newDate.getTime());
		if (differentMonth) {
            jtDate.setText(fmt.format(ddd.date.getTime()));
            ddd.repaint();
        } 
    }
  
    /** This function rolls the date **/
	private void rollDate(int field, int amount) {
        ddd.date.add(field, amount);
        jtDate.setText(fmt.format(ddd.date.getTime()));
        ddd.repaint();
    }

    ////////////////////////////////////////////////////////////////////////////
    
	public class DialogDateDay extends EwtComponent {
		
		private static final long serialVersionUID = -7097939755297798781L;

		public DateCalendar date;
    
        /** Constructor */		
		public DialogDateDay(DateCalendar date) {
            this.date = date;
            MouseListener ml = new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    clickFunction(e.getX(), e.getY());
                }
                public void mouseClicked(MouseEvent e) {
                    if ( e.getClickCount() > 1 )
                        dialog.endDialog();
                }
            };
            this.addMouseListener(ml);
        }
        
        /** The default size. */
		public Dimension getPreferredSize() {
			return new Dimension(8 * CELL_W + 2, 7 * CELL_H + 4);
		}
        
        /** When the user click on the widget */
		public void clickFunction(int x, int y) {
            // Has the user clicked on the panel???
            if(x > CELL_W && x < CELL_W*8 && y > CELL_H && y < 7*CELL_H)
            {
                int X = (x / CELL_W) - 1;
                int Y = (y / CELL_H) - 1;
  
                // Recup the first monday
                DateCalendar tmpdate = date.Clone();
                tmpdate.setDay(1);
                String d = tmpdate.getdayWeek();
                while(!d.equals(DateCalendar.days[1]))
                {
                    tmpdate.go(Calendar.DATE,-1);
                    d = tmpdate.getdayWeek();
                }
                
                // Search the exact day
                for(int i=0; i<Y*7+X; i++) {
                    tmpdate.go(Calendar.DATE,1);
                }
                //Check the validity of the month
                //if(tmpdate.getMonth() == date.getMonth())	
                //	date = tmpdate;
                changeDate(tmpdate);
             }
             repaint();
        }
      
        /** draw the panel */
		public void paintCanvasInterior(Graphics g) {
			Color oldColor = g.getColor();

			int sizex = getWidth();
            int sizey = getHeight();
            
			// Display the legend at top
            g.setColor(Color.white);
            g.fillRect(0,0,sizex,sizey);
            
            FontMetrics fm = g.getFontMetrics();
            
			// Draw days of week
			g.setColor(IliasLookAndFeel.LIGHT);
			g.fillRect(0, 0, sizex, CELL_H + 1);
			String[] dayWeek = date.getDayWeekLanguage();
			g.setColor(Color.white);
			for (int i = 1; i <= dayWeek.length; i++) {
				String dw = dayWeek[i % 7];
				String s = dw.substring(0, dw.length() < 3 ? dw.length() : 3);
				drawStringCentered(g, fm, s, 1 + i * CELL_W, CELL_H - 3, CELL_W);
			}
            
            DateCalendar tmpdate = date.Clone();
            tmpdate.setDay(1);
            String d = tmpdate.getdayWeek();
			while (!d.equals(DateCalendar.days[1])) {
                tmpdate.go(Calendar.DATE,-1);
                d = tmpdate.getdayWeek();
            }
            
			for (int i = 1; i <= 6; i++) {
                // The week
				g.setColor(Color.red);
				drawStringCentered(g, fm, "" + tmpdate.getWeek(), 1, 2 + CELL_H + i * CELL_H - 3, CELL_W);
                
                // The days
				for (int j = 1; j <= 7; j++) {
					if (tmpdate.getMonth() != date.getMonth()) {
						g.setColor(Color.gray);
					} else {
						if (tmpdate.getDay() == date.getDay()) {
							g.setColor(IliasLookAndFeel.LIGHT);
							g.fillRect(2 + j * CELL_W, 2 + i * CELL_H, CELL_W - 2, CELL_H);
							g.setColor(Color.white);
						} else {
                            g.setColor(Color.black);
						}
                    }
                    drawStringCentered(g, fm, ""+tmpdate.getDate(), 1+j*CELL_W, 2+CELL_H+i*CELL_H-3, CELL_W);
                    tmpdate.go(Calendar.DATE,1);
                }			
            }	

			// Draw border
			g.setColor(IliasLookAndFeel.DARK);
			g.drawRect(0, 0, sizex - 1, sizey - 1);
			g.drawRect(1, 1, sizex - 3, sizey - 3);
			// Draw line
			g.drawLine(CELL_W, 0, CELL_W, CELL_H * 7 + 3);
			g.drawLine(CELL_W + 1, 0, CELL_W + 1, CELL_H * 7 + 3);
			g.drawLine(0, CELL_H, CELL_W * 8, CELL_H);
			g.drawLine(0, CELL_H + 1, CELL_W * 8, CELL_H + 1);
			
			g.setColor(oldColor);
        }

		private void drawStringCentered(Graphics g, FontMetrics fm,
				String text, int x, int y, int w) {
            int uw = fm.stringWidth(text);
            g.drawString(text, x + (w-uw)/2, y);
        }
        
		public boolean isFocusTraversable() {
            return isEnabled();
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    
	public void keyTyped(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
		if (!isEnabled() || e.isConsumed())
			return;

		switch (e.getKeyCode()) {
		case KeyEvent.VK_RIGHT:
			rollDate(Calendar.DATE, +1);
			e.consume();
			break;
		case KeyEvent.VK_LEFT:
			rollDate(Calendar.DATE, -1);
			e.consume();
			break;
		case KeyEvent.VK_DOWN:
			rollDate(Calendar.WEEK_OF_YEAR, +1);
			e.consume();
			break;
		case KeyEvent.VK_UP:
			rollDate(Calendar.WEEK_OF_YEAR, -1);
			e.consume();
			break;
		case KeyEvent.VK_SPACE:
			e.consume();
			break;
		case KeyEvent.VK_ESCAPE:
			dialog.cancelDialog();
			e.consume();
			break;
		}
	}

	public void keyReleased(KeyEvent e) {
	}

	static class DatePanelButton extends PushButton {

		private static final long serialVersionUID = 1L;

		@Override
		public BorderPainter getBorderPainter() {
			return NullPainter.getPainter();
		}
	}
}

