package ilias.forms.handler;

import ilias.forms.laf.IliasRectanglePainter;

import java.awt.Component;

import oracle.ewt.EwtComponent;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.scrolling.scrollBox.ScrollBox;
import oracle.forms.engine.Message;
import oracle.forms.engine.Runform;
import oracle.forms.handler.HelpDialog;

public class IliasHelpDialog extends HelpDialog {

	private static final BorderPainter BORDER_PAINTER = new IliasRectanglePainter();

	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);
		EwtComponent content = getContent();
		for(int i=0; i<content.getComponentCount(); i++) {
			Component comp = content.getComponent(i);
			if (comp instanceof ScrollBox) {
				ScrollBox scrollBox = (ScrollBox)comp;
				scrollBox.setBorderPainter(BORDER_PAINTER);
			}
		}
	}
}
