package ilias.forms.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.net.URL;

import javax.swing.JTextPane;
import javax.swing.ToolTipManager;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import oracle.ewt.UIManager;
import oracle.forms.properties.ID;
import oracle.forms.ui.FormsToolTip;
import oracle.forms.ui.VBean;

public class VHTMLField extends VBean {

	private static final long serialVersionUID = 5017281730961257947L;

	private static final ID SET_TEXT = ID.registerProperty("SetText");
	private static final ID ADD_RULE = ID.registerProperty("AddRule");

	private JTextPane pane;
	private HTMLEditorKit kit;
	private String text = "";
	  
	public VHTMLField() {
		setLayout(new BorderLayout());
		pane = new JTextPane();
		pane.setBorder(null);
		kit = new HTMLEditorKit();
		pane.setEditorKit(kit);
		addRule("body { color:black; background-color:white; }");
		setFont(UIManager.getFont("Label.font"));
		pane.setEditable(false);
		pane.setForeground(Color.BLACK);
		pane.setBackground(Color.WHITE);
		add(BorderLayout.CENTER, pane);
	}

	@Override
	public void setFont(Font font) {
		super.setFont(font);
		if (font != null && pane != null) {
			addRule("body { font-family: "
					+ getFont().getFamily() + "; " + "font-size: "
					+ getFont().getSize() + "pt; }");
		}
	}

	@Override
	public boolean setProperty(ID id, Object value) {
		if (id == SET_TEXT) {
			setText((String)value);
			return true;
		} else if (id == ADD_RULE) {
			addRule(value.toString());
			return true;
		}
		switch(id.toID()) {
		case ID.INDEX_POPUPHELP_ID:
			FormsToolTip tp = (FormsToolTip) value;
			String s = (String) tp.getToolTipProperty(ID.INDEX_POPUPHELP_STRING);
			if (pane != null) {
				pane.setToolTipText(s.replace((char) 10, '\n'));
				ToolTipManager.sharedInstance().setDismissDelay(5000);
			}
			return super.setProperty(id, value);
		case ID.INDEX_VALUE:
			setText((String)value);
			return true;
		default:
			return super.setProperty(id, value);
		}
	}
	
	private void addRule(String rule) {
		HTMLDocument doc = (HTMLDocument) pane.getDocument();
		StyleSheet styleSheet = doc.getStyleSheet();
		styleSheet.addRule(rule);
	}

	private void setText(String value) {
		text = value;
		if (pane != null) {
			Document doc = pane.getDocument();
			doc.putProperty(Document.StreamDescriptionProperty, null);
			try {
				if (text.startsWith("http:") || text.startsWith("ftp:")
						|| text.startsWith("www.")
						|| text.startsWith("file:")) {
					URL url = null;
					/*
					 * if (text.startsWith("/forms")) { // getting the Forms
					 * Main class try { Method method =
					 * m_handler.getClass().getMethod( "getApplet", new
					 * Class[0]); Object applet = method.invoke(m_handler,
					 * new Object[0]); if (applet instanceof Main) {
					 * formsMain = (Main) applet; String sDocBase =
					 * formsMain .getDocumentBase().toString(); int i =
					 * sDocBase.indexOf("/forms/"); sDocBase =
					 * sDocBase.substring(0, i); initialURL = sDocBase + s;
					 * } } catch (Exception ex) { System.err
					 * .println(" !!! HTMLContent() Unable reach the link\n\t"
					 * + ex.toString()); } }
					 */
					url = new URL(text);
					try {
						pane.setText(null);
						pane.setPage(url);
					} catch (IOException ex) {
						System.out.println("Unable to follow the link to "
								+ text + ": " + ex);
					}
				} else {
					pane.setContentType("text/html");
					pane.setText(text);
				}
			} catch (Exception ex) {
				System.out.println("Unable to read the HTML content "
						+ text + ": " + ex);
			}
		}
	}
}