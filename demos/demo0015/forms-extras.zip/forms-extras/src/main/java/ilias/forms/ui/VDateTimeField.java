package ilias.forms.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class VDateTimeField extends VDateField
{
	private static final long serialVersionUID = -4132405827113686957L;

    private static SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy HH:mm");

    public VDateTimeField() {
		super();
		this.withTime = true;
	}
	
	public String formatDate(DateCalendar date) {
		//return date.toString() + " 00:00";
		return fmt.format(date.getTime());
	}

    public DateCalendar parse(String s) throws ParseException {
    	DateCalendar result = new DateCalendar();
    	result.setTime(fmt.parse(s));
    	return result;
    }
}
