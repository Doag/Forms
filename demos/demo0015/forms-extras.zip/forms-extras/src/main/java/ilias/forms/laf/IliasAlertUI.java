package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericAlertUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.util.ImmInsets;

public class IliasAlertUI extends GenericAlertUI {

	private static final ImmInsets _MESSAGE_INSETS = new ImmInsets(12, 12, 4, 12);

	public IliasAlertUI(LWComponent component) {
		super(component);
	}

	public ImmInsets getMessageInsets(LWComponent paramLWComponent) {
		return _MESSAGE_INSETS;
	}
}
