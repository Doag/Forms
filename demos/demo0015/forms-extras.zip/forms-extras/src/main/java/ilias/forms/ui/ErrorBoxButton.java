package ilias.forms.ui;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.io.InputStream;

import oracle.ewt.button.PushButton;
import oracle.ewt.painter.BorderPainter;

public class ErrorBoxButton extends PushButton {

	private static final long serialVersionUID = -3614874127852807401L;

	public ErrorBoxButton(int type) {
		switch(type) {
		case ErrorBox.ERROR:
			setImage(getImage("help_error.gif"));
			break;
		case ErrorBox.WARNING:
			setImage(getImage("help_warning.gif"));
			break;
		case ErrorBox.INFO:
			setImage(getImage("help_info.gif"));
			break;
		}
	}
	
	@Override
	protected void processActionEvent(ActionEvent paramActionEvent) {
		//super.processActionEvent(paramActionEvent);
		onClick();
	}

	protected void onClick() {
	}

	public BorderPainter getBorderPainter() {
		return null;
	}

	public static Image getImage(String name) {
		InputStream in = ErrorBoxButton.class.getResourceAsStream(name);
		try {
			int n = in.available();
			byte[] bytes = new byte[n];
			int o = 0;
			while ((o += in.read(bytes, o, n - o)) < n)
				;
			in.close();
			return Toolkit.getDefaultToolkit().createImage(bytes);
		} catch (Exception e) {
			return null;
		}
	}
}
