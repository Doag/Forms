package ilias.forms.error;

import java.awt.Color;
import java.awt.Dimension;

import oracle.ewt.lwAWT.LWLabel;
import oracle.ewt.popup.AbstractToolTip;
import oracle.ewt.popup.ToolTip;

public class LabelErrorTip extends AbstractToolTip {

	private static final long serialVersionUID = -505426843189234890L;

	private static ToolTip _sToolTip;
	private LWLabel _label = new LWLabel() {

		private static final long serialVersionUID = 4592106376389579330L;

		public Dimension getMinimumSize() {
			return new Dimension(0, 0);
		}
	};

	public static ToolTip getToolTip() {
		if (_sToolTip == null) {
			LabelErrorTip comp = new LabelErrorTip();
			comp.setBackground(Color.RED);
			comp._label.setForeground(Color.WHITE);
			_sToolTip = comp;

		}
		return _sToolTip;
	}

	public void setToolTipValue(Object paramObject) {
		this._label.setText(paramObject.toString());
	}

	protected LabelErrorTip() {
		setContent(this._label);
	}

	public Object getUIClassID() {
		return "ErrorTipUI";
	}
}