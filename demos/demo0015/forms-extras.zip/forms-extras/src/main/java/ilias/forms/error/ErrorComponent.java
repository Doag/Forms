package ilias.forms.error;

public interface ErrorComponent {
	public String getErrorString();
}
