package ilias.forms.handler;

import oracle.forms.handler.BlockScroller;

public class IliasBlockScroller extends BlockScroller {

}
