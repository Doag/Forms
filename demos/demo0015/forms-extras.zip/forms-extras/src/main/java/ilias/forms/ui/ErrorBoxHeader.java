package ilias.forms.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import oracle.ewt.button.PushButton;
import oracle.ewt.lwAWT.LWContainer;
import oracle.ewt.lwAWT.LWLabel;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;

public class ErrorBoxHeader extends LWContainer {

	private static final long serialVersionUID = -6540367162838094643L;

	private static final ErrorTextBorderPainter borderPainter = new ErrorTextBorderPainter();
	
	private LWLabel label;
	private PushButton button;
	private String text;
	private int count = 1;

	public ErrorBoxHeader(String text, int type) {
		super(new BorderLayout());
		this.text = text;
		label = new ErrorBoxLabel(text) {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onClick() {
				ErrorBoxHeader.this.onClick();
			}
		};
		button = new ErrorBoxButton(type) {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onClick() {
				ErrorBoxHeader.this.onButtonClick();
			}
		};
		add(label, BorderLayout.CENTER);
		add(button, BorderLayout.EAST);
	}

	public void increment() {
		count++;
		label.setText(text + " (" + Integer.toString(count) + ')');
	}

	@Override
	protected void processMouseEvent(MouseEvent event) {
		if (event.getID() == MouseEvent.MOUSE_CLICKED) {
			onClick();
		}
		super.processMouseEvent(event);
	}

	protected void onClick() {
	}

	protected void onButtonClick() {
	}

	@Override
	public BorderPainter getBorderPainter() {
		return borderPainter;
	}

	public int getTextHeight() {
		int extra = getHeight() - getInnerSize().height;
		FontMetrics fm = label.getFontMetrics(label.getFont());
		String text = label.getText();
		if (text != null) {
			return fm.getHeight() + extra;
		}
		return extra;
	}

	public static class ErrorTextBorderPainter extends AbstractBorderPainter {

		private static final ImmInsets _INSETS0 = new ImmInsets(4, 4, 4, 4);

		protected ImmInsets getOwnInsets(PaintContext ctx) {
			return _INSETS0;
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			g.setColor(ctx.getPaintBackground());
			g.drawRect(x, y, w - 1, h - 1);
			g.drawRect(x+1, y+1, w - 3, h - 3);
			g.drawRect(x+2, y+2, w - 5, h - 5);
			g.drawRect(x+3, y+3, w - 7, h - 7);
			g.setColor(oldColor);
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | 0x80;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return true;
		}
	}
}
