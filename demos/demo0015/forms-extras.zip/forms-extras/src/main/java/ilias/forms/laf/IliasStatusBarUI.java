package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericStatusBarUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasStatusBarUI extends GenericStatusBarUI {
	public IliasStatusBarUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}