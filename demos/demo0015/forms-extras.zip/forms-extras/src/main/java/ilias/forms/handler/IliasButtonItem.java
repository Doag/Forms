package ilias.forms.handler;

import oracle.forms.handler.ButtonItem;
import oracle.forms.properties.ID;

public class IliasButtonItem extends ButtonItem {

	@Override
	public synchronized boolean onUpdate(int id, Object value) {
		switch (id) {
		case ID.INDEX_BACKGROUND:
			// Ignore background setting
			return true;
        case ID.INDEX_VISIBLE:
            boolean result = super.onUpdate(id, value);
            getComponent().firePropertyChange("serverVisible", 'N', 'Y');
            return result;
		default:
			return super.onUpdate(id, value);
		}
	}
}
