package ilias.forms.laf;

import oracle.ewt.lwAWT.LWComponent;

public class IliasTextFieldUI extends IliasTextUI {

	public IliasTextFieldUI(LWComponent component) {
		super(component);
	}
}
