package ilias.forms.handler;

import oracle.forms.handler.TextFieldItem;
import oracle.forms.properties.ID;

public class IliasTextFieldItem extends TextFieldItem {

	@Override
	public synchronized boolean onUpdate(int id, Object value) {
		switch (id) {
		case ID.INDEX_HAS_LOV:
			if (((Boolean) value).booleanValue()) {
				getView().setProperty(ID.HAS_LOV, (Boolean) value);
			}
			return super.onUpdate(id, value);
        case ID.INDEX_VISIBLE:
            boolean result = super.onUpdate(id, value);
            getComponent().firePropertyChange("serverVisible", 'N', 'Y');
            return result;
		default:
			return super.onUpdate(id, value);
		}
	}
}
