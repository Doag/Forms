package ilias.forms.laf;

import java.awt.Color;
import java.awt.Graphics;

import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.util.ImmInsets;

public class IliasFocusRectanglePainter extends AbstractBorderPainter {

	private static final ImmInsets _INSETS1 = new ImmInsets(1, 1, 1, 1);
	private static final ImmInsets _INSETS2 = new ImmInsets(2, 2, 2, 2);

	public IliasFocusRectanglePainter() {
		super();
	}

	public IliasFocusRectanglePainter(Painter wrapped) {
		super(wrapped);
	}

	protected ImmInsets getOwnInsets(PaintContext ctx) {
		boolean hasFocus = (ctx.getPaintState() & PaintContext.STATE_FOCUSED) != 0;
		if (hasFocus) {
			return _INSETS2;
		} else {
			return _INSETS1;
		}
	}

	protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		Color oldColor = g.getColor();
		boolean hasFocus = (ctx.getPaintState() & PaintContext.STATE_FOCUSED) != 0;
		if (hasFocus) {
			g.setColor(IliasLookAndFeel.FOCUS_COLOR);
			g.drawRect(x, y, w - 1, h - 1);
			g.setColor(IliasLookAndFeel.BORDER_COLOR);
			g.drawRect(x + 1, y + 1, w - 3, h - 3);
		} else {
			g.setColor(IliasLookAndFeel.BORDER_COLOR);
			g.drawRect(x, y, w - 1, h - 1);
		}
		g.setColor(oldColor);
	}

	public int getRepaintFlags(PaintContext ctx) {
		return Painter.STATE_FOCUSED_CHANGED | Painter.STATE_SELECTED_CHANGED;
	}

	protected boolean isBorderTransparent(PaintContext ctx) {
		return false;
	}
}
