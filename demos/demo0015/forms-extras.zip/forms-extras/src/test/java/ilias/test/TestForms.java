package ilias.test;

import ilias.forms.laf.IliasLookAndFeel;
import ilias.oracle.forms.engine.FormsMain;

import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.applet.AudioClip;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLConnection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import oracle.ewt.UIManager;
import oracle.ewt.util.FocusUtils;

public class TestForms extends JFrame implements AppletStub, WindowListener {

	private static final long serialVersionUID = 7224539147742036746L;

	private FormsMain main;
	private TestAppletContext appletContext;
	
	private static final AppletParameters parameters = new AppletParameters();
	
	static {
		parameters.put("serverApp", "default");
		parameters.put("lookAndFeel", "generic");
		parameters.put("imageBase", "codebase");
		parameters.put("splashScreen", "no");
		parameters.put("background", "background.gif");
		parameters.put("logo", "empty.gif");
		parameters.put("networkRetries", "16");
		parameters.put("networkStats", "false");
		parameters.put("enableJavascriptEvent", "true");
		parameters.put("JavaScriptBlocksHeartBeat", "true");
		parameters.put("nlsLang", "true");
		//parameters.put("clientDPI", "72");	// Default = 96	(72 is 75% of 96)
		//parameters.put("formsMessageListener","ilias.test.TestFormsMessageListener");
	}
	
	static class AppletParameters {

		private Map<String,String> map = new HashMap<String, String>();

		public String get(String key) {
			return map.get(key.toUpperCase());
		}

		public String put(String key, String value) {
			return map.put(key.toUpperCase(), value);
		}
	}

	static class TestAppletContext implements AppletContext {

		public AudioClip getAudioClip(URL url) {
			return null;
		}

		public Image getImage(URL url) {
			try {
				return ImageIO.read(url);
			} catch(IOException e) {
				return null;
			}
		}

		public Applet getApplet(String name) {
			return null;
		}

		public Enumeration<Applet> getApplets() {
			return null;
		}

		public void showDocument(URL url) {
		}

		public void showDocument(URL url, String target) {
		}

		public void showStatus(String status) {
		}

		public void setStream(String key, InputStream stream)
				throws IOException {
		}

		public InputStream getStream(String key) {
			return null;
		}

		public Iterator<String> getStreamKeys() {
			return null;
		}
	}

	private static String getParam(String content, String key) {
		int index = content.indexOf(key);
		if (index >= 0) {
			int start = content.indexOf("\"", index);
			int end = content.indexOf("\"", start + 1);
			String value = content.substring(start + 1, end);
			System.out.println(key + '=' + value);
			return value;
		}
		return null;
	}

	public static void main(String[] args) throws Exception {

//		System.setProperty("awt.useSystemAAFontSettings", "on");
//		System.setProperty("swing.aatext", "true");

		String documentbase = "http://localhost:7777/forms/frmservlet?form=modernize&userid=summit/summit@orcl2";
		parameters.put("documentbase", documentbase);

		URL url = new URL(documentbase);
		URLConnection con = url.openConnection();
		Reader r = new InputStreamReader(con.getInputStream());
		BufferedReader br = new BufferedReader(r);

		String line;
		StringBuilder sb = new StringBuilder();
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}
		br.close();
		
		String content = sb.toString();

		String serverURL = getParam(content, "serverURL");
		serverURL = serverURL.replace("acceptLanguage=null", "acceptLanguage=en-US");
		serverURL = serverURL.replace("&#38;", "&");
		parameters.put("serverURL", serverURL);
		System.out.println("serverURL=" + serverURL);

		String codebase = "http://localhost:7777/forms/java";
		parameters.put("codebase", codebase);

		UIManager.setLookAndFeel(new IliasLookAndFeel());

		TestForms test = new TestForms();
		test.addWindowListener(test);
		test.setSize(1280, 1024);
		test.setVisible(true);
		test.run();
	}
	
	public TestForms() {
		if (FocusUtils.areNewFocusAPIsAvailable()) {
			try {
				Class<?> argTypes[] = { java.awt.Window.class, Boolean.TYPE };
				Method m = (sun.awt.SunToolkit.class).getMethod(
						"setLWRequestStatus", argTypes);
				Object args[] = { this, new Boolean(true) };
				m.invoke(null, args);
			} catch (Exception e) {
				e.printStackTrace(System.out);
			}
		}
		
		FocusUtils.setDefaultFocusTraversalPolicy(this);
		
		appletContext = new TestAppletContext();

		main = new FormsMain();
		main.setStub(this);

		setLayout(new BorderLayout());
		add(BorderLayout.CENTER, main);
	}
	
	public void run() {
		main.init();
		main.start();
		
		validate();
	}

	////////////////////
	// AppletStub
	
	public URL getDocumentBase() {
		try {
			String documentbase = parameters.get("documentbase");
			return new URL(documentbase);
		} catch(Exception e) {
			return null;
		}
	}

	public URL getCodeBase() {
		try {
			String codebase = parameters.get("codebase");
			return new URL(codebase);
		} catch(Exception e) {
			return null;
		}
	}

	public String getParameter(String name) {
		String value = parameters.get(name);
		//System.out.println(name + '=' + value);
		return value;
	}

	public AppletContext getAppletContext() {
		return appletContext;
	}

	public void appletResize(int width, int height) {
	}

	////////////////////
	// WindowListener
	public void windowOpened(WindowEvent windowevent) {
	}

	public void windowClosing(WindowEvent windowevent) {
		main.stop();
		main.destroy();
		dispose();
	}

	public void windowClosed(WindowEvent windowevent) {
		System.exit(0);
	}

	public void windowIconified(WindowEvent windowevent) {
	}

	public void windowDeiconified(WindowEvent windowevent) {
	}

	public void windowActivated(WindowEvent windowevent) {
	}

	public void windowDeactivated(WindowEvent windowevent) {
	}
}
