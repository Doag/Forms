package ilias.forms.ui;

import java.awt.Image;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import oracle.forms.engine.KeyBinder;
import oracle.forms.engine.Runform;
import oracle.forms.handler.IHandler;
import oracle.forms.handler.UICommon;
import oracle.forms.properties.FormAction;

public class VDateField extends AdvancedTextFieldItem {

	private static final long serialVersionUID = 1036391433040518749L;

    private static SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");

	protected Runform runform;
	private DateDialog dataDialog;

	private static Image CALENDAR_WHITE = TextComponentButton.getImage("calendar_white.gif");
	private static Image CALENDAR_YELLOW = TextComponentButton.getImage("calendar_yellow.gif");

	protected boolean withTime = false;
	
	public VDateField() {
		super(CALENDAR_WHITE, CALENDAR_YELLOW);
		getButton().setVisible(true);
	}

	@Override
	public void init(IHandler ihandler) {
		if (ihandler != null) {
			super.init(ihandler);
			if (ihandler instanceof UICommon) {
				UICommon uiCommon = (UICommon) ihandler;
				runform = uiCommon.getDispatcher();
				setLocale(runform.getLocale());
			}
		}
	}

	@Override
	protected void showButton(boolean editable) {
		getButton().setVisible(editable);
	}

    @Override
	public void processKeyEvent(KeyEvent e) {
    	// click on calendar button simulates LIST OF VALUES
		if (isEnabled() && isEditable() && !e.isConsumed()
				&& e.getID() == KeyEvent.KEY_PRESSED) {
			FormAction fa = KeyBinder.getFormAction(e);
			if (fa == FormAction.FA_LIST_OF_VALUES) {
				openDialog();
				e.consume();
				return;
			}
		}
		super.processKeyEvent(e);
	}

	private void openDialog() {
		DateCalendar date;
		try {
			date = parse(getText());
		} catch (Exception e) {
			date = new DateCalendar();
		}

		dataDialog = new DateDialog(date, withTime) {
			private static final long serialVersionUID = -266527087807068888L;

			public void onOK() {
				DateCalendar date = getDate();
				if (date != null && isEditable()) {
					String s = formatDate(date);
					if (!s.equalsIgnoreCase(getText())) {
						setText(s);
					}
				}
			}
		};
		dataDialog.showDialog(runform);
	}

	public String formatDate(DateCalendar date) {
		return date.toString();
	}

    public DateCalendar parse(String s) throws ParseException {
    	DateCalendar result = new DateCalendar();
    	result.setTime(fmt.parse(s));
    	return result;
    }
}