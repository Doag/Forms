package ilias.forms.laf;

import java.awt.Color;
import java.awt.Graphics;

import oracle.ewt.laf.generic.GenericChoiceUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.util.ImmInsets;

public class IliasChoiceUI extends GenericChoiceUI {

	private static final BorderPainter LIST_BUTTON_PAINTER = new ChoiceButtonPainter();
	private static final BorderPainter LIST_BORDER_PAINTER = new IliasRectanglePainter();
	
	public IliasChoiceUI(LWComponent component) {
		super(component);
	}

	@Override
	protected BorderPainter getListBorderPainter(LWComponent component) {
		return LIST_BORDER_PAINTER;
	}

	@Override
	public BorderPainter getButtonBorderPainter(LWComponent component) {
		return LIST_BUTTON_PAINTER;
	}

	public static class ChoiceButtonPainter extends AbstractBorderPainter {
		private static final ImmInsets _INSETS = new ImmInsets(0, 4, 0, 2);
		private static final ImmInsets _FILL_INSETS = new ImmInsets(0, 1, 0, 0);
		private static final ImmInsets _ARMED_FILL_INSETS = new ImmInsets(1, 2, 1, 1);

		public ChoiceButtonPainter() {
		}

		public ChoiceButtonPainter(Painter wrapped) {
			super(wrapped);
		}

		protected ImmInsets getOwnInsets(PaintContext ctx) {
			return _INSETS;
		}

		protected ImmInsets getOwnFillInsets(PaintContext ctx) {
			int state = ctx.getPaintState();
			if ((state & PaintContext.STATE_ARMED) != 0) {
				return _ARMED_FILL_INSETS;
			} else {
				return _FILL_INSETS;
			}
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			g.setColor(IliasLookAndFeel.BORDER_COLOR);
			g.drawLine(x, y, x, y + h - 1);
			g.setColor(oldColor);
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return false;
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | PaintContext.STATE_DISABLED | PaintContext.STATE_ARMED | 
				PaintContext.STATE_INACTIVE | PaintContext.STATE_FOCUSED | PaintContext.STATE_ISDEFAULT | 0x400;
		}
	}
}