package ilias.forms.laf;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.painter.AbstractPainter;
import oracle.ewt.painter.PaintContext;

public class IliasScrollArrowPainter extends AbstractPainter {
	public static final int UP_ARROW = 0;
	public static final int DOWN_ARROW = 1;
	public static final int LEFT_ARROW = 2;
	public static final int RIGHT_ARROW = 3;

	private static final int _MINIMUM_WIDTH = 15;
	private static final int _MINIMUM_HEIGHT = 15;

	private static int minimumWidth = _MINIMUM_WIDTH;
	private static int minimumHeight = _MINIMUM_HEIGHT;

	private int _arrow;

	private static final IliasScrollArrowPainter[] _PAINTERS = { //
			new IliasScrollArrowPainter(UP_ARROW), //
			new IliasScrollArrowPainter(DOWN_ARROW), //
			new IliasScrollArrowPainter(LEFT_ARROW), //
			new IliasScrollArrowPainter(RIGHT_ARROW) };

	private IliasScrollArrowPainter(int arrow) {
		this._arrow = arrow;
	}

	public static IliasScrollArrowPainter getPainter(int paramInt) {
		return _PAINTERS[paramInt];
	}

	public static void rescale(int scale) {
		minimumWidth = 15 * scale / 100;
		minimumHeight = 15 * scale / 100;
	}

	public void paint(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		Color oldColor = g.getColor();
		
		UIDefaults uiDefaults = ctx.getPaintUIDefaults();
		g.setColor(uiDefaults.getColor(LookAndFeel.CONTROL));
		g.fillRect(x, y, w, h);

		int state = ctx.getPaintState();
		int armed = ((state & PaintContext.STATE_ARMED) != 0) ? 1 : 0;
		boolean disabled = ((state & PaintContext.STATE_DISABLED) != 0);
		Color color = uiDefaults.getColor(LookAndFeel.CONTROL_SHADOW);

		boolean horizontal = (this._arrow >= LEFT_ARROW);
		int arrowSize = horizontal ? h : w;
		if ((arrowSize -= 8) > 8)
			arrowSize = 8;
		x += (w - arrowSize) / 2;
		y += (h - arrowSize) / 2;
		if (armed != 0) {
			++x;
			++y;
		}
		
		g.setColor(disabled ? color : Color.black);
		
		int i4 = arrowSize - 4;
		int i5 = i4 * 2 - 1;
		if (horizontal) {
			int yy1 = y + 1;
			int yy2 = y + i5;
			if (this._arrow == LEFT_ARROW)
				for (int xx = x + 1 + i4; xx > x + 1; --xx) {
					g.drawLine(xx, yy1, xx, yy2);
					++yy1;
					--yy2;
				}
			else
				for (int xx = x + 2; xx < x + 2 + i4; ++xx) {
					g.drawLine(xx, yy1, xx, yy2);
					++yy1;
					--yy2;
				}
		} else {
			int xx1 = x + 1;
			int xx2 = x + i5;
			if (this._arrow == UP_ARROW)
				for (int yy = y + 1 + i4; yy > y + 1; --yy) {
					g.drawLine(xx1, yy, xx2, yy);
					++xx1;
					--xx2;
				}
			else
				for (int yy = y + 2; yy < y + 2 + i4; ++yy) {
					g.drawLine(xx1, yy, xx2, yy);
					++xx1;
					--xx2;
				}
		}
		
		int i6;
		int i7;
		if (disabled) {
			g.setColor(Color.white);
			switch (this._arrow) {
			case 0:
				i6 = y + 2 + i4;
				g.drawLine(x + 1, i6, x + i5, i6);
				break;
			case 1:
				i6 = x + i4;
				i7 = y + i4 + 1;
				g.drawLine(i6, i7, i6 + i4 - 2, i7 - i4 + 2);
				g.drawLine(i6, i7 + 1, i6 + i4 - 1, i7 - i4 + 2);
				break;
			case 2:
				i6 = x + 2 + i4;
				g.drawLine(i6, y + 1, i6, y + i5);
				break;
			case 3:
				i6 = x + 3;
				i7 = y + i5 - 1;
				g.drawLine(i6, i7, i6 + i4 - 2, i7 - i4 + 2);
				g.drawLine(i6, i7 + 1, i6 + i4 - 1, i7 - i4 + 2);
			}
		}
		g.setColor(oldColor);
	}

	public Dimension getMinimumSize(PaintContext ctx) {
		return new Dimension(minimumWidth, minimumHeight);
	}

	public Dimension getMaximumSize(PaintContext ctx) {
		if (this._arrow >= LEFT_ARROW)
			return new Dimension(minimumWidth, 32767);
		return new Dimension(32767, minimumHeight);
	}

	public int getRepaintFlags(PaintContext ctx) {
		return PaintContext.STATE_DISABLED + PaintContext.STATE_ARMED;
	}
}
