package ilias;

import ilias.forms.ui.ErrorStack;
import ilias.forms.ui.ErrorStack.ButtonClickListener;
import ilias.forms.ui.ErrorStack.ClickListener;
import ilias.oracle.forms.engine.FormsMain;

import java.awt.event.ActionEvent;

import oracle.forms.engine.Main;
import oracle.forms.handler.IHandler;
import oracle.forms.properties.ID;
import oracle.forms.ui.CustomEvent;
import oracle.forms.ui.VBean;

public class ErrorStackPJC extends VBean implements ClickListener, ButtonClickListener {

	private static final long serialVersionUID = 1316658476127220666L;

	private static final ID SHOW_INFO = ID.registerProperty("ShowInfo");
	private static final ID SHOW_WARNING = ID.registerProperty("ShowWarning");
	private static final ID SHOW_ERROR = ID.registerProperty("ShowError");
	private static final ID SET_BOX_WIDTH = ID.registerProperty("SetBoxWidth");
	private static final ID SET_TIMER_DELAY = ID.registerProperty("SetTimerDelay");
    private static final ID CLICKED = ID.registerProperty("Clicked");
    private static final ID BUTTON_CLICKED = ID.registerProperty("ButtonClicked");
    private static final ID ERROR_ID = ID.registerProperty("ErrorId");
    private static final ID RESET_ID = ID.registerProperty("Reset");

	private ErrorStack errorStack = null;

	public ErrorStackPJC() {
		super();
	}

	/**
	 * The initialization method called by the Webform applet immediately after
	 * the object is constructed.  A handler reference is passed to the object
	 */
	public void init(IHandler handler) {
		super.init(handler);
		Main main = handler.getApplet();
		if (main instanceof FormsMain) {
			errorStack = ((FormsMain)main).getErrorStack();
			errorStack.addClickListener(this);
			errorStack.addButtonListener(this);
		}
	}

	/**
	 * The Webforms applet calls this method to elimate the object.  The object
	 * can release any resources it is using prior to it's destruction
	 */
	public void destroy() {
		if (errorStack != null) {
			errorStack.removeButtonListener(this);
			errorStack.removeClickListener(this);
			errorStack = null;
		}
	}

	public void onClick(ActionEvent e) {
		if (getHandler() != null) {
			try {
				CustomEvent ce = new CustomEvent(getHandler(), CLICKED);
				ce.setProperty(ERROR_ID, e.getActionCommand());
				dispatchCustomEvent(ce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	public void onButtonClick(ActionEvent e) {
		if (getHandler() != null) {
			try {
				CustomEvent ce = new CustomEvent(getHandler(), BUTTON_CLICKED);
				ce.setProperty(ERROR_ID, e.getActionCommand());
				dispatchCustomEvent(ce);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * this method sets the value of the desired property to the value represented
	 * by the Object value. The properties are identified from the results of the
	 * registration process performed at an earlier stage
	 */
	public boolean setProperty(ID pid, Object value) {
		if (errorStack != null) {
			if (pid == SHOW_INFO) {
				errorStack.addInfo(value.toString());
				return true;
			} else if (pid == SHOW_WARNING) {
				errorStack.addWarning(value.toString());
				return true;
			} else if (pid == SHOW_ERROR) {
				errorStack.addError(value.toString());
				return true;
			} else if (pid == SET_BOX_WIDTH) {
				errorStack.setBoxWidth(((Integer)value).intValue());
				return true;
			} else if (pid == SET_TIMER_DELAY) {
				errorStack.setTimerDelay(((Integer)value).intValue());
				return true;
			} else if (pid == RESET_ID) {
				errorStack.cleanup();
				return true;
			}
		}
		return super.setProperty(pid, value);
	}

	/**
	 ** This method returns the value of requested property.
	 */
	public Object getProperty(ID pid) {
		return super.getProperty(pid);
	}
}