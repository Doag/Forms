package ilias.forms.laf;

import java.awt.BorderLayout;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import oracle.ewt.laf.basic.BasicComponentUI;
import oracle.ewt.layout.MaximumBorderLayout;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.lwAWT.lwMenu.LWMenuBar;
import oracle.ewt.lwAWT.lwWindow.LWWindow;
import oracle.ewt.lwAWT.lwWindow.WindowType;
import oracle.ewt.lwAWT.lwWindow.laf.MouseWindowResizer;
import oracle.ewt.lwAWT.lwWindow.laf.TitleBar;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.NullPainter;
import oracle.ewt.plaf.WindowUI;

public class IliasWindowUI extends BasicComponentUI implements WindowUI,
		PropertyChangeListener {

	private LWComponent _contentPane;
	private TitleBar _titleBar;
	private BorderPainter _border;
	private MouseWindowResizer _resizer;

	public IliasWindowUI(LWComponent component) {
		super(component);
	}

	public BorderPainter getDefaultBorderPainter(LWComponent component) {
		LWWindow window = (LWWindow) component;
		if (window.getType() == WindowType.DIALOG || !window.isMaximized()) {
			if (_border == null) {
				_border = new IliasWindowBorder(window);
			}
			return _border;
		} else {
			return NullPainter.getPainter();
		}
	}

	@SuppressWarnings("deprecation")
	public void installUI(LWComponent component) {
		LWWindow window = (LWWindow) component;
		_contentPane = new LWComponent();
		_contentPane.setLayout(new MaximumBorderLayout());
		Component content = window.getContent();
		if (content != null) {
			_contentPane.add(BorderLayout.CENTER, content);
		}
		LWMenuBar menuBar = window.getMenuBar();
		if (menuBar != null) {
			_contentPane.add(BorderLayout.NORTH, menuBar);
		}
		window.setLayout(new MaximumBorderLayout());
		if (window.getType() == WindowType.DIALOG || !window.isMaximized()) {
			_titleBar = new TitleBar(window);
		    window.add(BorderLayout.NORTH, _titleBar);
		}
		window.add(BorderLayout.CENTER, _contentPane);
		_resizer = new MouseWindowResizer(window);
		window.addMouseListener(_resizer);
		window.addMouseMotionListener(_resizer);
		window.addPropertyChangeListener(this);
	}

	public void uninstallUI(LWComponent component) {
		LWWindow window = (LWWindow) component;
		Component content = window.getContent();
		if (content != null) {
			_contentPane.remove(content);
		}
		LWMenuBar menuBar = window.getMenuBar();
		if (menuBar != null) {
			_contentPane.remove(menuBar);
		}
		window.remove(_contentPane);
		if (_titleBar != null) {
		    window.remove(_titleBar);
		}
		window.setLayout(null);
		window.removeMouseListener(_resizer);
		window.removeMouseMotionListener(_resizer);
		window.removePropertyChangeListener(this);
		_contentPane = null;
		_titleBar = null;
		_resizer = null;
		_border = null;
	}

	public void propertyChange(PropertyChangeEvent event) {
		String propertyName = event.getPropertyName();
		LWWindow window = (LWWindow) event.getSource();
		if (propertyName.equals("content")) {
			Component oldContent = (Component) event.getOldValue();
			Component newContent = (Component) event.getNewValue();
			if (oldContent != null)
				_contentPane.remove(oldContent);
			if (newContent != null)
				_contentPane.add(BorderLayout.CENTER, newContent);
			window.validate();
		} else if (propertyName.equals("menubar")) {
			LWMenuBar oldMenuBar = (LWMenuBar) event.getOldValue();
			LWMenuBar newMenuBar = (LWMenuBar) event.getNewValue();
			if (oldMenuBar != null) {
				_contentPane.remove(oldMenuBar);
			}
			if (newMenuBar != null) {
				_contentPane.add(BorderLayout.NORTH, newMenuBar);
			}
			window.validate();
		}
	}
}
