package ilias.forms.laf;

import java.awt.Color;
import java.awt.Graphics;

import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.util.ImmInsets;

public class IliasRectanglePainter extends AbstractBorderPainter {

	private static final ImmInsets _INSETS = new ImmInsets(1, 1, 1, 1);

	private Color _color;
	private ImmInsets _insets = _INSETS;

	public IliasRectanglePainter() {
		this(IliasLookAndFeel.BORDER_COLOR);
	}

	public IliasRectanglePainter(Color color) {
		_color = color;
	}

	public IliasRectanglePainter(Painter painter) {
		super(painter);
	}

	public void setOwnInsets(ImmInsets insets) {
		_insets = insets;
	}

	protected ImmInsets getOwnInsets(PaintContext ctx) {
		return _insets;
	}

	protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		Color oldColor = g.getColor();
		g.setColor(_color);
		for(int i=0; i<_insets.top; i++) {
			g.drawLine(0, i, w - 1, i);
		}
		for(int i=0; i<_insets.bottom; i++) {
			g.drawLine(0, h - 1 - i, w - 1, h - 1 - i);
		}
		for(int i=0; i<_insets.left; i++) {
			g.drawLine(i, 0, i, h - 1);
		}
		for(int i=0; i<_insets.right; i++) {
			g.drawLine(w - 1 - i, 0, w - 1 - i, h - 1);
		}
		//g.drawRect(x, y, w - 1, h - 1);
		g.setColor(oldColor);
	}

	public int getRepaintFlags(PaintContext ctx) {
		return super.getRepaintFlags(ctx) | PaintContext.STATE_DISABLED | PaintContext.STATE_ISDEFAULT;
	}

	protected boolean isBorderTransparent(PaintContext ctx) {
		return false;
	}
}
