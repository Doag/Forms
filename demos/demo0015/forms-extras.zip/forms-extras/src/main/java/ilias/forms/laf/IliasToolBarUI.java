package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericToolBarUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasToolBarUI extends GenericToolBarUI {
	public IliasToolBarUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}