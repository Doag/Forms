package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericToolTipUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasErrorTipUI extends GenericToolTipUI {
	public IliasErrorTipUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}