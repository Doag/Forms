package ilias.forms.handler;

import oracle.forms.handler.ComboBoxItem;

public class IliasComboBoxItem extends ComboBoxItem {
}
