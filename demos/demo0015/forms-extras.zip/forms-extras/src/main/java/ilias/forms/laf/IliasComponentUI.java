package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericComponentUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasComponentUI extends GenericComponentUI {

	public IliasComponentUI(LWComponent component) {
		super(component);
	}
}
