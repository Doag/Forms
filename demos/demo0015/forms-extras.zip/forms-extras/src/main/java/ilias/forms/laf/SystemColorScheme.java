package ilias.forms.laf;

import java.awt.Color;
import java.awt.SystemColor;
import java.awt.image.ImageFilter;
import java.util.Locale;
import oracle.ewt.ColorScheme;
import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.laf.basic.ColorizingFilter;

class SystemColorScheme extends ColorScheme {
	private static final int[] _LUM_VALUES = { //
	255, //
			254, //
			223, //
			193, //
			192, //
			128, //
			127, //
			0 };
	private static final Color[] _LUM_COLORS = { //
	SystemColor.window, //
			SystemColor.controlLtHighlight, //
			SystemColor.controlHighlight, //
			SystemColor.scrollbar, //
			SystemColor.control, //
			SystemColor.controlShadow, //
			SystemColor.textHighlight, //
			SystemColor.controlDkShadow };
	private int[] _mappingTable;

	public String getName() {
		return "IliasSystemColor";
	}

	public String getDisplayName(Locale paramLocale) {
		return getName();
	}

	public String getDescription(Locale paramLocale) {
		return "System Color Scheme for Ilias Look and Feel";
	}

	public final Color getDefiningColor() {
		return SystemColor.control;
	}

	public final ImageFilter createColorizingFilter() {
		return new ColorizingFilter(_getColorMappingTable());
	}

	public final void initializeColors(UIDefaults defaults) {
		Color localColor2 = new Color(16773835);
		Color localColor3 = new Color(16439688);
		int i = 14678255;
		int j = 11726551;
		SystemColor localSystemColor = SystemColor.control;
		int k = localSystemColor.getRed();
		int m = localSystemColor.getGreen();
		int n = localSystemColor.getBlue();
		if ((k != m) || (m != n)) {
			i = (m << 15) + 8388608 | (n << 7) + 32768 | (k >> 1) + 128;
			j = (n << 15) + 8388608 | (k << 7) + 32768 | (m >> 1) + 128;
		}
		Color localColor5 = new Color(8684164);
		Object[] arrayOfObject = { //
				LookAndFeel.DESKTOP, localColor5, //
				LookAndFeel.ACTIVE_CAPTION, IliasLookAndFeel.DARK, //
				LookAndFeel.ACTIVE_CAPTION_TEXT, Color.white, //
				LookAndFeel.ACTIVE_CAPTION_BORDER, SystemColor.activeCaptionBorder, //
				LookAndFeel.INACTIVE_CAPTION, IliasLookAndFeel.LIGHT, //
				LookAndFeel.INACTIVE_CAPTION_TEXT, Color.lightGray, //
				LookAndFeel.INACTIVE_CAPTION_BORDER, SystemColor.inactiveCaptionBorder, //
				LookAndFeel.DIALOG, localSystemColor, //
				LookAndFeel.WINDOW, SystemColor.window, //
				LookAndFeel.WINDOW_BORDER,
				SystemColor.windowBorder, //
				LookAndFeel.WINDOW_TEXT,
				SystemColor.windowText, //
				LookAndFeel.MENU,
				SystemColor.menu, //
				LookAndFeel.MENU_TEXT,
				SystemColor.menuText, //
				LookAndFeel.TEXT_TEXT, SystemColor.textText, //
				LookAndFeel.TEXT_HIGHLIGHT,	IliasLookAndFeel.BLUE, //
				LookAndFeel.TEXT_HIGHLIGHT_TEXT, SystemColor.textText, //
				LookAndFeel.TEXT_INACTIVE_TEXT,
				SystemColor.textInactiveText, //
				LookAndFeel.CONTROL,
				localSystemColor, //
				LookAndFeel.CONTROL_TEXT,
				SystemColor.controlText, //
				LookAndFeel.CONTROL_HIGHLIGHT, SystemColor.controlHighlight, //
				LookAndFeel.CONTROL_LT_HIGHLIGHT,	SystemColor.controlLtHighlight, //
				LookAndFeel.CONTROL_SHADOW, SystemColor.controlShadow, //
				// Plain bevel uses the following system color...
				LookAndFeel.CONTROL_DK_SHADOW, IliasLookAndFeel.BORDER_COLOR, //
				LookAndFeel.SCROLLBAR, SystemColor.scrollbar, //
				LookAndFeel.INFO,
				SystemColor.info, LookAndFeel.INFO_TEXT, SystemColor.infoText,
				LookAndFeel.TEXT, SystemColor.text,
				LookAndFeel.SECONDARY_TEXT_HIGHLIGHT,
				SystemColor.textHighlight, LookAndFeel.LIGHT_INTENSITY,
				SystemColor.controlHighlight, LookAndFeel.NORMAL_INTENSITY,
				localSystemColor, LookAndFeel.DARK_INTENSITY,
				SystemColor.controlShadow, LookAndFeel.VERY_DARK_INTENSITY,
				SystemColor.controlDkShadow, LookAndFeel.LIGHT_LOOK,
				localSystemColor, LookAndFeel.DARK_LOOK, localSystemColor,
				LookAndFeel.VERY_DARK_LOOK, localSystemColor,
				LookAndFeel.CONTROL_INACTIVE_TEXT, SystemColor.textInactiveText, //
				LookAndFeel.CONTROL_INACTIVE, localSystemColor, // 
				LookAndFeel.TOOL_TIP, SystemColor.info, //
				LookAndFeel.SELECTED_FOCUS, IliasLookAndFeel.BLUE,
				LookAndFeel.PINSTRIPE1, localColor2, //
				LookAndFeel.PINSTRIPE2, localColor3, // 
				LookAndFeel.PINSTRIPE3, new Color(i), //
				LookAndFeel.PINSTRIPE4, new Color(j) };
		defaults.putDefaults(arrayOfObject);

		String os = System.getProperty("os.name");
		if (os.startsWith("Windows")) {
			defaults.put(LookAndFeel.TEXT, SystemColor.window);
		}
	}

	private final int[] _getColorMappingTable() {
		if (this._mappingTable == null) {
			int[] arrayOfInt = new int[256];
			int i = 0;
			int j = _LUM_VALUES[0];
			for (int k = 255; k >= 0; k--)
				if (k == j) {
					int m = _LUM_COLORS[i].getRGB() | 0xFF000000;
					arrayOfInt[k] = m;
					i++;
					if (i < _LUM_VALUES.length)
						j = _LUM_VALUES[i];
					else
						j = -1;
				} else {
					arrayOfInt[k] = (0xFF000000 | (k << 16 | k << 8 | k));
				}
			this._mappingTable = arrayOfInt;
		}
		return this._mappingTable;
	}
}
