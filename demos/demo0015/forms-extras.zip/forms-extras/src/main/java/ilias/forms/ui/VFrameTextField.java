package ilias.forms.ui;

import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;

import oracle.ewt.graphics.GraphicUtils;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTextField;

public class VFrameTextField extends VTextField {

	private static final long serialVersionUID = 589023229941451566L;

	public static final ID TEXT_OFFSET = ID.registerProperty("textOffset");
	public static final ID TEXT_SPACING = ID.registerProperty("textSpacing");
	public static final ID LINE_WIDTH = ID.registerProperty("lineWidth");

	private int mTextOffset = 10;
	private int mTextSpacing = 4;
	private int mLineWidth = 2;
	private Color mLineColor = IliasLookAndFeel.BORDER_COLOR;

	public VFrameTextField() {
		super();
	}

	@Override
	public boolean setProperty(ID id, Object value) {
		if (id == LINE_WIDTH) {
			mLineWidth = ((Integer) value).intValue();
			return true;
		} else if (id == TEXT_OFFSET) {
			mTextOffset = ((Integer) value).intValue();
			return true;
		} else if (id == TEXT_SPACING) {
			mTextSpacing = ((Integer) value).intValue();
			return true;
		}
		return super.setProperty(id, value);
	}

	@Override
	protected void paintCanvasInterior(Graphics g) {
		FontMetrics fm = g.getFontMetrics();
		String str = getDisplayStringFilter().convertString(getText());
		int strWidth = fm.stringWidth(str);

		int spacing = strWidth > 0 ? mTextSpacing : 0;
		
		int strX = mTextOffset + spacing;
		int strY = (getInnerHeight() - fm.getHeight()) / 2;
		int align = getAlignment();
		if (align == ALIGNMENT_RIGHT) {
			strX = getInnerWidth() - strX - strWidth;
		} else if (align == ALIGNMENT_CENTER) {
			strX = (getInnerWidth() - strWidth) / 2;
		}

		if (str != null) {
			GraphicUtils.drawString(g, str, strX, strY + fm.getAscent());
		}

		Color oldColor = g.getColor();
		g.setColor(mLineColor);

		int y = getInnerHeight() / 2;
		y -= mLineWidth / 2;
		int w = getInnerWidth();
		for (int i = 0; i < mLineWidth; i++) {
			g.drawLine(1, y + i, strX - spacing, y + i);
			g.drawLine(strX + strWidth + spacing, y + i, w - 1, y + i);
		}

		g.setColor(oldColor);
	}
}
