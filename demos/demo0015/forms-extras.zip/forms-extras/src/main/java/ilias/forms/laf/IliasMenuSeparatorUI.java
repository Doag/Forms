package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericMenuSeparatorUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasMenuSeparatorUI extends GenericMenuSeparatorUI {
	public IliasMenuSeparatorUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}