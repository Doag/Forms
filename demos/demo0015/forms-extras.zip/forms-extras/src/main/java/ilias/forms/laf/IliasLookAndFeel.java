package ilias.forms.laf;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.util.Locale;

import oracle.bali.share.util.IntegerUtils;
import oracle.ewt.ColorScheme;
import oracle.ewt.HashTableDefaults;
import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.graphics.ImageUtils;
import oracle.ewt.graphics.SynthesizingImageSet;
import oracle.ewt.laf.basic.BasicLookAndFeel;
import oracle.ewt.laf.basic.DisabledBGPainter;
import oracle.ewt.laf.basic.PerComponentUIInstantiator;
import oracle.ewt.laf.basic.SingletonUIInstantiator;
import oracle.ewt.laf.basic.StringInstantiator;
import oracle.ewt.laf.generic.GenericGroupBoxPainter;
import oracle.ewt.laf.generic.GenericInsetBorderPainter;
import oracle.ewt.laf.generic.GenericRectanglePainter;
import oracle.ewt.laf.generic.GrayFilter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.FilledRectPainter;
import oracle.ewt.painter.FixedBorderPainter;
import oracle.ewt.painter.NullPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.plaf.StatusBarUI;
import oracle.ewt.plaf.TextUI;
import oracle.ewt.plaf.ToolBarUI;

public class IliasLookAndFeel extends BasicLookAndFeel {

	public static final Color DARK = new Color(0, 87, 121);
	public static final Color LIGHT = new Color(85, 159, 188);
	public static final Color BLUE = new Color(207, 222, 244);
	public static final Color BORDER_COLOR = new Color(192, 192, 192);
	public static final Color FOCUS_COLOR = new Color(123, 204, 255);
	public static final Color QUERY_COLOR = new Color(251, 230, 174);

	private static final String ILIAS_LAF = "ilias.forms.laf.Ilias";

	private static final String GENERIC_IMAGE = "oracle.ewt.laf.generic.GenericLookAndFeel#cImageInst|";
	private static final String ILIAS_IMAGE = "ilias.forms.laf.IliasLookAndFeel#imageInst|";

	public static final Font TEXT_FONT = new Font("Calibri", Font.PLAIN, 14);
	public static final Font TEXT_FONT_BOLD = new Font("Calibri", Font.BOLD, 14);
	public static final Font TITLE_FONT = new Font("Century Gothic", 1, 10);

	private static ColorScheme sColorScheme;
	private static UIDefaults sCommonDefaults;
	private static ColorScheme[] sAvailableSchemes;

	static {
		String os = System.getProperty("os.name");
		if (os.startsWith("Windows")) {
			sColorScheme = new SystemColorScheme();
		} else {
			sColorScheme = new FixedColorScheme();
		}
		sAvailableSchemes = new ColorScheme[] { sColorScheme };
	}

	public String getName() {
		return "Ilias";
	}

	public String getDisplayName(Locale locale) {
		return "Ilias Look and Feel";
	}

	public String getDescription(Locale locale) {
		return "The look and feel that so many know and love";
	}

	public boolean isNativeLookAndFeel() {
		return false;
	}

	public BorderPainter createGroupBoxPainter(Painter painter1,
			Painter painter2) {
		return new GenericGroupBoxPainter(painter1, painter2);
	}

	public boolean isGroupBoxPainter(BorderPainter painter) {
		return painter instanceof GenericGroupBoxPainter;
	}

	public String getGroupBoxTitle(BorderPainter painter) {
		if (!isGroupBoxPainter(painter))
			return null;
		GenericGroupBoxPainter localGenericGroupBoxPainter = (GenericGroupBoxPainter) painter;
		Painter localPainter = localGenericGroupBoxPainter.getLabelPainter();
		return getGroupBoxTitleFromLabelPainter(localPainter);
	}

	protected boolean isCompatibleColorScheme(ColorScheme colorScheme) {
		return colorScheme == sColorScheme;
	}

	public ColorScheme getDefaultColorScheme() {
		return getReadOnlyColorSchemes()[0];
	}

	public void setDefaultColorScheme(ColorScheme paramColorScheme) {
	}

	public static Object imageFilterInst(UIDefaults uidefaults, Object type, String s) {
		if (type.equals(LookAndFeel.DISABLING_FILTER)) {
			return new GrayFilter(1);
		}
		if (type.equals(SynthesizingImageSet.NO_MOUSE_FILTER)) {
			return new GrayFilter(0);
		}
		return null;
	}

	protected ColorScheme[] getReadOnlyColorSchemes() {
		return sAvailableSchemes;
	}

	protected static Image getImage(String name) {
		return ImageUtils.getImageResource(IliasLookAndFeel.class, "images/"
				+ name);
	}

	public static Object cImageInst(UIDefaults defaults, Object paramObject,
			String name) {
		return ImageUtils.createFilteredImage(getImage(name),
				sColorScheme.createColorizingFilter());
	}

	public static Object imageInst(UIDefaults defaults, Object paramObject,
			String name) {
		return getImage(name);
	}

	public UIDefaults getDefaults(PaintContext ctx) {
		if (sCommonDefaults == null) {
			HashTableDefaults defaults = new HashTableDefaults(50);
			BasicLookAndFeel.initCommonFixedDefaults(defaults);
			_initPerComponentInitiators(defaults);
			sColorScheme.initializeColors(defaults);
			_initCommonFixedDefaults(defaults);
			_initColorizedCommonDefaults(defaults);
			_initInitiators(defaults);
			_initColorizedDeferredDefaults(defaults);
			_initCommonDeferredDefaults(defaults);
			sCommonDefaults = defaults;
		}
		return sCommonDefaults;
	}

	private static void _initPerComponentInitiators(UIDefaults defaults) {
		Object[] arrayOfObject = { //
		"AlertUI", new PerComponentUIInstantiator(), //
				"CheckboxMenuItemUI", new PerComponentUIInstantiator(), //
				"DesktopUI", new PerComponentUIInstantiator(), //
				"MenuBarUI", new PerComponentUIInstantiator(), //
				"MenuUI", new PerComponentUIInstantiator(), //
				"MenuItemUI", new PerComponentUIInstantiator(), //
				"RadioButtonMenuItemUI", new PerComponentUIInstantiator(), //
				"PopupMenuUI", new PerComponentUIInstantiator(), //
				"WindowUI", new PerComponentUIInstantiator() };
		defaults.putDefaults(arrayOfObject);
	}

	private static void _initCommonFixedDefaults(UIDefaults defaults) {
		defaults.put("TabBar.itemFont", TEXT_FONT);
		defaults.put("TabBar.selectedItemFont", TEXT_FONT_BOLD);
		defaults.put("ToolBar.font", TEXT_FONT);
		defaults.put("ToolTip.font", TEXT_FONT);
		defaults.put("ErrorTip.font", TEXT_FONT);
		defaults.put("TitleBar.font", TITLE_FONT);
		defaults.put("Label.font", TEXT_FONT);
		defaults.put("TextField.font", TEXT_FONT);
		defaults.put("TextArea.font", TEXT_FONT);

		defaults.put(StatusBarUI.STATUSBAR_BORDER, null);
		defaults.put(StatusBarUI.STATUSBAR_ITEM_BORDER,
				new GenericInsetBorderPainter(new FixedBorderPainter(null, 1,
						1, 1, 1), false, true));

		// Used for TextArea
		GenericInsetBorderPainter insetBorderPainter1 = new GenericInsetBorderPainter();
		defaults.put(TextUI.TEXT_FIELD_LOWERED_BORDER, insetBorderPainter1);

		// Used for TextField
		GenericInsetBorderPainter insetBorderPainter2 = new GenericInsetBorderPainter(
				new FixedBorderPainter(1, 1, 1, 1), false, false);
		defaults.put(TextUI.TEXT_AREA_LOWERED_BORDER, insetBorderPainter2);

		IliasRectanglePainter plainBorderPainter = new IliasRectanglePainter();

		defaults.put(TextUI.TEXT_FIELD_PLAIN_BORDER, plainBorderPainter);
		defaults.put(TextUI.TEXT_AREA_PLAIN_BORDER, plainBorderPainter);

		GenericInsetBorderPainter insetBorderPainter = new GenericInsetBorderPainter(
				true);
		defaults.put(TextUI.TEXT_FIELD_RAISED_BORDER, insetBorderPainter);
		defaults.put(TextUI.TEXT_AREA_RAISED_BORDER, insetBorderPainter);

		defaults.put(ToolBarUI.TOOLBAR_HORIZONTAL_BORDER,
				new FixedBorderPainter(0, 5, 0, 5));
		defaults.put(ToolBarUI.TOOLBAR_VERTICAL_BORDER, new FixedBorderPainter(
				5, 0, 5, 0));
		defaults.put(ToolBarUI.BASE_IMAGE_STATE, IntegerUtils.getInteger(16));
		defaults.put(BasicLookAndFeel.WINDOW_ACTIVATION_REPAINTING,
				Boolean.FALSE);

		IliasFocusRectanglePainter focusBorderPainter = new IliasFocusRectanglePainter();

		GenericInsetBorderPainter borderPainter = new GenericInsetBorderPainter(
				new FixedBorderPainter(2, 2, 2, 2), false, true);
		defaults.put("Alert.border", new FixedBorderPainter(5, 5, 5, 5));
		defaults.put("BusyBar.border", borderPainter);
		defaults.put("Choice.border", focusBorderPainter);
		defaults.put("ComboBox.border", insetBorderPainter1);
		defaults.put("DateEditor.border", insetBorderPainter1);
		defaults.put("Grid.border", insetBorderPainter1);
		defaults.put("List.border", focusBorderPainter);
		defaults.put("PasswordField.border", insetBorderPainter1);
		defaults.put("ProgressBar.border", borderPainter);
		defaults.put("ScrollPane.border", insetBorderPainter1);
		defaults.put("Spinner.border", insetBorderPainter1);
		defaults.put("Table.border", insetBorderPainter1);
		defaults.put("TableScrollPane.border", insetBorderPainter1);
		defaults.put("TextArea.border", insetBorderPainter1);
		defaults.put("TextField.border", insetBorderPainter2);
		defaults.put("TitleBar.border", new FixedBorderPainter(null, 1, 2, 1,
				2, true, true));
		defaults.put("ToolTip.border", new GenericRectanglePainter(
				new FixedBorderPainter(1, 2, 1, 2)));
		defaults.put("ErrorTip.border", new FixedBorderPainter(3, 4, 3, 4));
		defaults.put("ScrollBar.border", plainBorderPainter);

		Painter localPainter = defaults
				.getPainter(BasicLookAndFeel.DISABLED_BG_PAINTER);
		BorderPainter localBorderPainter = NullPainter.getPainter();
		DisabledBGPainter localDisabledBGPainter = new DisabledBGPainter(
				FilledRectPainter.getPainter(), TextUI.TEXT_IS_EDITABLE_KEY);
		defaults.put("BusyBar.fill", localPainter);
		defaults.put("Choice.fill", localPainter);
		defaults.put("ComboBox.fill", localPainter);
		defaults.put("DateEditor.fill", localPainter);
		defaults.put("Grid.fill", localPainter);
		defaults.put("List.fill", localBorderPainter);
		defaults.put("PasswordField.fill", localDisabledBGPainter);
		defaults.put("ProgressBar.fill", localPainter);
		defaults.put("Scrollbar.fill", localBorderPainter);
		defaults.put("Spinner.fill", localPainter);
		defaults.put("TabBar.fill", localBorderPainter);
		defaults.put("Table.fill", localPainter);
		defaults.put("TextArea.fill", localDisabledBGPainter);
		defaults.put("TextField.fill", localDisabledBGPainter);
		defaults.put("Tree.fill", localPainter);
	}

	private static void _initColorizedCommonDefaults(UIDefaults defaults) {
		Color cControl = defaults.getColor(LookAndFeel.CONTROL);
		Color cControlText = defaults.getColor(LookAndFeel.CONTROL_TEXT);
		Color localColor3 = defaults.getColor(LookAndFeel.CONTROL_DK_SHADOW);
		Color localColor4 = defaults.getColor(LookAndFeel.TEXT_HIGHLIGHT_TEXT);
		Color cMenu = defaults.getColor(LookAndFeel.MENU);
		Color cMenuText = defaults.getColor(LookAndFeel.MENU_TEXT);
		Color cText = defaults.getColor(LookAndFeel.TEXT);
		Color cTextText = defaults.getColor(LookAndFeel.TEXT_TEXT);
		Color localColor9 = defaults.getColor(LookAndFeel.TOOL_TIP);
		Color localColor10 = defaults.getColor(LookAndFeel.INFO_TEXT);
		Color cDesktop = defaults.getColor(LookAndFeel.DESKTOP);
		Color cWindowText = defaults.getColor(LookAndFeel.WINDOW_TEXT);
		defaults.put("BusyBar.background", cControl);
		defaults.put("BusyBar.foreground", localColor4);
		defaults.put("Button.background", BLUE);
		defaults.put("ChoiceButton.background", cControl);
		defaults.put("Button.foreground", Color.black);
		defaults.put("CalendarTable.background", cControl);
		defaults.put("CheckBox.foreground", cWindowText);
		defaults.put("Choice.background", cText);
		defaults.put("Choice.foreground", cTextText);
		defaults.put("ComboBox.background", cText);
		defaults.put("ComboBox.foreground", cTextText);
		defaults.put("DateEditor.background", cText);
		defaults.put("DateEditor.foreground", cTextText);
		defaults.put("Drawer.background", cControl);
		defaults.put("Drawer.foreground", cWindowText);
		defaults.put("Desktop.background", cDesktop);
		defaults.put("EwtButton.background", cControl);
		defaults.put("EwtButton.foreground", cControlText);
		defaults.put("FontPane.background", cControl);
		defaults.put("FontPane.foreground", cWindowText);
		defaults.put("Grid.background", cText);
		defaults.put("Grid.foreground", cTextText);
		defaults.put("Label.foreground", cWindowText);
		defaults.put("List.background", cText);
		defaults.put("List.foreground", cTextText);
		defaults.put("MDIRootPane.background", cMenu);
		defaults.put("PasswordField.background", cText);
		defaults.put("PasswordField.foreground", cTextText);
		defaults.put("PivotHeader.background", cControl);
		defaults.put("PivotTable.background", cControl);
		defaults.put("PopupMenu.background", cMenu);
		defaults.put("PopupMenu.foreground", cMenuText);
		defaults.put("MenuBar.background", cMenu);
		defaults.put("MenuBar.foreground", cMenuText);
		defaults.put("ProgressBar.background", cControl);
		defaults.put("ProgressBar.foreground", cTextText);
		defaults.put("RadioButton.foreground", cTextText);
		defaults.put("Ruler.background", cText);
		defaults.put("Ruler.foreground", cTextText);
		defaults.put("ScrollBar.background", cControl);
		defaults.put("ScrollBar.foreground", localColor3);
		defaults.put("SpinButton.background", cControl);
		defaults.put("Spinner.background", cText);
		defaults.put("Spinner.foreground", cTextText);
		defaults.put("StatusBar.background", cControl);
		defaults.put("TabBar.foreground", cTextText);
		defaults.put("TableHeader.background", cControl);
		defaults.put("TableHeader.foreground", cControlText);
		defaults.put("TableScrollPane.background", cControl);
		defaults.put("Table.background", cControl);
		defaults.put("Table.foreground", cTextText);
		defaults.put("TextArea.background", cText);
		defaults.put("TextArea.foreground", cTextText);
		defaults.put("TextField.background", cText);
		defaults.put("TextField.foreground", cTextText);
		defaults.put("EWTToggleButton.background", cControl);
		defaults.put("EWTToggleButton.foreground", cControlText);
		defaults.put("ToolBar.background", cControl);
		defaults.put("ToolBar.foreground", cControlText);
		defaults.put("ToolTip.background", localColor9);
		defaults.put("ToolTip.foreground", localColor10);
		defaults.put("Tree.background", cText);
		defaults.put("Tree.foreground", cTextText);
		defaults.put("Window.background", cMenu);
		defaults.put("TabPanel.itemBackground", cControl);
		defaults.put("TabBar.itemBackground", Color.white);
		defaults.put("TabBar.selectedItemBackground", BLUE);
		defaults.put("TabBar.inactiveSelectedItemBackground", cControl);
		defaults.put("ErrorTip.background", Color.RED);
		defaults.put("ErrorTip.foreground", Color.WHITE);
	}

	private static void _initInitiators(UIDefaults defaults) {
		Object[] arrayOfObject = { //
		"ArrowBoxUI", new SingletonUIInstantiator(), //
				"BusyBarUI", new SingletonUIInstantiator(), //
				"ButtonUI", new SingletonUIInstantiator(), //
				"CalendarTableUI", new SingletonUIInstantiator(), //
				"CheckBoxUI", new SingletonUIInstantiator(), //
				"ChoiceUI", new SingletonUIInstantiator(), //
				"ComboBoxUI", new SingletonUIInstantiator(), //
				"ComponentUI", new SingletonUIInstantiator(), //
				"DateEditorUI", new SingletonUIInstantiator(), //
				"DrawerUI", new SingletonUIInstantiator(), //
				"FontPaneUI", new SingletonUIInstantiator(), //
				"EwtButtonUI", new SingletonUIInstantiator(), //
				"GridUI", new SingletonUIInstantiator(), //
				"LabelUI", new SingletonUIInstantiator(), //
				"ListUI", new SingletonUIInstantiator(), //
				"MenuSeparatorUI", new SingletonUIInstantiator(), //
				"MeterUI", new SingletonUIInstantiator(), //
				"MDIRootPaneUI", new SingletonUIInstantiator(), //
				"PasswordFieldUI", new SingletonUIInstantiator(), //
				"RadioButtonUI", new SingletonUIInstantiator(), //
				"EWTToggleButtonUI", new SingletonUIInstantiator(), //
				"PivotGridUI", new SingletonUIInstantiator(), //
				"PivotHeaderUI", new SingletonUIInstantiator(), //
				"PivotTableUI", new SingletonUIInstantiator(), //
				"ProgressBarUI", new SingletonUIInstantiator(), //
				"RulerUI", new SingletonUIInstantiator(), //
				"ScrollBarUI", new SingletonUIInstantiator(), //
				"ScrollPaneUI", new SingletonUIInstantiator(), //
				"ShuttleUI", new SingletonUIInstantiator(), //
				"SplitPaneUI", new SingletonUIInstantiator(), //
				"SliderUI", new SingletonUIInstantiator(), //
				"SpinButtonUI", new SingletonUIInstantiator(), //
				"SpinnerUI", new SingletonUIInstantiator(), //
				"StatusBarUI", new SingletonUIInstantiator(), //
				"TabBarUI", new SingletonUIInstantiator(), //
				"TabbedPaneUI", new SingletonUIInstantiator(), //
				"TableUI", new SingletonUIInstantiator(), //
				"TableHeaderUI", new SingletonUIInstantiator(), //
				"TableScrollPaneUI", new SingletonUIInstantiator(), //
				"TextAreaUI", new SingletonUIInstantiator(), //
				"TextFieldUI", new SingletonUIInstantiator(), //
				"TitleBarUI", new SingletonUIInstantiator(), //
				"ToolBarUI", new SingletonUIInstantiator(), //
				"ToolTipUI", new SingletonUIInstantiator(), //
				"TreeUI", new SingletonUIInstantiator(), //
				"WizardUI", new SingletonUIInstantiator(), //
				"ErrorTipUI", new SingletonUIInstantiator() };
		defaults.putDefaults(arrayOfObject);
	}

	private static void _initColorizedDeferredDefaults(UIDefaults defaults) {
		Object[] arrayOfObject = { //
				"Slider.pointerStrip",
				new StringInstantiator(GENERIC_IMAGE + "sliderArrowStrip.gif",
						false), //
				"SpinButton.upStrip",
				new StringInstantiator(GENERIC_IMAGE + "spinUpStrip.gif", false), //
				"SpinButton.downStrip",
				new StringInstantiator(GENERIC_IMAGE + "spinDownStrip.gif",
						false), //
				"SpinButton.leftStrip",
				new StringInstantiator(GENERIC_IMAGE + "spinLeftStrip.gif",
						false), //
				"SpinButton.rightStrip",
				new StringInstantiator(GENERIC_IMAGE + "spinRightStrip.gif",
						false), //
				"Choice.arrowImage",
				new StringInstantiator(GENERIC_IMAGE + "choiceStrip.gif", false), //
				"BusyBar.stripImage",
				new StringInstantiator(GENERIC_IMAGE + "busyStrip.gif", false), //
				"Tree.openImage",
				new StringInstantiator(GENERIC_IMAGE + "expand.gif", false), //
				"Tree.closedImage",
				new StringInstantiator(GENERIC_IMAGE + "collapse.gif", false), //
				"Tree.multiItemDrag",
				new StringInstantiator(GENERIC_IMAGE + "multiItemDrag.gif",
						false), //
				"checkboxStrip",
				new StringInstantiator(ILIAS_IMAGE + "checkboxStrip.gif", false), //
				"checkboxQueryStrip",
				new StringInstantiator(ILIAS_IMAGE + "checkboxQueryStrip.gif",
						false), //
				"radioButtonStrip",
				new StringInstantiator(ILIAS_IMAGE + "radioButtonStrip.gif",
						false), //
				"radioButtonQueryStrip",
				new StringInstantiator(ILIAS_IMAGE
						+ "radioButtonQueryStrip.gif", false), //
				"menuCheckBoxStrip",
				new StringInstantiator(GENERIC_IMAGE + "menuCheckBoxStrip.gif",
						false), //
				"menuRadioButtonStrip",
				new StringInstantiator(GENERIC_IMAGE
						+ "menuRadioButtonStrip.gif", false), //
				"Shuttle.rightArrow",
				new StringInstantiator(GENERIC_IMAGE + "rightArrow.gif", false), //
				"Shuttle.rightAllArrow",
				new StringInstantiator(GENERIC_IMAGE + "rightAllArrow.gif",
						false), //
				"Shuttle.leftArrow",
				new StringInstantiator(GENERIC_IMAGE + "leftArrow.gif", false), //
				"Shuttle.leftAllArrow",
				new StringInstantiator(GENERIC_IMAGE + "leftAllArrow.gif",
						false), //
				"Shuttle.downArrow",
				new StringInstantiator(GENERIC_IMAGE + "downArrow.gif", false), //
				"Shuttle.downAllArrow",
				new StringInstantiator(GENERIC_IMAGE + "downAllArrow.gif",
						false), //
				"Shuttle.upArrow",
				new StringInstantiator(GENERIC_IMAGE + "upArrow.gif", false), //
				"Shuttle.upAllArrow",
				new StringInstantiator(GENERIC_IMAGE + "upAllArrow.gif", false), //
				"Shuttle.reorderUpRight",
				new StringInstantiator(GENERIC_IMAGE + "reorderUpRight.gif",
						false), //
				"Shuttle.reorderDownRight",
				new StringInstantiator(GENERIC_IMAGE + "reorderDownRight.gif",
						false), //
				"Shuttle.reorderUpLeft",
				new StringInstantiator(GENERIC_IMAGE + "reorderUpLeft.gif",
						false), //
				"Shuttle.reorderDownLeft",
				new StringInstantiator(GENERIC_IMAGE + "reorderDownLeft.gif",
						false),
				"ScrollBar.alleyImage",
				new StringInstantiator(GENERIC_IMAGE + "alleyStipple.gif",
						false),
				"SpinButton.rightArrow",
				new StringInstantiator(GENERIC_IMAGE + "spinRightArrow.gif",
						false),
				"SpinButton.leftArrow",
				new StringInstantiator(GENERIC_IMAGE + "spinLeftArrow.gif",
						false),
				"SpinButton.downArrow",
				new StringInstantiator(GENERIC_IMAGE + "spinDownArrow.gif",
						false),
				"SpinButton.upArrow",
				new StringInstantiator(GENERIC_IMAGE + "spinUpArrow.gif", false),
				"TabBar.scrollLeft",
				new StringInstantiator(GENERIC_IMAGE + "tableft.gif", false),
				"TabBar.scrollRight",
				new StringInstantiator(GENERIC_IMAGE + "tabright.gif", false),
				"TabBar.scrollBoth",
				new StringInstantiator(GENERIC_IMAGE + "tabboth.gif", false),
				"TabBar.visibleStrip",
				new StringInstantiator(GENERIC_IMAGE + "tabvisstrip.gif", false),
				"TabBar.visible",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericTabBarUI", false) };
		defaults.putDefaults(arrayOfObject);
	}

	private static void _initCommonDeferredDefaults(UIDefaults defaults) {
		Object[] arrayOfObject = { //
				"CollapsedNodePainter",
				new StringInstantiator("oracle.ewt.laf.generic.GenericTreeUI",
						false), //
				"ExpandedNodePainter",
				new StringInstantiator("oracle.ewt.laf.generic.GenericTreeUI",
						false), //
				"UpScrollPainter",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"DownScrollPainter",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"LeftScrollPainter",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"RightScrollPainter",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"UpScrollSet",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"DownScrollSet",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"LeftScrollSet",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"RightScrollSet",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericScrollBarUI", false), //
				"checkboxSet",
				new StringInstantiator(ILIAS_LAF + "CheckBoxUI", false), //
				"checkboxQuerySet",
				new StringInstantiator(ILIAS_LAF + "CheckBoxUI", false), //
				"radioButtonSet",
				new StringInstantiator(ILIAS_LAF + "RadioButtonUI", false), //
				"radioButtonQuerySet",
				new StringInstantiator(ILIAS_LAF + "RadioButtonUI", false), //
				"DefaultCellPainter",
				new StringInstantiator("oracle.ewt.laf.generic.GenericGridUI",
						false), //
				"DefaultHeaderPainter",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericTableHeaderUI", false), //
				"CheckBoxPainter",
				new StringInstantiator(ILIAS_LAF + "CheckBoxUI", false), //
				"CheckBoxComponentPainter",
				new StringInstantiator(ILIAS_LAF + "CheckBoxUI", false), //
				"RadioButtonPainter",
				new StringInstantiator(ILIAS_LAF + "RadioButtonUI", false), //
				"RadioButtonComponentPainter",
				new StringInstantiator(ILIAS_LAF + "RadioButtonUI", false), //
				"Grid.checkPainter",
				new StringInstantiator("oracle.ewt.laf.generic.GenericGridUI",
						false), //
				"Grid.radioPainter",
				new StringInstantiator("oracle.ewt.laf.generic.GenericGridUI",
						false), //
				"Alert.errorImage",
				new StringInstantiator(
						"ilias.forms.laf.IliasLookAndFeel#imageInst|stop.gif",
						false), //
				"Alert.warningImage",
				new StringInstantiator(
						"ilias.forms.laf.IliasLookAndFeel#imageInst|caution.gif",
						false), //
				"Alert.informationImage",
				new StringInstantiator(
						"ilias.forms.laf.IliasLookAndFeel#imageInst|note.gif",
						false), //
				"Alert.questionImage",
				new StringInstantiator(
						"ilias.forms.laf.IliasLookAndFeel#imageInst|question.gif",
						false), //
				"ColorChoice.arrow",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|colorChoice.gif",
						false), //
				"Grid.checkImage",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|check.gif",
						false), //
				LookAndFeel.DISABLING_FILTER,
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageFilterInst|",
						true), //
				SynthesizingImageSet.NO_MOUSE_FILTER,
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageFilterInst|",
						true), //
				"HorizInsetSeparator",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericSeparatorPainter", false), //
				"HorizOutsetSeparator",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericSeparatorPainter", false), //
				"VertInsetSeparator",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericSeparatorPainter", false), //
				"VertOutsetSeparator",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericSeparatorPainter", false), //
				"FileChooser.folder",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|folder.gif",
						false), //
				"Window.closeStrip",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|closeStrip.gif",
						false), //
				"Window.maximizeStrip",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|maximizeStrip.gif",
						false), //
				"Window.minimizeStrip",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|minimizeStrip.gif",
						false), //
				"Window.restoreStrip",
				new StringInstantiator(
						"oracle.ewt.laf.generic.GenericLookAndFeel#imageInst|restoreStrip.gif",
						false) };
		defaults.putDefaults(arrayOfObject);
	}
}
