package ilias.forms.ui;

import java.awt.Color;
import java.util.Comparator;
import java.util.Date;

public class VDateExpiredFieldRange implements Comparator<VDateExpiredFieldRange>{

	private Date sDate; 
	private Date eDate; 
	private Color color; 
	private int priority;
	
	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	public VDateExpiredFieldRange(){
		  
	}
	
	public VDateExpiredFieldRange(int priority, Date sDate, Date eDate, Color color){
	  this.sDate = sDate;
	  this.eDate = eDate;
	  this.color = color;
	  this.priority = priority;
	}

	public Date getsDate() {
		return sDate;
	}

	public void setsDate(Date sDate) {
		this.sDate = sDate;
	}

	public Date geteDate() {
		return eDate;
	}

	public void seteDate(Date eDate) {
		this.eDate = eDate;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public int compare(VDateExpiredFieldRange o1, VDateExpiredFieldRange o2) {
		if (o1.getPriority() < o2.getPriority()){
			return 1;
		} else{
			return -1;	
		}
	}
}
