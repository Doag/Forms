package ilias.forms.ui;

public class VRadioGroupField extends VRadioButtonField {

	private static final long serialVersionUID = 3943643911278829987L;

	public VRadioGroupField() {
		super();
	}
}
