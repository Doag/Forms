package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericDesktopUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasDesktopUI extends GenericDesktopUI {
	public IliasDesktopUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}