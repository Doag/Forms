package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericTitleBarUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasTitleBarUI extends GenericTitleBarUI {

	public IliasTitleBarUI(LWComponent component) {
		super(component);
	}
}
