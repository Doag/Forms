package ilias.clipboard;

import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

import oracle.ewt.graphics.GraphicUtils;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.lwAWT.lwMenu.LWMenuItem;
import oracle.ewt.lwAWT.lwMenu.LWPopupMenu;
import oracle.ewt.lwAWT.lwText.LWTextArea;
import oracle.ewt.lwAWT.lwText.LWTextField;
import oracle.forms.ui.VTextArea;
import oracle.forms.ui.VTextField;

public class MyClipboard implements ActionListener {

    ////////////////////////////////////////////////////////////////////////////

	public static class MyComparator implements Comparator<MyEntry> {
        public int compare(MyEntry o1, MyEntry o2)
        {
            int res = o1.getKey().compareTo(o2.getKey());
            if ( res == 0 ) {
                res = o1.getValue().compareTo(o2.getValue());
            }
            return res;
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    
	public static class MyEntry extends LWMenuItem {
		private static final long serialVersionUID = 1206439985783397285L;

		private String mKey;
        private String mValue;
        //private int mWidth, mHeight;
        //private long mTimestamp;
        
		public MyEntry(String key, String value) {
            super();
            mKey = key;
            mValue = value;
            setFont(IliasLookAndFeel.TEXT_FONT);
        }
        
        public String getKey() {return mKey; }
        public String getValue() {return mValue; }

		public void paintInterior(Graphics g) {
            Dimension d = getInnerSize();
            FontMetrics fm = getFontMetrics(getFont());
            Color oldColor = g.getColor();
            Color textColor;
			if (this.isSelected()) {
                g.setColor(IliasLookAndFeel.BLUE);
                g.fillRect(0, 0, (int)d.getWidth(), (int)d.getHeight());
                textColor = Color.white;
			} else {
                g.setColor(Color.white);
                g.fillRect(0, 0, (int)d.getWidth(), (int)d.getHeight());
                textColor = Color.black;
            }
			/*
            g.setColor(Color.lightGray);
            g.drawRect(-1, -1, mMyClipboard.getKeyWidth(), (int)d.getHeight());
            g.drawRect(mMyClipboard.getKeyWidth()-1, -1, (int)d.getWidth() - mMyClipboard.getKeyWidth(), (int)d.getHeight());
            */
            g.setColor(Color.lightGray);
            g.drawLine(mMyClipboard.getKeyWidth(), 0, mMyClipboard.getKeyWidth(), (int)d.getHeight());
            g.setColor(textColor);
            GraphicUtils.drawString(g, mKey, 3, d.height-fm.getDescent()-1);
            GraphicUtils.drawString(g, mValue, mMyClipboard.getKeyWidth() + 3, d.height-fm.getDescent()-1);
            g.setColor(oldColor);
        }

		public int getKeyWidth() {
            FontMetrics fm = getFontMetrics(getFont());
            return fm.stringWidth(mKey);
        }
        
		public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return convertInnerToOuterSize(mMyClipboard.getKeyWidth() + fm.stringWidth(mValue) + 6, fm.getHeight()+1);
        }

		public Dimension getMinimumSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return convertInnerToOuterSize(mMyClipboard.getKeyWidth(), fm.getHeight()+1);
        }
    
		public Dimension getMaximumSize() {
            FontMetrics fm = getFontMetrics(getFont());
            return convertInnerToOuterSize(mMyClipboard.getKeyWidth() + fm.stringWidth(mValue) + 6, fm.getHeight()+1);
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    
    public static MyClipboard mMyClipboard = new MyClipboard(new MyComparator());

    private Comparator<MyEntry> mComparator;
    private ArrayList<MyEntry> mList;
    private int mWidthKey;
    LWComponent mComponent;
    
	public MyClipboard(Comparator<MyEntry> comparator) {
		mComparator = comparator;
		mList = new ArrayList<MyEntry>(20);
	}
    
	public void add(MyEntry newEntry) {
        newEntry.addActionListener(this);
        newEntry.setActionCommand(newEntry.getValue());

        int i = 0;
        for(Iterator<MyEntry> iter = mList.iterator(); iter.hasNext();)
        {
            MyEntry entry = iter.next();
            int d = mComparator.compare(entry, newEntry);
            if ( d == 0 )
                return;
            if ( d > 0)
            {
                mList.add(i, newEntry);
                return;
            }
            i++;
        }
        mList.add(newEntry);
    }
    
    public int size() { return mList.size(); }
    public Iterator<MyEntry> iterator() { return mList.iterator(); }
    public int getKeyWidth() { return mWidthKey + 6; }

	public void popup(LWComponent component, int x, int y) {
        mWidthKey = 0;
        mComponent = component;
        LWPopupMenu popup = new LWPopupMenu();
		for (Iterator<MyEntry> iter = mMyClipboard.iterator(); iter.hasNext();) {
            MyEntry entry = iter.next();
            mWidthKey = Math.max(mWidthKey, entry.getKeyWidth());
            popup.add(entry);
        }
        popup.popup(mComponent, x, y);
    }

	public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
		synchronized (mComponent) {
            if ( mComponent instanceof VTextField) {
                LWTextField f = (LWTextField)mComponent;
                int i = f.getSelectionStart();
                int j = f.getSelectionEnd();
                f.replaceRange(s, i, j);
            }
            if ( mComponent instanceof VTextArea) {
                LWTextArea f = (LWTextArea)((VTextArea)mComponent).getContent();
                int i = f.getSelectionStart();
                int j = f.getSelectionEnd();
                f.replaceRange(s, i, j);
            }
        }
    }

    /** Create an item with a label and an icon */
	static public LWMenuItem createPopupItem(ActionListener listener,
			String label, String action, String icon, boolean flag) {
        LWMenuItem item = new LWMenuItem(label);
        item.setImage(loadImage(icon));
        item.setActionCommand(action);
        item.addActionListener(listener);
        item.setEnabled(flag);
        return item;
    }

    /** Loads an image */
	static private Image loadImage(String name) {
        InputStream in = mMyClipboard.getClass().getResourceAsStream(name);
		try {
            int n = in.available();
            byte[] bytes = new byte[n];
            int o = 0;
            while((o+=in.read(bytes,o,n-o))<n);
            in.close();
            return Toolkit.getDefaultToolkit().createImage(bytes);
        }
		catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
