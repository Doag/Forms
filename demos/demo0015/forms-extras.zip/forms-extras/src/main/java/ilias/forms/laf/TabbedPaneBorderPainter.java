package ilias.forms.laf;

import java.awt.Color;
import java.awt.Graphics;

import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;

public class TabbedPaneBorderPainter extends AbstractBorderPainter {
	public static final int TOP = 0;
	public static final int BOTTOM = 1;
	public static final int LEFT = 2;
	public static final int RIGHT = 3;

	private int _orientation;

	private static final ImmInsets _TOP_INSETS = new ImmInsets(2, 0, 0, 0);
	private static final ImmInsets _BOTTOM_INSETS = new ImmInsets(0, 0, 2, 0);
	private static final ImmInsets _LEFT_INSETS = new ImmInsets(1, 1, 0, 0);
	private static final ImmInsets _RIGHT_INSETS = new ImmInsets(0, 0, 20, 4);
	private static final ImmInsets _FILL_INSETS = new ImmInsets(2, 2, 2, 2);

	public TabbedPaneBorderPainter(int orientation) {
		this._orientation = orientation;
	}

	public int getRepaintFlags(PaintContext ctx) {
		return super.getRepaintFlags(ctx) | 0x400;
	}

	protected ImmInsets getOwnInsets(PaintContext paramPaintContext) {
		if (this._orientation == TOP) {
			return _TOP_INSETS;
		} else if (this._orientation == BOTTOM) {
			return _BOTTOM_INSETS;
		} else if (this._orientation == LEFT) {
			return _LEFT_INSETS;
		} else {
			return _RIGHT_INSETS;
		}
	}

	public ImmInsets getOwnFillInsets(PaintContext paramPaintContext) {
		return _FILL_INSETS;
	}

	protected void paintBorder(PaintContext ctx, Graphics g, int x, int y,
			int w, int h) {
		Color oldColor = g.getColor();
		g.setColor(IliasLookAndFeel.BLUE);
		if (_orientation == TOP) {
			g.fillRect(x, y, w, 2);
		} else if (_orientation == BOTTOM) {
			g.fillRect(x, y + h - 2, w, 2);
		} else if (_orientation == LEFT) {
			g.fillRect(x, y, 1, h);
			g.fillRect(x, y, w, 1);
		} else {
			g.fillRect(x, y + w - 4, 4, h);
			g.fillRect(x, y + h - 20, w, 20);
		}
		g.setColor(oldColor);
	}

	protected boolean isBorderTransparent(PaintContext paramPaintContext) {
		return false;
	}
}
