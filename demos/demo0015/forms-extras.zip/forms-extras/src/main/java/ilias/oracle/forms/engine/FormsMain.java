package ilias.oracle.forms.engine;

import ilias.CollapsibleFramesPJC;
import ilias.forms.laf.IliasLookAndFeel;
import ilias.forms.ui.ErrorStack;
import ilias.forms.ui.ErrorStackLayout;
import ilias.forms.vgs.IliasDisplayFrame;

import java.awt.BorderLayout;
import java.util.HashMap;
import java.util.Map;

import oracle.ewt.UIManager;
import oracle.forms.engine.Main;
import oracle.forms.engine.Runform;
import oracle.forms.ui.mdi.MDIContainer;

public class FormsMain extends Main {

	private static final long serialVersionUID = 4313831765286482597L;

	private ErrorStack errorStack;

    private Map<String, Map<String, IliasDisplayFrame>> collapsibleFrames = new HashMap<String, Map<String, IliasDisplayFrame>>();
    private Map<String, CollapsibleFramesPJC> collapsibleFrameBeans = new HashMap<String, CollapsibleFramesPJC>();
	
	/**
	 * We want our look and feel.
	 * 
	 * Create an errorstack (corner bottom right)
	 */
	@Override
	protected void createRunform(Runform runform) {
		UIManager.setLookAndFeel(new IliasLookAndFeel());

		MDIContainer mdiContainer = getMDIContainer();

		errorStack = new ErrorStack();

		BorderLayout layout = (BorderLayout) mdiContainer.getLayout();
		ErrorStackLayout newLayout = new ErrorStackLayout(layout, errorStack);
		mdiContainer.setLayout(newLayout);
		mdiContainer.add(errorStack, 0);

		super.createRunform(runform);
	}

	public ErrorStack getErrorStack() {
		return errorStack;
	}

	/**
	 * Use our patched Runform class
	 */
	protected Runform newRunform(Main main, Runform runform) {
		System.out.println("Creating new runform instance");
		return new FormsRunform(main, runform);
	}

    /**
     * Collapsible frames
     */
    public void registerCollapsibleFrame(IliasDisplayFrame frame) {
    //    System.out.println("Registering frame " + frame.getFormName() + '.' + frame.getFrameName());
        String formName = frame.getFormName();
        Map<String, IliasDisplayFrame> frames = collapsibleFrames.get(formName);
        if (frames == null) {
            frames = new HashMap<String, IliasDisplayFrame>();
            collapsibleFrames.put(formName, frames);
        }
        String frameName = frame.getFrameName();
        frames.put(frameName, frame);
    }

    public void unregisterCollapsibleFrame(IliasDisplayFrame frame) {
    //    System.out.println("Unregistering frame " + frame.getFormName() + '.' + frame.getFrameName());
        String formName = frame.getFormName();
        Map<String, IliasDisplayFrame> frames = collapsibleFrames.get(formName);
        if (frames != null) {
            String frameName = frame.getFrameName();
            frames.remove(frameName);
        }
    }
    
    public void registerCollapsibleFramesBean(CollapsibleFramesPJC bean) {
    //    System.out.println("Registering bean " + bean.getFormName());
        String formName = bean.getFormName();
        collapsibleFrameBeans.put(formName, bean);
    }

    public void unregisterCollapsibleFramesBean(CollapsibleFramesPJC bean) {
    //    System.out.println("Unregistering bean " + bean.getFormName());
        String formName = bean.getFormName();
        collapsibleFrameBeans.remove(formName);
    }

    public CollapsibleFramesPJC getCollapsibleFramesBean(String name) {
        return collapsibleFrameBeans.get(name);
    }

    public IliasDisplayFrame getCollapsibleFrame(String formName, String frameName) {
        Map<String, IliasDisplayFrame> frames = collapsibleFrames.get(formName);
        if (frames != null) {
            return frames.get(frameName);
        } else {
            return null;
        }
    }
}
