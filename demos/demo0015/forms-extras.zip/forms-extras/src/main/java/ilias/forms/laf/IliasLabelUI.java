package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericLabelUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasLabelUI extends GenericLabelUI {

	public IliasLabelUI(LWComponent component) {
		super(component);
	}
}
