package ilias.forms.laf;

import java.awt.Color;

import oracle.ewt.painter.ColorChange;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;

public class IliasScrollbarColorChange extends ColorChange {

	public IliasScrollbarColorChange(Painter paramPainter) {
		super(paramPainter);
	}

	@Override
	protected Color getColor(PaintContext paramPaintContext) {
		return new Color(245, 245, 245);
	}

}
