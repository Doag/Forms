package ilias.forms.ui;

import ilias.forms.error.ErrorComponent;
import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;

import oracle.ewt.painter.BorderPainter;
import oracle.forms.properties.BorderBevel;
import oracle.forms.properties.ID;
import oracle.forms.ui.VRadioButton;

public class VRadioButtonField extends VRadioButton implements ErrorComponent {

	private static final long serialVersionUID = 3108013435668083359L;

	private static final ID ERROR_STRING = ID.registerProperty("errorString");

	private boolean inEnterQuery = false;

	protected final RadioButtonComponentBorder border;

	public VRadioButtonField() {
		super();
		border = new RadioButtonComponentBorder(this);
	}

	@Override
	public boolean setProperty(ID id, Object value) {
		if (id == ID.BORDER_BEVEL) {
			border.setBorderBevel((BorderBevel) value);
		} else if (id.toID() == ERROR_STRING.toID()) {
			return setErrorStringProperty((String) value);
		} else if (id == ID.BACKGROUND) {
			Color bgc = (Color)value;
			if (bgc.getRGB() == IliasLookAndFeel.QUERY_COLOR.getRGB()) {
				inEnterQuery = true;
				repaint();
				return true;
			} else {
				inEnterQuery = false;
				repaint();
				return super.setProperty(id, value);
			}
		}
		return super.setProperty(id, value);
	}

	@Override
	protected int getPaintState() {
		// If in enter query mode, set an additional flag in the state
		// See the IliasToggleButtonUIPainter where it is used
		int state = super.getPaintState();
		if (inEnterQuery) {
			state += 256;
		}
		return state;
	}

	private boolean setErrorStringProperty(String error) {
		setErrorString(error);
		return true;
	}

	public void setErrorString(String error) {
		border.setErrorString(error);
	}

	public String getErrorString() {
		return border.getErrorString();
	}

	@Override
	public BorderPainter getBorderPainter() {
		return border.getBorderPainter();
	}
}
