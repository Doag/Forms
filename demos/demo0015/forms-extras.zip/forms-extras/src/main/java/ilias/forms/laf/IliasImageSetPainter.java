package ilias.forms.laf;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import oracle.ewt.graphics.ImageSet;
import oracle.ewt.graphics.ImageStrip;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AbstractPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;

public class IliasImageSetPainter extends AbstractPainter {
	private final ImageSet _imageSet[];
	private final Image _baseImage;

	public IliasImageSetPainter(Image baseImage) {
		_baseImage = baseImage;
		_imageSet = new ImageSet[12];
		_imageSet[5] = new ImageStrip(_baseImage, IliasToggleButtonUI.IMAGESTRIP_MASK);
	}

	private ImageSet getImageSet(PaintContext ctx) {
		ImageSet image = _imageSet[5];
		LWComponent comp = (LWComponent) ctx.getImageObserver();
		Integer scale = (Integer) comp.getClientProperty("IliasScale");
		if (scale != null) {
			int index = (scale - 75) / 5;
			image = _imageSet[index];
			if (image == null) {
				int baseWidth = _baseImage.getWidth(null);
				int width = baseWidth * scale / 100;
				Image scaled = _baseImage.getScaledInstance(width, width * 8, Image.SCALE_AREA_AVERAGING);
				image = _imageSet[index] = new ImageStrip(scaled, IliasToggleButtonUI.IMAGESTRIP_MASK);
			}
		}
		return image;
	}

	@Override
	public Dimension getSize(PaintContext ctx, int w, int h) {
		return getMinimumSize(ctx);
	}

	@Override
	public Dimension getMinimumSize(PaintContext ctx) {
		Dimension size = getImageSet(ctx).getSize();
		return size;
	}

	@Override
	public Dimension getMaximumSize(PaintContext ctx) {
		return getMinimumSize(ctx);
	}

	public void paint(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		ImageSet image = getImageSet(ctx);
		int state = getPaintState(ctx) & 0x9F;
		image.paintImage(state, g, x, y, ctx.getImageObserver());
	}

	public boolean isTransparent(PaintContext ctx) {
		return _imageSet[5].isTransparent();
	}

	public int getRepaintFlags(PaintContext ctx) {
		return _imageSet[5].getAvailableImageFlags();
	}

	public Painter getPainterAt(PaintContext ctx, int paramInt1, int paramInt2,
			int paramInt3, int paramInt4, Painter painter) {
		ImageSet image = getImageSet(ctx);
		if (image.contains(paramInt3, paramInt4)) {
			return this;
		}
		return null;
	}

	protected int getPaintState(PaintContext ctx) {
		return ctx.getPaintState();
	}
}