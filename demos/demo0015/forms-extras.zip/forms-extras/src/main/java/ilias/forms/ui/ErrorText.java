package ilias.forms.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import oracle.ewt.lwAWT.LWLabel;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;

public class ErrorText extends LWLabel {

	private static final long serialVersionUID = -6540367162838094643L;

	private static final ErrorTextBorderPainter borderPainter = new ErrorTextBorderPainter();

	public ErrorText(String text) {
		super(text);
		if (getFont() == null) {
			setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		setBackground(Color.white);
	}

	@Override
	protected void processMouseEvent(MouseEvent event) {
		if (event.getID() == MouseEvent.MOUSE_CLICKED) {
			onClick();
		}
		super.processMouseEvent(event);
	}
	
	protected void onClick() {
	}

	@Override
	public BorderPainter getBorderPainter() {
		return borderPainter;
	}

	private String getDisplayText() {
		FontMetrics fm = getFontMetrics(getFont());
		int w = getInnerSize().width;

		String result = "";
		String[] lines = getText().split("\\n");
		for(String line : lines) {
			int len = line.length();
			int pos = -1;
			int beg = 0;
			int sav = 0;
			while (true) {
				int off = pos + 1;
				if (off >= len) {
					break;
				}
				pos = line.indexOf(' ', off);
				if (pos == -1) {
					pos = len;
				}
				int width = fm.stringWidth(line.substring(beg, pos));
				if (width > w) {
					if (sav <= beg) {
						sav = pos;
					}
					result += line.substring(beg, sav);
					if (sav < len) {
						result += '\n';
					}
					beg = sav + 1;
					pos = sav;
				}
				sav = pos;
			}
			if (beg < pos) {
				result += line.substring(beg, pos);
			}
			result += '\n';
		}
		return result;
	}

	public int getTextHeight() {
		int extra = getHeight() - getInnerSize().height;
		FontMetrics fm = getFontMetrics(getFont());
		String text = getDisplayText();
		if (text != null) {
			return fm.getHeight() * text.split("\\n").length + extra;
		}
		return extra;
	}

	@Override
	protected Object getPaintData(Object key) {
		if (key == null || key == PaintContext.LABEL_KEY) {
			return getDisplayText();
		} else {
			return super.getPaintData(key);
		}
	}

	public static class ErrorTextBorderPainter extends AbstractBorderPainter {

		private static final ImmInsets _INSETS0 = new ImmInsets(4, 4, 4, 4);

		protected ImmInsets getOwnInsets(PaintContext ctx) {
			return _INSETS0;
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			Color oldColor = g.getColor();
			g.setColor(Color.white);
			g.drawRect(x, y, w - 1, h - 1);
			g.drawRect(x+1, y+1, w - 3, h - 3);
			g.drawRect(x+2, y+2, w - 5, h - 5);
			g.drawRect(x+3, y+3, w - 7, h - 7);
			g.setColor(oldColor);
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | 0x80;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return true;
		}
	}
}
