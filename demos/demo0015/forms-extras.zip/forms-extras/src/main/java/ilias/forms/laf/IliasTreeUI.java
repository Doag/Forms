package ilias.forms.laf;

import oracle.ewt.dTree.DTreeItem;
import oracle.ewt.laf.generic.GenericTreeUI;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.Painter;

public class IliasTreeUI extends GenericTreeUI {
	
	public IliasTreeUI(LWComponent comp) {
		super(comp);
	}

	@Override
	public Painter getItemPainter(LWComponent tree, DTreeItem item) {
		return super.getItemPainter(tree, item);
	}
}