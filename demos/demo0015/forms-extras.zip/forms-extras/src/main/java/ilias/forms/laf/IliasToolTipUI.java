package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericToolTipUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasToolTipUI extends GenericToolTipUI {
	public IliasToolTipUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}