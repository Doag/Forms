package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericComboBoxUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasComboBoxUI extends GenericComboBoxUI {
	public IliasComboBoxUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}