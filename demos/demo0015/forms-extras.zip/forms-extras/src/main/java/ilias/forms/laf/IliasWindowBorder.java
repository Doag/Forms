package ilias.forms.laf;

import java.awt.Color;
import java.awt.Graphics;

import oracle.ewt.lwAWT.lwWindow.LWWindow;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;

public class IliasWindowBorder extends AbstractBorderPainter {

	private LWWindow _window;
	private static ImmInsets _sInsets = new ImmInsets(2, 2, 2, 2);
	//private static ImmInsets _sNonResizableInsets = new ImmInsets(1, 1, 1, 1);
	private static ImmInsets _sNonResizableInsets = new ImmInsets(4, 4, 4, 4);

	public IliasWindowBorder(LWWindow window) {
		super(null);
		this._window = window;
	}

	@Override
	protected ImmInsets getOwnInsets(PaintContext ctx) {
		//ImmInsets immsets = _isResizable() ? _sInsets : _sNonResizableInsets;
		ImmInsets immsets = _sNonResizableInsets;
		return immsets;
	}

	@Override
	protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
		Color oldColor = g.getColor();
		g.setColor(IliasLookAndFeel.DARK);
		ImmInsets insets = getOwnInsets(ctx);
		for (int i=0; i<insets.top; i++) {
			g.drawRect(x + i, y + i, w - i * 2 - 1, h - i * 2 - 1);
		}
		g.setColor(oldColor);
	}

	protected boolean isBorderTransparent(PaintContext paramPaintContext) {
		return false;
	}

	private boolean _isResizable() {
		return _window == null ? false : _window.isResizable();
	}
}
