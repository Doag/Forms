package ilias.forms.handler;

import oracle.forms.handler.CheckboxItem;

public class IliasCheckboxItem extends CheckboxItem {
}
