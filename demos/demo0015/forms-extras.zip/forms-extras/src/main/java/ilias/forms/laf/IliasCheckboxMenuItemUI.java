package ilias.forms.laf;

import oracle.ewt.laf.generic.GenericCheckboxMenuItemUI;
import oracle.ewt.lwAWT.LWComponent;

public class IliasCheckboxMenuItemUI extends GenericCheckboxMenuItemUI {
	public IliasCheckboxMenuItemUI(LWComponent paramLWComponent) {
		super(paramLWComponent);
	}
}
