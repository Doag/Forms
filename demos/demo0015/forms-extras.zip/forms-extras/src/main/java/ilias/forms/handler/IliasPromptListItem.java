package ilias.forms.handler;

import ilias.forms.ui.AdvancedTextAreaItem;
import ilias.forms.ui.AdvancedTextFieldItem;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import oracle.forms.engine.Message;
import oracle.forms.engine.MessageHandler;
import oracle.forms.engine.Runform;
import oracle.forms.handler.ComponentItem;
import oracle.forms.handler.TextAreaItem;
import oracle.forms.handler.TextFieldItem;
import oracle.forms.properties.ID;
import oracle.graphics.vgs.ui.Device;

/**
 * Used to push the prompt for an Advanced Field into that field. It is used as
 * key for the 'Past special'
 * 
 * @author gyselinl
 * 
 */
public class IliasPromptListItem extends ComponentItem {

	private static int sHandlerClassId = 0;

	private int itemId;
	private IliasFormCanvas mFormCanvas;
	private Vector<IliasPromptItem> mPrompts;
	private int mNumPrompts;
	private Hashtable<Integer, Integer> mHashTable;
	private IliasPromptItem mLocalPrompt = null;

	public IliasPromptListItem() {
		setHandler(this);
		this.mNumPrompts = 0;
		this.mHashTable = new Hashtable<Integer, Integer>();
		this.mPrompts = new Vector<IliasPromptItem>();
	}

	public synchronized void onRegister(int paramInt) {
		sHandlerClassId = paramInt;
	}

	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);
		onUpdate(message);
		mFormCanvas.addPromptListItem(this);
	}

	@Override
	public synchronized boolean onUpdate(int id, Object value) {
		int index;
		boolean result = true;
		switch (id) {
		case ID.INDEX_PROMPTLIST_CANVAS:
			mFormCanvas = ((IliasFormCanvas) getDispatcher().getHandler(
					((Integer) value).intValue()));
			break;
		case ID.INDEX_PROMPTLIST_ADD_PROMPT_ID:
			mLocalPrompt = new IliasPromptItem();
			mLocalPrompt.setPromptProperty(IliasPromptItem.PROMPT_ITEMINDEX, value);
			addPromptToList(mLocalPrompt);
			mNumPrompts += 1;
			itemId = (Integer) value;
			break;
		case ID.INDEX_PROMPTLIST_UPDATE_PROMPT_ID:
			index = mHashTable.get(value).intValue();
			mLocalPrompt = mPrompts.elementAt(index);
			mLocalPrompt.setDirty(true);
			break;
		case ID.INDEX_PROMPTLIST_REMOVE_PROMPT:
			index = mHashTable.get(value).intValue();
			onRemove(index);
			break;
		case ID.INDEX_PROMPTLIST_DONE_PROMPT:
			if (!mLocalPrompt.isDirty()) {
				break;
			}
			mLocalPrompt.damagePrompt(mFormCanvas);
			break;
		case ID.INDEX_VALUE:
			result = mLocalPrompt.setPromptProperty(id, value);
			MessageHandler handler = getDispatcher().getHandler(itemId);
			if (handler instanceof TextFieldItem) {
				TextFieldItem item = (TextFieldItem) handler;
				if (item.getComponent() instanceof AdvancedTextFieldItem) {
					AdvancedTextFieldItem textField = (AdvancedTextFieldItem) item.getComponent();
					textField.setPrompt(((String[]) value)[0]);
				}
			} else if (handler instanceof TextAreaItem) {
				TextAreaItem item = (TextAreaItem) handler;
				if (item.getComponent() instanceof AdvancedTextAreaItem) {
					AdvancedTextAreaItem textArea = (AdvancedTextAreaItem) item.getComponent();
					textArea.setPrompt(((String[]) value)[0]);
				}
			}
			break;
		default:
			result = mLocalPrompt.setPromptProperty(id, value);
			break;
		}
		return result;
	}

	public void dirtyAllPrompts() {
		for (int i = 0; i < mPrompts.size(); i++) {
			mPrompts.elementAt(i).setDirty(true);
		}
	}

	public void addPromptToList(IliasPromptItem item) {
		mPrompts.addElement(item);
		Integer k = new Integer(item.getItemInfo().getItemIndex());
		Integer v = new Integer(mPrompts.indexOf(item));
		mHashTable.put(k, v);
	}

	public void onRemove(int index) {
		mPrompts.removeElementAt(index);
		mNumPrompts -= 1;
	}

	@Override
	public synchronized void onDestroy() {
		super.onDestroy();
		for (int i = 0; i < this.mNumPrompts; i++) {
			mPrompts.elementAt(i).doDestroy();
		}
		mNumPrompts = 0;
		mPrompts = null;
		mHashTable = null;
		mFormCanvas = null;
	}

	public int getHandlerClassId() {
		return sHandlerClassId;
	}

	public void listProperties(PrintStream paramPrintStream, String paramString) {
	}

	public void onDraw(Graphics g, Device device) {
		for (int i = 0; i < mNumPrompts; i++) {
			IliasPromptItem item = mPrompts.elementAt(i);
			if (!item.isDisplayed()) {
				continue;
			}
			item.drawPrompt(g, device, mFormCanvas);
		}
	}

	public List<IliasPromptItem> getPromptsInRect(Rectangle rect) {
        int scale = 100;
		List<IliasPromptItem> result = new ArrayList<IliasPromptItem>();
		for (int i = 0; i < mNumPrompts; i++) {
			IliasPromptItem item = mPrompts.elementAt(i);
			if (!item.isDisplayed()) {
				continue;
			}
            int x = item.getOriginalX() * scale / 100;
            int y = item.getOriginalY() * scale / 100;
            Point topLeft = new Point(x, y);
			if (rect.contains(topLeft)) {
				result.add(item);
			}
		}
		return result;
	}
}
