package ilias.forms.laf;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

import oracle.ewt.LookAndFeel;
import oracle.ewt.UIDefaults;
import oracle.ewt.laf.basic.DisablingPainter;
import oracle.ewt.laf.basic.TabTextPainter;
import oracle.ewt.laf.generic.GenericFocusPainter;
import oracle.ewt.laf.generic.GenericTabBarUI;
import oracle.ewt.laf.generic.GenericTabPainter;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AlignmentPainter;
import oracle.ewt.painter.DirectionalBorderPainter;
import oracle.ewt.painter.FixedBorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.painter.Painter;
import oracle.ewt.painter.PainterJoiner;
import oracle.ewt.tabBar.TabBar;
import oracle.ewt.util.StringUtils;

public class IliasTabBarUI extends GenericTabBarUI {

	private static int TAB_BAR_WIDTH = 133;
	
	private static Painter[] _sPainterCache = new Painter[12];

	public IliasTabBarUI(LWComponent component) {
		super(component);
	}

	@Override
	public void uninstallUI(LWComponent paramLWComponent) {
		super.uninstallUI(paramLWComponent);
	}

	@Override
	public Painter getTabPainter(LWComponent component, boolean leftMost, boolean rightMost) {

		TabBar tabBar = (TabBar) component;

		int orientation;
		if (tabBar.getOrientation() == TabBar.BOTTOM)
			orientation = GenericTabPainter.ORIENTATION_BOTTOM;
		else if (tabBar.getOrientation() == TabBar.TOP)
			orientation = GenericTabPainter.ORIENTATION_TOP;
		else if (tabBar.getOrientation() == TabBar.LEFT)
			orientation = GenericTabPainter.ORIENTATION_LEFT;
		else
			orientation = GenericTabPainter.ORIENTATION_RIGHT;

		int position;
		if (leftMost)
			position = GenericTabPainter.POSITION_LEFTMOST;
		else if (rightMost)
			position = GenericTabPainter.POSITION_RIGHTMOST;
		else
			position = GenericTabPainter.POSITION_CENTER;

		int k = orientation * 3 + position;

		Painter painter = _sPainterCache[k];
		
		if (painter == null) {
			UIDefaults ui = getUIDefaults(component);
			Painter border1 = new DirectionalBorderPainter(
					ui.getPainter(LookAndFeel.IMAGE_SET_PAINTER), 0, 0, 0, 0,
					true);
			Painter textPainter = new FixedWidthTabTextPainter(orientation);
			Painter border2 = new DirectionalBorderPainter(
					new DisablingPainter(textPainter), 2, 4, 2, 4, true);
			//
			painter = new PainterJoiner(border1, border2,
					PainterJoiner.ALIGN_CENTER_ANTIDEFAULT);
			// Use the alignments
			painter = new AlignmentPainter(painter);
			// Draw a focus rectangle for the selected item
			painter = new GenericFocusPainter(painter);
			// Control the padding of the focus rectangle
			if (orientation == GenericTabPainter.ORIENTATION_TOP) {
				painter = new FixedBorderPainter(painter, 1, 0, 0, 0); // top,left,bottom,right
			} else if (orientation == GenericTabPainter.ORIENTATION_BOTTOM) {
				painter = new FixedBorderPainter(painter, 0, 0, 1, 0); // top,left,bottom,right
			} else {
				painter = new FixedBorderPainter(painter, 0, 0, 0, 0); // top,left,bottom,right
			}
			// Draw the tab borders
			painter = new IliasTabPainter(painter, orientation, position);
			_sPainterCache[k] = painter;
		}

		return painter;
	}

	static class FixedWidthTabTextPainter extends TabTextPainter {
		private final int orientation;

		public FixedWidthTabTextPainter(int orientation) {
			this.orientation = orientation;
		}

		public Dimension getPreferredSize(PaintContext ctx) {
			return _getSize(ctx, true);
		}

		public Dimension getMinimumSize(PaintContext ctx) {
			return _getSize(ctx, false);
		}

		private Dimension _getSize(PaintContext ctx, boolean preferred) {
			int width = 0;
			int height = 0;
			Font font = getFont(ctx);
			if (font != null) {
				FontMetrics fm = ctx.getFontMetrics(font);
				String str = preferred ? getStringData(ctx)
						: getMinimumStringData(ctx);
				if ((fm != null) && (str != null)) {
					str = StringUtils.getDisplayString(str, ctx);
					width = fm.stringWidth(str);
					height = fm.getHeight() - fm.getLeading();
				}
			}
			if (orientation == GenericTabPainter.ORIENTATION_LEFT) {
				width = TAB_BAR_WIDTH;
			}
			return new Dimension(width, height);
		}

		protected int paintText(PaintContext ctx, Graphics g, FontMetrics fm,
				String str, int x, int y, int w, float alignment, int k) {
			if (orientation == GenericTabPainter.ORIENTATION_LEFT) {
				alignment = 1.0f;
			}
			Font oldFont = g.getFont();
			g.setFont(getFont(ctx));
			// If disabled, text is grayed
			int result = super.paintText(ctx, g, g.getFontMetrics(), str, x, y, w, alignment, k);
			g.setFont(oldFont);
			return result;
		}
		
		private Font getFont(PaintContext ctx) {
			int state = ctx.getPaintState();
			UIDefaults ui = ctx.getPaintUIDefaults();
			Font font;
			/*
			if ((state & PaintContext.STATE_SELECTED) != 0) {
				// Selected (bold font)
				font = ui.getFont("TabBar.selectedItemFont");
			} else {
				// Not selected (normal font)
				font = ui.getFont("TabBar.itemFont");
			}
			*/
			if ((state & PaintContext.STATE_DISABLED) == 0) {
				font = ui.getFont("TabBar.selectedItemFont");
			} else {
				font = ui.getFont("TabBar.itemFont");
			}
			return font;
		}
	}

	static class IliasTabPainter extends GenericTabPainter {
		private int orientation;

		public IliasTabPainter(Painter painter, int orientation, int position) {
			super(painter, orientation, position);
			this.orientation = orientation;
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y,
				int w, int h) {
			int state = ctx.getPaintState();
			UIDefaults ui = ctx.getPaintUIDefaults();
			Color oldColor = g.getColor();
			if ((state & PaintContext.STATE_SELECTED) == 0) {
				if ((state & PaintContext.STATE_DISABLED) != 0) {
					Color c = ui.getColor("TabBar.itemBackground");
					g.setColor(c);
				} else {
					Color c = ui.getColor("TabBar.itemBackground");
					g.setColor(c);
				}
				g.fillRect(x, y, w, h);
			}
			Color c = ui.getColor("TabBar.selectedItemBackground");
			g.setColor(c);
			if ((state & PaintContext.STATE_SELECTED) == 0) {
				// Not selected, just a border
				if (orientation != GenericTabPainter.ORIENTATION_LEFT) {
					g.drawRect(x-1, y-1, w+2, h+2);
					g.drawRect(x, y, w, h);
				}
			} else {
				// Selected, fill tab
				if (orientation == GenericTabPainter.ORIENTATION_TOP) {
					g.fillRect(x, y+1, w, h-1);
				} else if (orientation == GenericTabPainter.ORIENTATION_BOTTOM) {
					g.fillRect(x, y, w, h-1);
				} else {
					g.fillRect(x, y, w, h);
				}
			}
			g.setColor(oldColor);
		}
	}
}
