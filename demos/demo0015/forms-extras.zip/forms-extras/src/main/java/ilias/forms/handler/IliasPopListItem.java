package ilias.forms.handler;

import oracle.forms.handler.PopListItem;

public class IliasPopListItem extends PopListItem {
}
