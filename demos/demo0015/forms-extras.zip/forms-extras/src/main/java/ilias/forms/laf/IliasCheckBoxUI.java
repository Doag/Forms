package ilias.forms.laf;

import java.awt.Image;

import oracle.ewt.UIDefaults;
import oracle.ewt.graphics.ImageStrip;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.Painter;

public class IliasCheckBoxUI extends IliasToggleButtonUI {
	public IliasCheckBoxUI(LWComponent comp) {
		super(comp);
	}

	protected String getPainterKeyName() {
		return "CheckBoxPainter";
	}

	protected String getComponentPainterKeyName() {
		return "CheckBoxComponentPainter";
	}

	public static Object instantiate(UIDefaults defaults, Object key, String arg) {
		if (key.equals("CheckBoxPainter")) {
			Painter p1 = new IliasImageSetPainter(defaults.getImage("checkboxStrip"));
			Painter p2 = new IliasImageSetPainter(defaults.getImage("checkboxQueryStrip"));
			return new IliasToggleButtonUIPainter(p1, p2);
		}
		if (key.equals("checkboxSet")) {
			Image strip = defaults.getImage("checkboxStrip");
			return new ImageStrip(strip, IMAGESTRIP_MASK);
		}
		if (key.equals("checkboxQuerySet")) {
			Image strip = defaults.getImage("checkboxQueryStrip");
			return new ImageStrip(strip, IMAGESTRIP_MASK);
		}
		if (key.equals("CheckBoxComponentPainter")) {
			return createComponentPainter(defaults, defaults.getPainter("CheckBoxPainter"));
		}
		return null;
	}
}