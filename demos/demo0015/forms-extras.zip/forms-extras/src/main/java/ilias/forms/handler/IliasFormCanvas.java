package ilias.forms.handler;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;

import oracle.ewt.scrolling.scrollBox.ScrollBox;
import oracle.forms.engine.Message;
import oracle.forms.engine.MessageHandler;
import oracle.forms.engine.Runform;
import oracle.forms.handler.FormCanvas;
import oracle.forms.handler.FormWindow;
import oracle.forms.properties.ID;

/**
 * Canvases are created with a given DRAWN_CANVASUSAGE
 * USAGE_CONTENT = 1:
	TYPE: CREATE
	HANDLER_CLASS_ID: FormCanvas (259)
	HANDLER_ID: 104
	 PROPERTY: DRAWN_CANVASUSAGE 213 (byte) 1
	 PROPERTY: UI_PARENT 134 (int) 103                     <- Window
	 PROPERTY: OUTERSIZE 137 (point) x=640,y=427
	 PROPERTY: FONT 149 (int) 1
	 PROPERTY: SIZE 126 (point) x=640,y=427
 * USAGE_OTHER = 5;
	TYPE: CREATE
	HANDLER_CLASS_ID: FormCanvas (259)
	HANDLER_ID: 110
	 PROPERTY: DRAWN_CANVASUSAGE 213 (byte) 5
	 PROPERTY: UI_PARENT 134 (int) 104                     <- Canvas USAGE 1
	 PROPERTY: OUTERSIZE 137 (point) x=2731,y=2731
	 PROPERTY: BACKGROUND 147 (int) 11
	 PROPERTY: FONT 149 (int) 3
	 PROPERTY: EVENTMASK 163 (int) 265
	 PROPERTY: LANGUAGE_DIRECTION 165 (byte) 1
	 PROPERTY: TITLE 129 (string) "PAGE_1"
	 PROPERTY: SIZE 126 (point) x=2731,y=2731
 * USAGE_VTOOLBARALLEY = 2;
	TYPE: CREATE
	HANDLER_CLASS_ID: FormCanvas (259)
	HANDLER_ID: 106
	 PROPERTY: DRAWN_CANVASUSAGE 213 (byte) 2
	 PROPERTY: OUTERSIZE 137 (point) x=640,y=427
	 PROPERTY: TITLE 129 (string) "vertical_toolbar"
	--
	TYPE: UPDATE
	HANDLER_ID: 106
	 PROPERTY: USAGE 158 (byte) 2
	 PROPERTY: UI_PARENT 134 (int) 103
 * USAGE_HTOOLBARALLEY = 3;
	TYPE: CREATE
	HANDLER_CLASS_ID: FormCanvas (259)
	HANDLER_ID: 105
	 PROPERTY: DRAWN_CANVASUSAGE 213 (byte) 3
	 PROPERTY: OUTERSIZE 137 (point) x=640,y=427
	 PROPERTY: TITLE 129 (string) "vertical_toolbar"
    --
	TYPE: UPDATE
	HANDLER_ID: 105
	 PROPERTY: USAGE 158 (byte) 3
	 PROPERTY: UI_PARENT 134 (int) 103
 * USAGE_STATUSALLEY = 4;
	TYPE: CREATE
	HANDLER_CLASS_ID: FormCanvas (259)
	HANDLER_ID: 107
	 PROPERTY: DRAWN_CANVASUSAGE 213 (byte) 4
	 PROPERTY: UI_PARENT 134 (int) 103                        <- Window
	 PROPERTY: TITLE 129 (string) "status_line"
 *
 * getComponent() returns a ScrollBox if usage = 1 or 5, else the DrawnPanel
 * getPanel() always returns the DrawnPanel
 * 
 * @author gyselinl
 *
 */
public class IliasFormCanvas extends FormCanvas {

	private FormWindow mWindow;
	private IliasDisplayList mBoilerplate = null;
	private IliasPromptListItem mPromptListItem = null;
	private boolean backgroundSet = false;
	private boolean mHDisplayPolicy = false;
	private boolean mVDisplayPolicy = false;

	@Override
	public void doAddParent(int handlerId) {
		super.doAddParent(handlerId);
		MessageHandler handler = getDispatcher().getHandler(handlerId);
		if (handler instanceof FormWindow) {
			mWindow = (FormWindow) handler;
		}
	}

	public FormWindow getWindow() {
		return mWindow;
	}

	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);
		if (!backgroundSet) {
			getComponent().setBackground(Color.white);
			getPanel().setBackground(Color.white);
		}
	}

	@Override
	public synchronized boolean onUpdate(int id, Object value) {
		boolean handled = false;
		switch (id) {
		case ID.INDEX_BACKGROUND:
			backgroundSet = true;
			handled = super.onUpdate(id, value);
			break;
		case ID.INDEX_SBOX_HSA:
			mHDisplayPolicy = ((Boolean)value).booleanValue();
			handled = super.onUpdate(id, value);
			fixScrollBars();
			break;
		case ID.INDEX_SBOX_VSA:
			mVDisplayPolicy = ((Boolean)value).booleanValue();
			handled = super.onUpdate(id, value);
			fixScrollBars();
			break;
		default:
			handled = super.onUpdate(id, value);
			break;
		}
		return handled;
	}

	private void fixScrollBars() {
		// getComponent() returns a ScrollBox in case of usage USAGE_CONTENT(1) and USAGE_OTHER(5)
		if (getComponent() instanceof ScrollBox) {
			ScrollBox scrollBox = (ScrollBox)getComponent();
			if (mHDisplayPolicy) {
				scrollBox.setHDisplayPolicy(ScrollBox.DISPLAY_AS_NEEDED);
			}
			if (mVDisplayPolicy) {
				scrollBox.setVDisplayPolicy(ScrollBox.DISPLAY_AS_NEEDED);
			}
		}
	}

	public void addGraphic(IliasDisplayList displayList) {
		mBoilerplate = displayList;
		getComponent().repaint();
	}

	public void addPromptListItem(IliasPromptListItem promptListItem) {
		mPromptListItem = promptListItem;
	}

	public IliasPromptListItem getPromptListItem() {
		return mPromptListItem;
	}

	@Override
	public void paint(Graphics g, Dimension size, Rectangle rect) {
		if (mBoilerplate != null) {
			mBoilerplate.drawGraphic(g, this);
		}
		if (mPromptListItem != null) {
			mPromptListItem.onDraw(g, this);
		}
	}
}
