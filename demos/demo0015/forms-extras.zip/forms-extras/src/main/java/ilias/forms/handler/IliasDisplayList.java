package ilias.forms.handler;

import ilias.forms.vgs.IliasDisplayGroup;

import java.awt.Graphics;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Vector;

import oracle.forms.engine.Message;
import oracle.forms.engine.Runform;
import oracle.forms.handler.ComponentItem;
import oracle.forms.properties.ID;
import oracle.graphics.vgs.ui.Device;
import oracle.graphics.vgs.ui.PackedTree;
import oracle.graphics.vgs.ui.Transform;

public class IliasDisplayList extends ComponentItem {

	private static int sHandlerClassId = 0;

	private IliasDisplayGroup mDisplayTree;
	private IliasFormCanvas mFormCanvas;

	public IliasDisplayList() {
		setHandler(this);
	}

	@Override
	public synchronized void onRegister(int paramInt) {
		sHandlerClassId = paramInt;
	}
	
	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);

		Transform transformer = new Transform();
		Vector<byte[]> vector = null;

		int n = message.size();
		for (int i = 0; i < n; i++) {
			int id = message.getPropertyAt(i);
			Object value = message.getValueAt(i);
			switch (id) {
			case ID.INDEX_BP_PARENT:
				int index = ((Integer) value).intValue();
				mFormCanvas = (IliasFormCanvas) runform.getHandler(index);
				mFormCanvas.addGraphic(this);
				break;
			case ID.INDEX_BP_NUMCHUNKS:
				vector = new Vector<byte[]>(((Integer) value).intValue());
				break;
			case ID.INDEX_BP_CHUNK:
				vector.addElement((byte[]) value);
				break;
			case ID.INDEX_BP_SCREEN_HORIZONTAL:
				transformer.setClientXScale(((Integer) value).intValue());
				break;
			case ID.INDEX_BP_SCREEN_VERTICAL:
				transformer.setClientYScale(((Integer) value).intValue());
				break;
			case ID.INDEX_BP_VGS_HORIZONTAL:
				transformer.setVGSXScale(((Integer) value).intValue());
				break;
			case ID.INDEX_BP_VGS_VERTICAL:
				transformer.setVGSYScale(((Integer) value).intValue());
				break;
			}
		}

		int version = runform.getVGSVersion().intValue();

		mDisplayTree = new IliasDisplayGroup(getDispatcher().getApplet(), mFormCanvas);
		try {
			PackedTree tree = new PackedTree(vector, version, transformer);
			mDisplayTree.unpackTree(tree);
		} catch (IOException e) {
			mDisplayTree = null;
		}
	}

	@Override
	public synchronized void onDestroy() {
		super.onDestroy();
		mFormCanvas = null;
		if (mDisplayTree != null) {
			mDisplayTree.onDestroy();
		}
		mDisplayTree = null;
	}

	@Override
	public int getHandlerClassId() {
		return sHandlerClassId;
	}

	@Override
	public void listProperties(PrintStream paramPrintStream, String paramString) {
	}

	public void drawGraphic(Graphics g, Device device) {
		if (mDisplayTree != null) {
			mDisplayTree.drawGraphic(g, device);
		}
	}
}
