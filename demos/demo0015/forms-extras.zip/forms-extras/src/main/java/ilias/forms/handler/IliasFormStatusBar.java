package ilias.forms.handler;

import ilias.forms.laf.IliasRectanglePainter;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import oracle.ewt.EwtContainer;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.lwAWT.lwText.LWTextField;
import oracle.forms.engine.Message;
import oracle.forms.engine.Runform;
import oracle.forms.handler.FormStatusBar;
import oracle.forms.properties.ID;

public class IliasFormStatusBar extends FormStatusBar {

	private int mCurrentLamp = -1;
	private String mRecordIndicator;
	private String mMessage;
	private EwtContainer mContainer;
	private LWTextField mRecordField;
	private LWTextField mMessageField;

	@Override
	public synchronized void onCreate(Runform runform, Message message) {
		super.onCreate(runform, message);

		mContainer = new EwtContainer();
		mContainer.setLayout(new GridBagLayout());

		mRecordField = new LWTextField();
		mRecordField.setBorderPainter(new IliasRectanglePainter());
		mRecordField.setEditable(false);
		mRecordField.setFocusable(false);
		
		mMessageField = new LWTextField();
		mMessageField.setBorderPainter(new IliasRectanglePainter());
		mMessageField.setEditable(false);
		mMessageField.setFocusable(false);

		GridBagConstraints constraints = new GridBagConstraints();
	    constraints.fill = 1;
	    constraints.weightx = 0.10D;
	    mContainer.add(mRecordField, constraints);
	    constraints.weightx = 0.84D;
	    mContainer.add(mMessageField, constraints);
	}

	@Override
	public synchronized void onDestroy() {
		super.onDestroy();
		mContainer.removeAll();
		mMessageField = null;
		mRecordField = null;
	}

	public LWComponent getComponent() {
		return mContainer;
	}

	public LWComponent getStatusBar() {
		return mContainer;
	}

	@Override
	public synchronized boolean onUpdate(int id, Object value) {
	    switch (id) {
	    case ID.INDEX_STBAR_ADDLAMP:
	    	break;
	    case ID.INDEX_STBAR_MSGLINE:
	    	mMessage = (String)value;
    		mMessageField.setText(mMessage);
	    	break;
	    case ID.INDEX_STBAR_LAMP_INDEX:
	    	this.mCurrentLamp = ((Integer)value).intValue();
	    	break;
	    case ID.INDEX_STBAR_LAMP_VALUE:
	    	switch(mCurrentLamp) {
	    	case 0:
	    		mRecordIndicator = (String)value;
	    		mRecordField.setText(mRecordIndicator);
	    		break;
	    	}
	    	//this.mCurrentLampValue = (String)value;
	    	//System.out.println("Lamp #" + mCurrentLamp + "=" + mCurrentLampValue);
	    	break;
	    case ID.INDEX_STBAR_SHOW_WORKING:
	    	break;
	    case ID.INDEX_STBAR_BLANK_MSG:
	    	mMessage = null;
    		mMessageField.setText(mMessage);
	    	break;
	    case ID.INDEX_STBAR_REMOVE_LAMPS:
	    	mRecordIndicator = null;
    		mRecordField.setText(mRecordIndicator);
	    	break;
	    }
		return super.onUpdate(id, value);
	}
}
