package ilias.forms.laf;

import java.awt.Image;

import oracle.ewt.UIDefaults;
import oracle.ewt.graphics.ImageStrip;
import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.Painter;

public class IliasRadioButtonUI extends IliasToggleButtonUI {
	public IliasRadioButtonUI(LWComponent comp) {
		super(comp);
	}

	protected String getPainterKeyName() {
		return "RadioButtonPainter";
	}

	protected String getComponentPainterKeyName() {
		return "RadioButtonComponentPainter";
	}

	public static Object instantiate(UIDefaults defaults, Object key, String arg) {
		if (key.equals("RadioButtonPainter")) {
			Painter p1 = new IliasImageSetPainter(defaults.getImage("radioButtonStrip"));
			Painter p2 = new IliasImageSetPainter(defaults.getImage("radioButtonQueryStrip"));
			return new IliasToggleButtonUIPainter(p1, p2);
		}
		if (key.equals("radioButtonSet")) {
			Image strip = defaults.getImage("radioButtonStrip");
			return new ImageStrip(strip, IMAGESTRIP_MASK);
		}
		if (key.equals("radioButtonQuerySet")) {
			Image strip = defaults.getImage("radioButtonQueryStrip");
			return new ImageStrip(strip, IMAGESTRIP_MASK);
		}
		if (key.equals("RadioButtonComponentPainter")) {
			return createComponentPainter(defaults, defaults.getPainter("RadioButtonPainter"));
		}
		return null;
	}
}