package ilias.forms.ui;

import ilias.forms.error.ErrorManager;
import ilias.forms.laf.IliasLookAndFeel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;

import oracle.ewt.lwAWT.LWComponent;
import oracle.ewt.painter.AbstractBorderPainter;
import oracle.ewt.painter.BorderPainter;
import oracle.ewt.painter.PaintContext;
import oracle.ewt.util.ImmInsets;
import oracle.forms.properties.BorderBevel;

public class CheckboxComponentBorder implements FocusListener, HierarchyListener {

	private CheckboxBorderPainter borderPainter;
	private Component component;
	private String error = null;

	public CheckboxComponentBorder(Component component) {
		this.component = component;
		component.addHierarchyListener(this);
		// Listen to 'focus' events
		component.addFocusListener(this);
		borderPainter = new CheckboxBorderPainter();
	}

	public void setBorderBevel(BorderBevel bevel) {
		borderPainter.borderBevel = bevel;
	}

	private void dispose() {
		component.removeHierarchyListener(this);
		component.removeFocusListener(this);
		component = null;
	}

	public void setErrorString(String error) {
		if (this.error != null) {
			ErrorManager.getErrorManager().unregisterComponent(component);
			removeErrorBorder();
		}
		this.error = error;
		if (this.error != null) {
			addErrorBorder();
			ErrorManager.getErrorManager().registerComponent(component);
		}
	}

	public String getErrorString() {
		return error;
	}

	private void addFocusBorder() {
		borderPainter.setFocus(true);
		component.repaint();
		/*
		focusBorder = new FocusBorder();
		setBorderBounds(focusBorder, component.getBounds());
		component.getParent().add(focusBorder);
		*/
	}

	private void removeFocusBorder() {
		borderPainter.setFocus(false);
		component.repaint();
		/*
		if (focusBorder != null) {
			component.getParent().remove(focusBorder);
			focusBorder = null;
		}
		*/
	}

	private void addErrorBorder() {
		borderPainter.setError(true);
		component.repaint();
		/*
		errorBorder = new ErrorBorder();
		setBorderBounds(errorBorder, component.getBounds());
		component.getParent().add(errorBorder);
		*/
	}

	private void removeErrorBorder() {
		borderPainter.setError(false);
		component.repaint();
		/*
		if (errorBorder != null) {
			component.getParent().remove(errorBorder);
			errorBorder = null;
		}
		*/
	}

	// Focus listener

	public void focusGained(FocusEvent e) {
		addFocusBorder();
	}

	public void focusLost(FocusEvent e) {
		removeFocusBorder();
	}

	public void hierarchyChanged(HierarchyEvent e) {
		if (e.getID() == HierarchyEvent.PARENT_CHANGED) {
			if (component.getParent() != null) {
				if (component.hasFocus()) {
					addFocusBorder();
				}
				if (error != null) {
					addErrorBorder();
				}
			} else {
				removeFocusBorder();
				removeErrorBorder();
				dispose();
			}
		}
	}

	public BorderPainter getBorderPainter() {
		return borderPainter;
	}

	public static class CheckboxBorderPainter extends AbstractBorderPainter {

		private static final Color ERROR_COLOR = new Color(255, 0, 0);

		private static final ImmInsets _INSETS0 = new ImmInsets(0, 0, 0, 0);

		private boolean hasFocus = false;
		private boolean hasError = false;
		
		public BorderBevel borderBevel;

		protected void setFocus(boolean flag) {
			hasFocus = flag;
		}
		
		protected void setError(boolean flag) {
			hasError = flag;
		}

		protected ImmInsets getOwnInsets(PaintContext ctx) {
			return _INSETS0;
		}

		protected void paintBorder(PaintContext ctx, Graphics g, int x, int y, int w, int h) {
			int off = (h - 12) / 4;
			Color oldColor = g.getColor();
			if (borderBevel != BorderBevel.NONE) {
				if (hasError) {
					g.setColor(ERROR_COLOR);
					g.drawRect(x, y + off, 12, 13);
					g.setColor(IliasLookAndFeel.BORDER_COLOR);
					g.drawRect(x + 1, y + off + 1, 10, 11);
				} else if (hasFocus) {
					g.setColor(IliasLookAndFeel.FOCUS_COLOR);
					g.drawRect(x, y + off, 12, 13);
					g.setColor(IliasLookAndFeel.BORDER_COLOR);
					g.drawRect(x + 1, y + off + 1, 10, 11);
				} else {
					// Draw nothing
				}
			}
			g.setColor(oldColor);
		}

		public int getRepaintFlags(PaintContext ctx) {
			return super.getRepaintFlags(ctx) | 0x80;
		}

		protected boolean isBorderTransparent(PaintContext ctx) {
			return false;
		}
	}

	public static class FocusBorder extends LWComponent {

		private static final long serialVersionUID = 4498984874691493766L;

		public void paint(Graphics g) {
			Color oldColor = g.getColor();
			g.setColor(IliasLookAndFeel.FOCUS_COLOR);
			g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
			g.setColor(oldColor);
		}
	}

	public static class ErrorBorder extends LWComponent {

		private static final long serialVersionUID = 7871281472894938526L;

		private static final Color ERROR_COLOR = new Color(255, 0, 0);

		public void paint(Graphics g) {
			Color oldColor = g.getColor();
			g.setColor(ERROR_COLOR);
			g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
			g.setColor(oldColor);
		}
	}
}
